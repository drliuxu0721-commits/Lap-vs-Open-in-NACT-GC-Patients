################################################################################
# 03_survival_analysis.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# KM curves + Cox models for DFS/OS in Original, PSM, and IPTW cohorts
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(survival)
library(survminer)
library(survey)
library(dplyr)
library(tibble)
library(openxlsx)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Survival", showWarnings = FALSE, recursive = TRUE)
dir.create("results/Figures", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import data
## ------------------------------------------------------------------

dat_original <- read.csv("results/analysis_dataset_before_psm_iptw.csv",
                         header = TRUE, check.names = TRUE)

dat_psm <- read.csv("results/PSM/matched_dataset.csv",
                    header = TRUE, check.names = TRUE)

dat_iptw <- read.csv("results/IPTW/data_after_iptw.csv",
                     header = TRUE, check.names = TRUE)

## ------------------------------------------------------------------
## 4. Data formatting
## ------------------------------------------------------------------

format_data <- function(dat) {
  
  dat$Surgical.approach <- factor(
    dat$Surgical.approach,
    levels = c("Open", "Laparoscopic")
  )
  dat$Surgical.approach <- relevel(dat$Surgical.approach, ref = "Open")
  
  dat$DFS <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS <- as.numeric(dat$OS)
  dat$OS.time <- as.numeric(dat$OS.time)
  
  factor_vars <- c(
    "Sex",
    "Tumor.site",
    "cT",
    "cN",
    "Grade",
    "Lauren.classification",
    "Bormann.classification",
    "NACT.regimen",
    "Surgical.procedure",
    "ypT",
    "ypN",
    "Mandard.TRG",
    "MPR",
    "pCR",
    "Margin",
    "Nerve.Invasion",
    "Lymphovascular.Tumor.Thrombus",
    "ACT",
    "ACT.regimen",
    "Complication",
    "Perioperative.mortality"
  )
  
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  
  numeric_vars <- c(
    "Age",
    "NACT.cycles",
    "Operation.time",
    "Positive.Lymph.Nodes.Count",
    "Total.Lymph.Nodes.Count"
  )
  
  numeric_vars <- intersect(numeric_vars, names(dat))
  dat[, numeric_vars] <- lapply(dat[, numeric_vars], as.numeric)
  
  dat <- dat %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(DFS), !is.na(DFS.time), !is.na(OS), !is.na(OS.time))
  
  return(dat)
}

dat_original <- format_data(dat_original)
dat_psm      <- format_data(dat_psm)
dat_iptw     <- format_data(dat_iptw)

## ------------------------------------------------------------------
## 5. Event summary
## ------------------------------------------------------------------

event_summary <- data.frame(
  Cohort = c("Original", "PSM", "IPTW"),
  N = c(nrow(dat_original), nrow(dat_psm), nrow(dat_iptw)),
  Open_N = c(
    sum(dat_original$Surgical.approach == "Open", na.rm = TRUE),
    sum(dat_psm$Surgical.approach == "Open", na.rm = TRUE),
    sum(dat_iptw$Surgical.approach == "Open", na.rm = TRUE)
  ),
  Laparoscopic_N = c(
    sum(dat_original$Surgical.approach == "Laparoscopic", na.rm = TRUE),
    sum(dat_psm$Surgical.approach == "Laparoscopic", na.rm = TRUE),
    sum(dat_iptw$Surgical.approach == "Laparoscopic", na.rm = TRUE)
  ),
  DFS_events = c(
    sum(dat_original$DFS == 1, na.rm = TRUE),
    sum(dat_psm$DFS == 1, na.rm = TRUE),
    sum(dat_iptw$DFS == 1, na.rm = TRUE)
  ),
  OS_events = c(
    sum(dat_original$OS == 1, na.rm = TRUE),
    sum(dat_psm$OS == 1, na.rm = TRUE),
    sum(dat_iptw$OS == 1, na.rm = TRUE)
  ),
  Median_DFS_followup = c(
    median(dat_original$DFS.time, na.rm = TRUE),
    median(dat_psm$DFS.time, na.rm = TRUE),
    median(dat_iptw$DFS.time, na.rm = TRUE)
  ),
  Median_OS_followup = c(
    median(dat_original$OS.time, na.rm = TRUE),
    median(dat_psm$OS.time, na.rm = TRUE),
    median(dat_iptw$OS.time, na.rm = TRUE)
  )
)

print(event_summary)

## ------------------------------------------------------------------
## 6. Helper functions
## ------------------------------------------------------------------

format_p <- function(p) {
  if (is.na(p)) {
    return("NA")
  } else if (p < 0.001) {
    return("<0.001")
  } else {
    return(paste0("=", sprintf("%.3f", p)))
  }
}

format_p_table <- function(p) {
  ifelse(
    is.na(p),
    "NA",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

## ------------------------------------------------------------------
## 7. Main KM + Cox function
## ------------------------------------------------------------------
## This function follows the user's original plotting style.

plot_km <- function(dat,
                    time_var,
                    event_var,
                    endpoint,
                    cohort,
                    model_type = c("Original", "PSM", "IPTW"),
                    weight_var = NULL) {
  
  model_type <- match.arg(model_type)
  rt <- dat
  
  title <- paste(cohort, endpoint)
  
  rt$Surgical.approach <- factor(
    rt$Surgical.approach,
    levels = c("Open", "Laparoscopic")
  )
  rt$Surgical.approach <- relevel(rt$Surgical.approach, ref = "Open")
  
  surv_formula <- as.formula(
    paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach")
  )
  
  ## ------------------------------------------------------------
  ## Original / PSM
  ## ------------------------------------------------------------
  
  if (is.null(weight_var)) {
    
    if (model_type == "PSM") {
      cox_formula <- as.formula(
        paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach + cluster(subclass)")
      )
      coxfit <- coxph(cox_formula, data = rt)
      model_name <- "PSM Cox with matched-pair cluster"
    } else {
      coxfit <- coxph(surv_formula, data = rt)
      model_name <- "Unadjusted Cox"
    }
    
    cox.sum <- summary(coxfit)
    
    HR  <- cox.sum$conf.int["Surgical.approachLaparoscopic", "exp(coef)"]
    LCL <- cox.sum$conf.int["Surgical.approachLaparoscopic", "lower .95"]
    UCL <- cox.sum$conf.int["Surgical.approachLaparoscopic", "upper .95"]
    Cox.P <- cox.sum$coefficients["Surgical.approachLaparoscopic", "Pr(>|z|)"]
    
    diff <- survdiff(surv_formula, data = rt)
    Logrank.P <- 1 - pchisq(diff$chisq, df = 1)
    
    hr.txt <- paste0(
      "HR = ",
      sprintf("%.2f", HR),
      " (95% CI: ",
      sprintf("%.2f", LCL),
      "-",
      sprintf("%.2f", UCL),
      ")"
    )
    
    pValue <- paste0(
      "\n  Log-rank P",
      format_p(Logrank.P),
      "\n  ",
      hr.txt
    )
    
    fit <- survfit(surv_formula, data = rt)
  }
  
  ## ------------------------------------------------------------
  ## IPTW
  ## ------------------------------------------------------------
  
  if (!is.null(weight_var)) {
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = rt
    )
    
    coxfit <- svycoxph(surv_formula, design = design)
    cox.sum <- summary(coxfit)
    
    HR  <- exp(coef(coxfit)["Surgical.approachLaparoscopic"])
    CI  <- exp(confint(coxfit)["Surgical.approachLaparoscopic", ])
    LCL <- CI[1]
    UCL <- CI[2]
    Cox.P <- cox.sum$coefficients["Surgical.approachLaparoscopic", "Pr(>|z|)"]
    
    diff <- svylogrank(surv_formula, design = design)
    Logrank.P <- as.numeric(diff[[2]][2])
    
    hr.txt <- paste0(
      "HR = ",
      sprintf("%.2f", HR),
      " (95% CI: ",
      sprintf("%.2f", LCL),
      "-",
      sprintf("%.2f", UCL),
      ")"
    )
    
    pValue <- paste0(
      "\n  Weighted log-rank P",
      format_p(Logrank.P),
      "\n  ",
      hr.txt
    )
    
    model_name <- "IPTW weighted Cox"
    
    fit <- survfit(
      surv_formula,
      data = rt,
      weights = rt[[weight_var]]
    )
  }
  
  ## Important fix for survminer compatibility
  fit$call$formula <- surv_formula
  
  ylab_text <- ifelse(
    endpoint == "DFS",
    "Disease-free survival probability",
    "Overall survival probability"
  )
  
  surPlot <- ggsurvplot(
    fit,
    # fun = 'event',
    data = rt,
    conf.int = TRUE,
    pval = pValue,
    pval.size = 6,
    pval.coord = c(0, 0.15),
    legend.title = "",
    legend.labs = c("Open", "Laparoscopic"),
    xlab = "Time(months)",
    ylab = ylab_text,
    break.time.by = 24,
    palette = c("#C24B3A", "#0F659D"),
    risk.table = TRUE,
    risk.table.title = "",
    risk.table.height = .25,
    title = title
    # legend = c(0.8, 1)
  )
  
  pdf(
    file = paste0("results/Figures/KM_", cohort, "_", endpoint, ".pdf"),
    width = 6,
    height = 8,
    onefile = FALSE
  )
  print(surPlot)
  dev.off()
  
  out <- data.frame(
    Cohort = cohort,
    Endpoint = endpoint,
    Model = model_name,
    HR = as.numeric(HR),
    Lower95CI = as.numeric(LCL),
    Upper95CI = as.numeric(UCL),
    Cox.P.value = as.numeric(Cox.P),
    Logrank.P.value = as.numeric(Logrank.P),
    stringsAsFactors = FALSE
  )
  
  return(out)
}

## ------------------------------------------------------------------
## 8. Survival rate function
## ------------------------------------------------------------------

get_surv_rate <- function(dat,
                          time_var,
                          event_var,
                          endpoint,
                          cohort,
                          weight_var = NULL) {
  
  fml <- as.formula(
    paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach")
  )
  
  if (is.null(weight_var)) {
    fit <- survfit(fml, data = dat)
  } else {
    fit <- survfit(fml, data = dat, weights = dat[[weight_var]])
  }
  
  s3 <- summary(fit, times = 36)
  s5 <- summary(fit, times = 60)
  
  out3 <- data.frame(
    Cohort = cohort,
    Endpoint = endpoint,
    Time.months = 36,
    Group = gsub("Surgical.approach=", "", s3$strata),
    Survival = s3$surv,
    Lower95CI = s3$lower,
    Upper95CI = s3$upper
  )
  
  out5 <- data.frame(
    Cohort = cohort,
    Endpoint = endpoint,
    Time.months = 60,
    Group = gsub("Surgical.approach=", "", s5$strata),
    Survival = s5$surv,
    Lower95CI = s5$lower,
    Upper95CI = s5$upper
  )
  
  out <- bind_rows(out3, out5) %>%
    mutate(
      Survival.percent = Survival * 100,
      Lower95CI.percent = Lower95CI * 100,
      Upper95CI.percent = Upper95CI * 100,
      Survival_CI = paste0(
        sprintf("%.1f", Survival.percent),
        "% (",
        sprintf("%.1f", Lower95CI.percent),
        "-",
        sprintf("%.1f", Upper95CI.percent),
        ")"
      )
    )
  
  return(out)
}

## ------------------------------------------------------------------
## 9. Run KM curves and Cox models
## ------------------------------------------------------------------

cox_results <- bind_rows(
  plot_km(dat_original, "DFS.time", "DFS", "DFS", "Original", model_type = "Original"),
  plot_km(dat_original, "OS.time",  "OS",  "OS",  "Original", model_type = "Original"),
  
  plot_km(dat_psm, "DFS.time", "DFS", "DFS", "PSM", model_type = "PSM"),
  plot_km(dat_psm, "OS.time",  "OS",  "OS",  "PSM", model_type = "PSM"),
  
  plot_km(dat_iptw, "DFS.time", "DFS", "DFS", "IPTW", model_type = "IPTW", weight_var = "iptw_weight"),
  plot_km(dat_iptw, "OS.time",  "OS",  "OS",  "IPTW", model_type = "IPTW", weight_var = "iptw_weight")
)

cox_results <- cox_results %>%
  mutate(
    HR_CI = paste0(
      sprintf("%.2f", HR),
      " (",
      sprintf("%.2f", Lower95CI),
      "-",
      sprintf("%.2f", Upper95CI),
      ")"
    ),
    Cox.P.formatted = format_p_table(Cox.P.value),
    Logrank.P.formatted = format_p_table(Logrank.P.value)
  )

write.csv(
  cox_results,
  "results/Survival/cox_results_original_psm_iptw.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 10. 3-year and 5-year survival rates
## ------------------------------------------------------------------

surv_rates <- bind_rows(
  get_surv_rate(dat_original, "DFS.time", "DFS", "DFS", "Original"),
  get_surv_rate(dat_original, "OS.time",  "OS",  "OS",  "Original"),
  
  get_surv_rate(dat_psm, "DFS.time", "DFS", "DFS", "PSM"),
  get_surv_rate(dat_psm, "OS.time",  "OS",  "OS",  "PSM"),
  
  get_surv_rate(dat_iptw, "DFS.time", "DFS", "DFS", "IPTW", weight_var = "iptw_weight"),
  get_surv_rate(dat_iptw, "OS.time",  "OS",  "OS",  "IPTW", weight_var = "iptw_weight")
)

write.csv(
  surv_rates,
  "results/Survival/survival_rates_3y_5y.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 11. Export Excel summary
## ------------------------------------------------------------------

wb <- createWorkbook()

addWorksheet(wb, "Cox results")
writeData(wb, "Cox results", cox_results)

addWorksheet(wb, "3y 5y survival")
writeData(wb, "3y 5y survival", surv_rates)

addWorksheet(wb, "Event summary")
writeData(wb, "Event summary", event_summary)

saveWorkbook(
  wb,
  "results/Survival/survival_results_summary.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 12. Console output
## ------------------------------------------------------------------

cat("\n============================================================\n")
cat("Survival analysis completed.\n")
cat("============================================================\n")

cat("\nEvent summary:\n")
print(event_summary)

cat("\nCox results:\n")
print(
  cox_results[, c(
    "Cohort",
    "Endpoint",
    "Model",
    "HR_CI",
    "Cox.P.formatted",
    "Logrank.P.formatted"
  )]
)

cat("\nOutput files:\n")
cat("results/Figures/KM_Original_DFS.pdf\n")
cat("results/Figures/KM_Original_OS.pdf\n")
cat("results/Figures/KM_PSM_DFS.pdf\n")
cat("results/Figures/KM_PSM_OS.pdf\n")
cat("results/Figures/KM_IPTW_DFS.pdf\n")
cat("results/Figures/KM_IPTW_OS.pdf\n")
cat("results/Survival/survival_results_summary.xlsx\n")
cat("results/Survival/cox_results_original_psm_iptw.csv\n")
cat("results/Survival/survival_rates_3y_5y.csv\n")