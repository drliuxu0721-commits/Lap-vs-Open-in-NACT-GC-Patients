################################################################################
# 01_lap_open_psm_iptw.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# PSM + IPTW + baseline tables + SMD
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(MatchIt)
library(WeightIt)
library(cobalt)
library(dplyr)
library(tibble)
library(stringr)
library(tableone)
library(compareGroups)
library(survey)
library(knitr)

## ------------------------------------------------------------------
## 2. Working directory and data import
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
script_dir <- file.path(root_dir, "script")
data_file <- file.path(root_dir, "data str.csv")

setwd(root_dir)

dir.create("results", showWarnings = FALSE)
dir.create("results/PSM", showWarnings = FALSE, recursive = TRUE)
dir.create("results/IPTW", showWarnings = FALSE, recursive = TRUE)
dir.create("results/Tables", showWarnings = FALSE, recursive = TRUE)
dir.create("results/Figures", showWarnings = FALSE, recursive = TRUE)

data <- read.csv(data_file, header = TRUE, check.names = TRUE)

names(data)

## ------------------------------------------------------------------
## 3. Define radical surgery cohort
## ------------------------------------------------------------------

data0 <- data %>%
  filter(Surgical.approach %in% c("Open", "Laparoscopic")) %>%
  filter(Surgical.procedure %in% c(
    "Distal gastrectomy",
    "Proximal gastrectomy",
    "Total gastrectomy"
  ))

## ------------------------------------------------------------------
## 3.1 Check survival variables
## ------------------------------------------------------------------

surv_vars <- c("DFS", "DFS.time", "OS", "OS.time")

missing_surv_vars <- setdiff(surv_vars, names(data0))

if (length(missing_surv_vars) > 0) {
  stop(
    paste0(
      "Missing survival variables: ",
      paste(missing_surv_vars, collapse = ", ")
    )
  )
}

data0 <- data0 %>%
  mutate(
    DFS = as.numeric(DFS),
    DFS.time = as.numeric(DFS.time),
    OS = as.numeric(OS),
    OS.time = as.numeric(OS.time)
  )

## ------------------------------------------------------------------
## 4. Variable formatting
## ------------------------------------------------------------------

Factor <- c(
  "Sex",
  "Tumor.site",
  "Surgical.procedure",
  "Surgical.approach",
  "NACT.regimen",
  "Lauren.classification",
  "Bormann.classification",
  "cT",
  "cN",
  "ypT",
  "ypN",
  "Mandard.TRG",
  "Margin",
  "MPR",
  "pCR",
  "ypM",
  "Peritoneal.washing.cytology",
  "Grade",
  "Nerve.Invasion",
  "Lymphovascular.Tumor.Thrombus",
  "ACT.regimen",
  "Complication",
  "CD",
  "Recurrence",
  "Metastasis",
  "Perioperative.mortality"
)

Factor <- intersect(Factor, names(data0))
data0[, Factor] <- lapply(data0[, Factor], factor)

Num <- c(
  "Age",
  "NACT.cycles",
  "Operation.time",
  "Positive.Lymph.Nodes.Count",
  "Total.Lymph.Nodes.Count",
  "DFS.time",
  "OS.time"
)

Num <- intersect(Num, names(data0))
data0[, Num] <- lapply(data0[, Num], as.numeric)

## Treatment variable
## Open as reference, Laparoscopic as treatment
data0$treat <- factor(
  data0$Surgical.approach,
  levels = c("Open", "Laparoscopic")
)

## ------------------------------------------------------------------
## 5. Variables for matching / weighting
## ------------------------------------------------------------------

ps_vars <- c(
  "Age",
  "Sex",
  "Tumor.site",
  "cT",
  "cN",
  "Grade",
  "Lauren.classification",
  "Bormann.classification",
  "NACT.regimen",
  "NACT.cycles",
  "Surgical.procedure"
)

ps_vars <- intersect(ps_vars, names(data0))

## Remove rows with missing values in treatment or PS variables
data_ps <- data0 %>%
  filter(!is.na(treat)) %>%
  filter(if_all(all_of(ps_vars), ~ !is.na(.)))

cat("\nOriginal radical surgery cohort:\n")
print(table(data0$treat, useNA = "ifany"))

cat("\nCohort used for PSM/IPTW after removing missing PS variables:\n")
print(table(data_ps$treat, useNA = "ifany"))

write.csv(data_ps, "results/analysis_dataset_before_psm_iptw.csv", row.names = FALSE)

## ------------------------------------------------------------------
## 6. PSM: nearest neighbor matching
## ------------------------------------------------------------------

ps_formula <- as.formula(
  paste("treat ~", paste(ps_vars, collapse = " + "))
)

m.out <- matchit(
  formula  = ps_formula,
  data     = data_ps,
  method   = "nearest",
  distance = "logit",
  caliper  = 0.2,
  replace  = FALSE,
  ratio    = 1,
  estimand = "ATT"
)

summary(m.out)

matched_df <- match.data(m.out)

write.csv(matched_df, "results/PSM/matched_dataset.csv", row.names = FALSE)

## ------------------------------------------------------------------
## 7. PSM SMD output
## ------------------------------------------------------------------

bal_psm <- bal.tab(m.out, un = TRUE)

smd_psm <- bal_psm$Balance %>%
  as.data.frame() %>%
  rownames_to_column("Variable") %>%
  filter(!str_detect(Variable, "distance")) %>%
  select(Variable, Diff.Un, Diff.Adj) %>%
  mutate(across(c(Diff.Un, Diff.Adj), abs)) %>%
  rename(
    SMD_before = Diff.Un,
    SMD_after_PSM = Diff.Adj
  )

write.csv(smd_psm, "results/PSM/SMD_PSM.csv", row.names = FALSE)

LP_psm <- love.plot(
  m.out,
  thresholds = 0.1,
  var.order  = "unadjusted",
  abs        = TRUE,
  colors     = c("#1f78b4", "#33a02c")
)

pdf("results/Figures/love_plot_PSM.pdf", height = 5, width = 7)
print(LP_psm)
dev.off()

## ------------------------------------------------------------------
## 8. IPTW using WeightIt
## ------------------------------------------------------------------

w.out <- weightit(
  formula   = ps_formula,
  data      = data_ps,
  method    = "ps",
  estimand  = "ATE",
  stabilize = TRUE
)

## Trim extreme weights
w.out.trim <- trim(w.out, at = 0.99, lower = TRUE)

data_iptw <- data_ps
data_iptw$iptw_weight <- w.out.trim$weights

write.csv(data_iptw, "results/IPTW/data_after_iptw.csv", row.names = FALSE)

## ------------------------------------------------------------------
## 9. IPTW SMD output
## ------------------------------------------------------------------

bal_iptw <- bal.tab(w.out.trim, un = TRUE)

smd_iptw <- bal_iptw$Balance %>%
  as.data.frame() %>%
  rownames_to_column("Variable") %>%
  filter(!str_detect(Variable, "prop.score|distance")) %>%
  select(Variable, Diff.Un, Diff.Adj) %>%
  mutate(across(c(Diff.Un, Diff.Adj), abs)) %>%
  rename(
    SMD_before = Diff.Un,
    SMD_after_IPTW = Diff.Adj
  )

write.csv(smd_iptw, "results/IPTW/SMD_IPTW.csv", row.names = FALSE)

LP_iptw <- love.plot(
  w.out.trim,
  thresholds = 0.1,
  var.order  = "unadjusted",
  abs        = TRUE,
  colors     = c("#1f78b4", "#33a02c")
)

pdf("results/Figures/love_plot_IPTW.pdf", height = 5, width = 7)
print(LP_iptw)
dev.off()

## Weight summary
weight_summary <- data_iptw %>%
  summarise(
    n = n(),
    min_weight = min(iptw_weight, na.rm = TRUE),
    p1_weight = quantile(iptw_weight, 0.01, na.rm = TRUE),
    median_weight = median(iptw_weight, na.rm = TRUE),
    mean_weight = mean(iptw_weight, na.rm = TRUE),
    p99_weight = quantile(iptw_weight, 0.99, na.rm = TRUE),
    max_weight = max(iptw_weight, na.rm = TRUE),
    ess = sum(iptw_weight)^2 / sum(iptw_weight^2)
  )

write.csv(weight_summary, "results/IPTW/weight_summary.csv", row.names = FALSE)

## ------------------------------------------------------------------
## 10. Baseline variables for table
## ------------------------------------------------------------------

baseline_vars <- c(
  "Age",
  "Sex",
  "Tumor.site",
  "cT",
  "cN",
  "Grade",
  "Lauren.classification",
  "Bormann.classification",
  "NACT.regimen",
  "NACT.cycles",
  "Surgical.procedure"
)

baseline_vars <- intersect(baseline_vars, names(data_ps))

baseline_cat_vars <- c(
  "Sex",
  "Tumor.site",
  "cT",
  "cN",
  "Grade",
  "Lauren.classification",
  "Bormann.classification",
  "NACT.regimen",
  "Surgical.procedure"
)

baseline_cat_vars <- intersect(baseline_cat_vars, baseline_vars)

nonnorm_vars <- c("Age", "NACT.cycles")
nonnorm_vars <- intersect(nonnorm_vars, baseline_vars)

## ------------------------------------------------------------------
## 11. Original baseline table: compareGroups style
## ------------------------------------------------------------------

formula_baseline <- as.formula(
  paste("treat ~", paste(baseline_vars, collapse = " + "))
)

cg_original <- compareGroups(
  formula_baseline,
  data = data_ps,
  method = 2
)

tab_original <- createTable(
  cg_original,
  show.all = TRUE,
  show.n = TRUE,
  show.p.overall = TRUE
)

export2csv(
  tab_original,
  file = "results/Tables/table1_original_compareGroups.csv"
)

## ------------------------------------------------------------------
## 12. PSM baseline table: compareGroups style
## ------------------------------------------------------------------

cg_psm <- compareGroups(
  formula_baseline,
  data = matched_df,
  method = 2
)

tab_psm <- createTable(
  cg_psm,
  show.all = TRUE,
  show.n = TRUE,
  show.p.overall = TRUE
)

export2csv(
  tab_psm,
  file = "results/Tables/table1_PSM_compareGroups.csv"
)

## ------------------------------------------------------------------
## 13. IPTW baseline table: survey + tableone style
## ------------------------------------------------------------------

design_iptw <- svydesign(
  ids = ~1,
  weights = ~iptw_weight,
  data = data_iptw
)

tab_iptw <- svyCreateTableOne(
  vars       = baseline_vars,
  strata     = "treat",
  data       = design_iptw,
  factorVars = baseline_cat_vars,
  test       = TRUE,
  smd        = TRUE
)

tab_iptw_mat <- print(
  tab_iptw,
  quote         = FALSE,
  noSpaces      = TRUE,
  showAllLevels = TRUE,
  printToggle   = FALSE,
  smd           = TRUE,
  nonnormal     = nonnorm_vars,
  contDigits    = 2,
  catDigits     = 2,
  smdDigits     = 3,
  pDigits       = 3
)

tab_iptw_df <- as.data.frame(tab_iptw_mat) %>%
  rownames_to_column("Variable")

write.csv(
  tab_iptw_df,
  "results/Tables/table1_IPTW_tableone.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 14. Original and PSM baseline tables using tableone as supplementary
## ------------------------------------------------------------------

tab_original_t1 <- CreateTableOne(
  vars       = baseline_vars,
  strata     = "treat",
  data       = data_ps,
  factorVars = baseline_cat_vars,
  test       = TRUE,
  smd        = TRUE
)

tab_original_t1_mat <- print(
  tab_original_t1,
  quote         = FALSE,
  noSpaces      = TRUE,
  showAllLevels = TRUE,
  printToggle   = FALSE,
  smd           = TRUE,
  nonnormal     = nonnorm_vars,
  contDigits    = 2,
  catDigits     = 2,
  smdDigits     = 3,
  pDigits       = 3
)

write.csv(
  as.data.frame(tab_original_t1_mat) %>% rownames_to_column("Variable"),
  "results/Tables/table1_original_tableone_with_SMD.csv",
  row.names = FALSE
)

tab_psm_t1 <- CreateTableOne(
  vars       = baseline_vars,
  strata     = "treat",
  data       = matched_df,
  factorVars = baseline_cat_vars,
  test       = TRUE,
  smd        = TRUE
)

tab_psm_t1_mat <- print(
  tab_psm_t1,
  quote         = FALSE,
  noSpaces      = TRUE,
  showAllLevels = TRUE,
  printToggle   = FALSE,
  smd           = TRUE,
  nonnormal     = nonnorm_vars,
  contDigits    = 2,
  catDigits     = 2,
  smdDigits     = 3,
  pDigits       = 3
)

write.csv(
  as.data.frame(tab_psm_t1_mat) %>% rownames_to_column("Variable"),
  "results/Tables/table1_PSM_tableone_with_SMD.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 15. Merge SMD from PSM and IPTW
## ------------------------------------------------------------------

smd_all <- smd_psm %>%
  full_join(smd_iptw, by = c("Variable", "SMD_before")) %>%
  arrange(desc(SMD_before))

write.csv(
  smd_all,
  "results/Tables/SMD_original_PSM_IPTW.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 16. Save key objects
## ------------------------------------------------------------------

saveRDS(m.out, "results/PSM/matchit_object.rds")
saveRDS(w.out.trim, "results/IPTW/weightit_object_trimmed.rds")
saveRDS(design_iptw, "results/IPTW/survey_design_iptw.rds")

## ------------------------------------------------------------------
## 17. Console summary
## ------------------------------------------------------------------

cat("\n============================================================\n")
cat("Analysis completed.\n")
cat("============================================================\n")

cat("\nOriginal cohort used for PSM/IPTW:\n")
print(table(data_ps$treat))

cat("\nPSM cohort:\n")
print(table(matched_df$treat))

cat("\nIPTW weight summary:\n")
print(weight_summary)

cat("\nMaximum SMD after PSM:\n")
print(max(smd_psm$SMD_after_PSM, na.rm = TRUE))

cat("\nMaximum SMD after IPTW:\n")
print(max(smd_iptw$SMD_after_IPTW, na.rm = TRUE))

cat("\nFiles saved under: results/\n")