################################################################################
# 05_exploratory_ACT_pathway_analysis.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# Exploratory pathway analysis:
# Surgical approach -> complications / perioperative mortality / ACT
# ACT -> DFS / OS
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(dplyr)
library(tibble)
library(stringr)
library(survival)
library(survey)
library(tableone)
library(openxlsx)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Exploratory_ACT_pathway", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import data
## ------------------------------------------------------------------

dat_original <- read.csv("results/analysis_dataset_before_psm_iptw.csv",
                         header = TRUE, check.names = TRUE)

dat_psm <- read.csv("results/PSM/matched_dataset.csv",
                    header = TRUE, check.names = TRUE)

dat_iptw <- read.csv("results/IPTW/data_after_iptw.csv",
                     header = TRUE, check.names = TRUE)

## ------------------------------------------------------------------
## 4. Data formatting
## ------------------------------------------------------------------

format_data <- function(dat) {
  
  dat$Surgical.approach <- factor(
    dat$Surgical.approach,
    levels = c("Open", "Laparoscopic")
  )
  dat$Surgical.approach <- relevel(dat$Surgical.approach, ref = "Open")
  
  dat$DFS <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS <- as.numeric(dat$OS)
  dat$OS.time <- as.numeric(dat$OS.time)
  
  numeric_vars <- c(
    "Age",
    "NACT.cycles",
    "Operation.time",
    "Positive.Lymph.Nodes.Count",
    "Total.Lymph.Nodes.Count"
  )
  
  numeric_vars <- intersect(numeric_vars, names(dat))
  dat[, numeric_vars] <- lapply(dat[, numeric_vars], as.numeric)
  
  factor_vars <- c(
    "Sex",
    "Tumor.site",
    "cT",
    "cN",
    "Grade",
    "Lauren.classification",
    "Bormann.classification",
    "NACT.regimen",
    "Surgical.procedure",
    "ypT",
    "ypN",
    "Mandard.TRG",
    "MPR",
    "pCR",
    "Margin",
    "Nerve.Invasion",
    "Lymphovascular.Tumor.Thrombus",
    "ACT",
    "ACT.regimen",
    "Complication",
    "CD",
    "Perioperative.mortality"
  )
  
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  
  dat <- dat %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(DFS), !is.na(DFS.time), !is.na(OS), !is.na(OS.time))
  
  return(dat)
}

dat_original <- format_data(dat_original)
dat_psm      <- format_data(dat_psm)
dat_iptw     <- format_data(dat_iptw)

## ------------------------------------------------------------------
## 5. Create complication / ACT variables
## ------------------------------------------------------------------

create_pathway_vars <- function(dat) {
  
  dat <- dat %>%
    mutate(
      Complication_any = case_when(
        Complication == "No" ~ 0,
        is.na(Complication) ~ NA_real_,
        TRUE ~ 1
      ),
      
      Severe_complication = case_when(
        CD == "Higher than grade 3" ~ 1,
        CD %in% c("Lower than grade 3", "No") ~ 0,
        is.na(CD) ~ NA_real_,
        TRUE ~ NA_real_
      ),
      
      Perioperative_mortality_any = case_when(
        Perioperative.mortality %in% c("Yes", "1", 1) ~ 1,
        Perioperative.mortality %in% c("No", "0", 0) ~ 0,
        is.na(Perioperative.mortality) ~ NA_real_,
        TRUE ~ as.numeric(as.character(Perioperative.mortality))
      ),
      
      ACT_received = case_when(
        ACT %in% c("Yes", "1", 1) ~ 1,
        ACT %in% c("No", "0", 0) ~ 0,
        !is.na(ACT.regimen) & ACT.regimen != "No" ~ 1,
        ACT.regimen == "No" ~ 0,
        is.na(ACT) & is.na(ACT.regimen) ~ NA_real_,
        TRUE ~ NA_real_
      )
    )
  
  dat$Complication_any <- factor(
    dat$Complication_any,
    levels = c(0, 1),
    labels = c("No", "Yes")
  )
  
  dat$Severe_complication <- factor(
    dat$Severe_complication,
    levels = c(0, 1),
    labels = c("No", "Yes")
  )
  
  dat$Perioperative_mortality_any <- factor(
    dat$Perioperative_mortality_any,
    levels = c(0, 1),
    labels = c("No", "Yes")
  )
  
  dat$ACT_received <- factor(
    dat$ACT_received,
    levels = c(0, 1),
    labels = c("No", "Yes")
  )
  
  return(dat)
}

dat_original <- create_pathway_vars(dat_original)
dat_psm      <- create_pathway_vars(dat_psm)
dat_iptw     <- create_pathway_vars(dat_iptw)

## ------------------------------------------------------------------
## 6. Check constructed variables
## ------------------------------------------------------------------

cat("\nOriginal cohort complication check:\n")
print(table(dat_original$Complication, useNA = "ifany"))
print(table(dat_original$CD, useNA = "ifany"))
print(table(dat_original$Complication_any, useNA = "ifany"))
print(table(dat_original$Severe_complication, useNA = "ifany"))

cat("\nOriginal cohort ACT check:\n")
print(table(dat_original$ACT, useNA = "ifany"))
print(table(dat_original$ACT.regimen, useNA = "ifany"))
print(table(dat_original$ACT_received, useNA = "ifany"))

## ------------------------------------------------------------------
## 7. Descriptive pathway tables
## ------------------------------------------------------------------

make_descriptive_table <- function(dat, cohort_name, weight_var = NULL) {
  
  vars <- c(
    "Complication_any",
    "Severe_complication",
    "Perioperative_mortality_any",
    "ACT_received",
    "ACT.regimen"
  )
  
  vars <- intersect(vars, names(dat))
  
  factor_vars <- vars
  
  if (is.null(weight_var)) {
    
    tab <- CreateTableOne(
      vars = vars,
      strata = "Surgical.approach",
      data = dat,
      factorVars = factor_vars,
      test = TRUE
    )
    
    tab_mat <- print(
      tab,
      showAllLevels = TRUE,
      printToggle = FALSE,
      quote = FALSE,
      noSpaces = TRUE,
      catDigits = 2,
      pDigits = 3
    )
    
  } else {
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = dat
    )
    
    tab <- svyCreateTableOne(
      vars = vars,
      strata = "Surgical.approach",
      data = design,
      factorVars = factor_vars,
      test = TRUE
    )
    
    tab_mat <- print(
      tab,
      showAllLevels = TRUE,
      printToggle = FALSE,
      quote = FALSE,
      noSpaces = TRUE,
      catDigits = 2,
      pDigits = 3
    )
  }
  
  tab_df <- as.data.frame(tab_mat) %>%
    rownames_to_column("Variable") %>%
    mutate(Cohort = cohort_name) %>%
    select(Cohort, Variable, everything())
  
  return(tab_df)
}

descriptive_results <- bind_rows(
  make_descriptive_table(dat_original, "Original"),
  make_descriptive_table(dat_psm, "PSM"),
  make_descriptive_table(dat_iptw, "IPTW", weight_var = "iptw_weight")
)

write.csv(
  descriptive_results,
  "results/Exploratory_ACT_pathway/pathway_descriptive_tables.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 8. Logistic models:
## Surgical approach -> complications / mortality / ACT
## ------------------------------------------------------------------

extract_logistic_result <- function(fit,
                                    coef_name = "Surgical.approachLaparoscopic",
                                    cohort,
                                    outcome,
                                    model_name) {
  
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    return(data.frame(
      Cohort = cohort,
      Outcome = outcome,
      Model = model_name,
      OR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    ))
  }
  
  OR <- exp(coef(fit)[coef_name])
  CI <- exp(confint(fit)[coef_name, ])
  P <- s$coefficients[coef_name, ncol(s$coefficients)]
  
  out <- data.frame(
    Cohort = cohort,
    Outcome = outcome,
    Model = model_name,
    OR = as.numeric(OR),
    Lower95CI = as.numeric(CI[1]),
    Upper95CI = as.numeric(CI[2]),
    P.value = as.numeric(P),
    stringsAsFactors = FALSE
  )
  
  return(out)
}

run_logistic <- function(dat,
                         cohort,
                         outcome,
                         model_type = c("Original", "PSM", "IPTW"),
                         weight_var = NULL) {
  
  model_type <- match.arg(model_type)
  
  dat_use <- dat %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(.data[[outcome]]))
  
  event_n <- sum(dat_use[[outcome]] == "Yes", na.rm = TRUE)
  
  if (event_n < 5) {
    return(data.frame(
      Cohort = cohort,
      Outcome = outcome,
      Model = paste0(model_type, " logistic"),
      OR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    ))
  }
  
  fml <- as.formula(
    paste0(outcome, " ~ Surgical.approach")
  )
  
  if (model_type == "Original") {
    
    fit <- glm(fml, data = dat_use, family = binomial())
    
    out <- extract_logistic_result(
      fit = fit,
      cohort = cohort,
      outcome = outcome,
      model_name = "Original logistic"
    )
    
  } else if (model_type == "PSM") {
    
    fit <- glm(fml, data = dat_use, family = binomial())
    
    out <- extract_logistic_result(
      fit = fit,
      cohort = cohort,
      outcome = outcome,
      model_name = "PSM logistic"
    )
    
  } else if (model_type == "IPTW") {
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = dat_use
    )
    
    fit <- svyglm(fml, design = design, family = quasibinomial())
    
    out <- extract_logistic_result(
      fit = fit,
      cohort = cohort,
      outcome = outcome,
      model_name = "IPTW weighted logistic"
    )
  }
  
  return(out)
}

logistic_outcomes <- c(
  "Complication_any",
  "Severe_complication",
  "Perioperative_mortality_any",
  "ACT_received"
)

logistic_results <- bind_rows(
  
  lapply(logistic_outcomes, function(x) {
    run_logistic(dat_original, "Original", x, model_type = "Original")
  }),
  
  lapply(logistic_outcomes, function(x) {
    run_logistic(dat_psm, "PSM", x, model_type = "PSM")
  }),
  
  lapply(logistic_outcomes, function(x) {
    run_logistic(dat_iptw, "IPTW", x, model_type = "IPTW", weight_var = "iptw_weight")
  })
)

logistic_results <- logistic_results %>%
  mutate(
    OR_CI = ifelse(
      is.na(OR),
      NA,
      paste0(
        sprintf("%.2f", OR),
        " (",
        sprintf("%.2f", Lower95CI),
        "-",
        sprintf("%.2f", Upper95CI),
        ")"
      )
    ),
    P.value.formatted = case_when(
      is.na(P.value) ~ NA_character_,
      P.value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", P.value)
    )
  )

write.csv(
  logistic_results,
  "results/Exploratory_ACT_pathway/logistic_surgical_approach_to_complication_ACT.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 9. ACT -> DFS / OS survival analysis
## ------------------------------------------------------------------

extract_cox_result <- function(fit,
                               coef_name,
                               cohort,
                               endpoint,
                               model_name) {
  
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    return(data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = model_name,
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    ))
  }
  
  if (inherits(fit, "svycoxph")) {
    
    HR <- exp(coef(fit)[coef_name])
    CI <- exp(confint(fit)[coef_name, ])
    P  <- s$coefficients[coef_name, "Pr(>|z|)"]
    
  } else {
    
    HR <- s$conf.int[coef_name, "exp(coef)"]
    CI <- c(
      s$conf.int[coef_name, "lower .95"],
      s$conf.int[coef_name, "upper .95"]
    )
    P <- s$coefficients[coef_name, "Pr(>|z|)"]
  }
  
  out <- data.frame(
    Cohort = cohort,
    Endpoint = endpoint,
    Model = model_name,
    HR = as.numeric(HR),
    Lower95CI = as.numeric(CI[1]),
    Upper95CI = as.numeric(CI[2]),
    P.value = as.numeric(P),
    stringsAsFactors = FALSE
  )
  
  return(out)
}

run_ACT_survival <- function(dat,
                             cohort,
                             endpoint = c("DFS", "OS"),
                             model_type = c("Original", "PSM", "IPTW"),
                             weight_var = NULL) {
  
  endpoint <- match.arg(endpoint)
  model_type <- match.arg(model_type)
  
  if (endpoint == "DFS") {
    time_var <- "DFS.time"
    event_var <- "DFS"
  } else {
    time_var <- "OS.time"
    event_var <- "OS"
  }
  
  dat_use <- dat %>%
    filter(!is.na(ACT_received)) %>%
    filter(!is.na(.data[[time_var]]), !is.na(.data[[event_var]]))
  
  dat_use$ACT_received <- factor(
    dat_use$ACT_received,
    levels = c("No", "Yes")
  )
  dat_use$ACT_received <- relevel(dat_use$ACT_received, ref = "No")
  
  if (sum(dat_use$ACT_received == "No", na.rm = TRUE) < 10 |
      sum(dat_use$ACT_received == "Yes", na.rm = TRUE) < 10) {
    
    return(data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = paste0(model_type, " ACT survival Cox"),
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    ))
  }
  
  fml <- as.formula(
    paste0("Surv(", time_var, ", ", event_var, ") ~ ACT_received")
  )
  
  if (model_type == "Original") {
    
    fit <- coxph(fml, data = dat_use)
    
    out <- extract_cox_result(
      fit = fit,
      coef_name = "ACT_receivedYes",
      cohort = cohort,
      endpoint = endpoint,
      model_name = "Original Cox: ACT yes vs no"
    )
    
  } else if (model_type == "PSM") {
    
    fml_psm <- as.formula(
      paste0("Surv(", time_var, ", ", event_var, ") ~ ACT_received + cluster(subclass)")
    )
    
    fit <- coxph(fml_psm, data = dat_use)
    
    out <- extract_cox_result(
      fit = fit,
      coef_name = "ACT_receivedYes",
      cohort = cohort,
      endpoint = endpoint,
      model_name = "PSM Cox: ACT yes vs no"
    )
    
  } else if (model_type == "IPTW") {
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = dat_use
    )
    
    fit <- svycoxph(fml, design = design)
    
    out <- extract_cox_result(
      fit = fit,
      coef_name = "ACT_receivedYes",
      cohort = cohort,
      endpoint = endpoint,
      model_name = "IPTW weighted Cox: ACT yes vs no"
    )
  }
  
  return(out)
}

ACT_survival_results <- bind_rows(
  
  run_ACT_survival(dat_original, "Original", "DFS", "Original"),
  run_ACT_survival(dat_original, "Original", "OS",  "Original"),
  
  run_ACT_survival(dat_psm, "PSM", "DFS", "PSM"),
  run_ACT_survival(dat_psm, "PSM", "OS",  "PSM"),
  
  run_ACT_survival(dat_iptw, "IPTW", "DFS", "IPTW", weight_var = "iptw_weight"),
  run_ACT_survival(dat_iptw, "IPTW", "OS",  "IPTW", weight_var = "iptw_weight")
)

ACT_survival_results <- ACT_survival_results %>%
  mutate(
    HR_CI = ifelse(
      is.na(HR),
      NA,
      paste0(
        sprintf("%.2f", HR),
        " (",
        sprintf("%.2f", Lower95CI),
        "-",
        sprintf("%.2f", Upper95CI),
        ")"
      )
    ),
    P.value.formatted = case_when(
      is.na(P.value) ~ NA_character_,
      P.value < 0.001 ~ "<0.001",
      TRUE ~ sprintf("%.3f", P.value)
    )
  )

write.csv(
  ACT_survival_results,
  "results/Exploratory_ACT_pathway/ACT_survival_results.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 10. Export all results to Excel
## ------------------------------------------------------------------

wb <- createWorkbook()

addWorksheet(wb, "Descriptive")
writeData(wb, "Descriptive", descriptive_results)

addWorksheet(wb, "Logistic")
writeData(wb, "Logistic", logistic_results)

addWorksheet(wb, "ACT_survival")
writeData(wb, "ACT_survival", ACT_survival_results)

saveWorkbook(
  wb,
  "results/Exploratory_ACT_pathway/exploratory_ACT_pathway_results.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 11. Print summary
## ------------------------------------------------------------------

cat("\nAnalysis completed.\n")
cat("\nFiles saved in:\n")
cat("results/Exploratory_ACT_pathway/\n")

cat("\nKey outputs:\n")
cat("1. pathway_descriptive_tables.csv\n")
cat("2. logistic_surgical_approach_to_complication_ACT.csv\n")
cat("3. ACT_survival_results.csv\n")
cat("4. exploratory_ACT_pathway_results.xlsx\n")

cat("\nConstructed variable checks:\n")
cat("\nOriginal Complication_any:\n")
print(table(dat_original$Complication_any, useNA = "ifany"))

cat("\nOriginal Severe_complication:\n")
print(table(dat_original$Severe_complication, useNA = "ifany"))

cat("\nOriginal ACT_received:\n")
print(table(dat_original$ACT_received, useNA = "ifany"))