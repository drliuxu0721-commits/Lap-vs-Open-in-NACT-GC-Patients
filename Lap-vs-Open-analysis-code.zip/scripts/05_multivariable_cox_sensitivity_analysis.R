################################################################################
# 05_multivariable_cox_sensitivity_analysis.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# Multivariable-adjusted Cox sensitivity analysis for DFS/OS
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(survival)
library(survey)
library(dplyr)
library(tibble)
library(openxlsx)
library(stringr)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Survival", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import data
## ------------------------------------------------------------------

dat_original <- read.csv("results/analysis_dataset_before_psm_iptw.csv",
                         header = TRUE, check.names = TRUE)

dat_psm <- read.csv("results/PSM/matched_dataset.csv",
                    header = TRUE, check.names = TRUE)

dat_iptw <- read.csv("results/IPTW/data_after_iptw.csv",
                     header = TRUE, check.names = TRUE)

## ------------------------------------------------------------------
## 4. Data formatting
## ------------------------------------------------------------------

format_data <- function(dat) {
  
  dat$Surgical.approach <- factor(
    dat$Surgical.approach,
    levels = c("Open", "Laparoscopic")
  )
  
  dat$Surgical.approach <- relevel(dat$Surgical.approach, ref = "Open")
  
  dat$DFS <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS <- as.numeric(dat$OS)
  dat$OS.time <- as.numeric(dat$OS.time)
  
  numeric_vars <- c(
    "Age",
    "NACT.cycles",
    "Operation.time",
    "Positive.Lymph.Nodes.Count",
    "Total.Lymph.Nodes.Count"
  )
  
  numeric_vars <- intersect(numeric_vars, names(dat))
  dat[, numeric_vars] <- lapply(dat[, numeric_vars], as.numeric)
  
  factor_vars <- c(
    "Sex",
    "Tumor.site",
    "cT",
    "cN",
    "Grade",
    "Lauren.classification",
    "Bormann.classification",
    "NACT.regimen",
    "Surgical.procedure",
    "ypT",
    "ypN",
    "Mandard.TRG",
    "MPR",
    "pCR",
    "Margin",
    "Nerve.Invasion",
    "Lymphovascular.Tumor.Thrombus",
    "ACT",
    "ACT.regimen",
    "Complication",
    "Perioperative.mortality"
  )
  
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  
  dat <- dat %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(DFS), !is.na(DFS.time), !is.na(OS), !is.na(OS.time))
  
  return(dat)
}

dat_original <- format_data(dat_original)
dat_psm      <- format_data(dat_psm)
dat_iptw     <- format_data(dat_iptw)

## ------------------------------------------------------------------
## 5. Define adjustment variables
## ------------------------------------------------------------------

## Primary model: preoperative baseline variables only
adj_preop <- c(
  "Age",
  "Sex",
  "Tumor.site",
  "cT",
  "cN",
  "Grade",
  "Lauren.classification",
  "Bormann.classification",
  "NACT.regimen",
  "NACT.cycles",
  "Surgical.procedure"
)

## Limited postoperative sensitivity model
## Only used in Original and PSM cohorts.
## Not used in IPTW to avoid model instability from sparse weighted strata.
adj_limited_postop <- c(
  adj_preop,
  "ypT",
  "ypN",
  "Mandard.TRG",
  "ACT"
)

## IPTW residual adjustment model
## Only baseline variables are used.
adj_iptw_limited <- c(
  "Age",
  "Sex",
  "cT",
  "cN",
  "NACT.regimen",
  "Surgical.procedure"
)

## ------------------------------------------------------------------
## 6. Helper functions
## ------------------------------------------------------------------

format_p <- function(p) {
  ifelse(
    is.na(p),
    "NA",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

extract_cox_result <- function(fit,
                               coef_name = "Surgical.approachLaparoscopic",
                               cohort,
                               endpoint,
                               model_name) {
  
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    return(data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = model_name,
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    ))
  }
  
  if (inherits(fit, "svycoxph")) {
    
    HR <- exp(coef(fit)[coef_name])
    CI <- exp(confint(fit)[coef_name, ])
    P  <- s$coefficients[coef_name, "Pr(>|z|)"]
    
    out <- data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = model_name,
      HR = as.numeric(HR),
      Lower95CI = as.numeric(CI[1]),
      Upper95CI = as.numeric(CI[2]),
      P.value = as.numeric(P),
      stringsAsFactors = FALSE
    )
    
  } else {
    
    out <- data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = model_name,
      HR = as.numeric(s$conf.int[coef_name, "exp(coef)"]),
      Lower95CI = as.numeric(s$conf.int[coef_name, "lower .95"]),
      Upper95CI = as.numeric(s$conf.int[coef_name, "upper .95"]),
      P.value = as.numeric(s$coefficients[coef_name, "Pr(>|z|)"]),
      stringsAsFactors = FALSE
    )
  }
  
  return(out)
}

complete_case_data <- function(dat, vars) {
  
  vars <- intersect(vars, names(dat))
  
  dat %>%
    filter(if_all(all_of(vars), ~ !is.na(.)))
}

make_model_formula <- function(time_var,
                               event_var,
                               covariates,
                               cluster_var = NULL) {
  
  rhs <- paste(c("Surgical.approach", covariates), collapse = " + ")
  
  if (!is.null(cluster_var)) {
    rhs <- paste0(rhs, " + cluster(", cluster_var, ")")
  }
  
  as.formula(
    paste0("Surv(", time_var, ", ", event_var, ") ~ ", rhs)
  )
}

run_multivariable_cox <- function(dat,
                                  cohort,
                                  endpoint = c("DFS", "OS"),
                                  model_type = c("Original", "PSM", "IPTW"),
                                  adj_vars,
                                  adj_label,
                                  weight_var = NULL) {
  
  endpoint <- match.arg(endpoint)
  model_type <- match.arg(model_type)
  
  if (endpoint == "DFS") {
    time_var <- "DFS.time"
    event_var <- "DFS"
  } else {
    time_var <- "OS.time"
    event_var <- "OS"
  }
  
  base_vars <- c(
    "Surgical.approach",
    time_var,
    event_var,
    adj_vars
  )
  
  if (model_type == "PSM") {
    base_vars <- c(base_vars, "subclass")
  }
  
  if (model_type == "IPTW") {
    base_vars <- c(base_vars, weight_var)
  }
  
  base_vars <- intersect(base_vars, names(dat))
  adj_vars_use <- intersect(adj_vars, names(dat))
  
  dat_cc <- complete_case_data(dat, base_vars)
  
  n_open <- sum(dat_cc$Surgical.approach == "Open", na.rm = TRUE)
  n_lap  <- sum(dat_cc$Surgical.approach == "Laparoscopic", na.rm = TRUE)
  events <- sum(dat_cc[[event_var]] == 1, na.rm = TRUE)
  
  if (n_open < 10 | n_lap < 10 | events < 10) {
    
    out <- data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = paste0(model_type, " multivariable Cox: ", adj_label),
      N = nrow(dat_cc),
      Open_N = n_open,
      Laparoscopic_N = n_lap,
      Events = events,
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    )
    
    return(out)
  }
  
  fit <- NULL
  
  if (model_type == "Original") {
    
    fml <- make_model_formula(
      time_var = time_var,
      event_var = event_var,
      covariates = adj_vars_use
    )
    
    fit <- tryCatch(
      coxph(fml, data = dat_cc),
      error = function(e) NULL
    )
    
    model_name <- paste0("Original multivariable Cox: ", adj_label)
    
  } else if (model_type == "PSM") {
    
    fml <- make_model_formula(
      time_var = time_var,
      event_var = event_var,
      covariates = adj_vars_use,
      cluster_var = "subclass"
    )
    
    fit <- tryCatch(
      coxph(fml, data = dat_cc),
      error = function(e) NULL
    )
    
    model_name <- paste0("PSM multivariable Cox: ", adj_label)
    
  } else if (model_type == "IPTW") {
    
    fml <- make_model_formula(
      time_var = time_var,
      event_var = event_var,
      covariates = adj_vars_use
    )
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = dat_cc
    )
    
    fit <- tryCatch(
      svycoxph(fml, design = design),
      error = function(e) NULL
    )
    
    model_name <- paste0("IPTW weighted Cox: ", adj_label)
  }
  
  if (is.null(fit)) {
    
    out <- data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = model_name,
      N = nrow(dat_cc),
      Open_N = n_open,
      Laparoscopic_N = n_lap,
      Events = events,
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    )
    
    return(out)
  }
  
  out <- extract_cox_result(
    fit = fit,
    cohort = cohort,
    endpoint = endpoint,
    model_name = model_name
  )
  
  out <- out %>%
    mutate(
      N = nrow(dat_cc),
      Open_N = n_open,
      Laparoscopic_N = n_lap,
      Events = events
    ) %>%
    select(
      Cohort,
      Endpoint,
      Model,
      N,
      Open_N,
      Laparoscopic_N,
      Events,
      HR,
      Lower95CI,
      Upper95CI,
      P.value
    )
  
  return(out)
}

## ------------------------------------------------------------------
## 7. Run multivariable-adjusted sensitivity analyses
## ------------------------------------------------------------------

multi_results <- bind_rows(
  
  ## Original cohort: preoperative adjustment
  run_multivariable_cox(
    dat = dat_original,
    cohort = "Original",
    endpoint = "DFS",
    model_type = "Original",
    adj_vars = adj_preop,
    adj_label = "preoperative variables"
  ),
  
  run_multivariable_cox(
    dat = dat_original,
    cohort = "Original",
    endpoint = "OS",
    model_type = "Original",
    adj_vars = adj_preop,
    adj_label = "preoperative variables"
  ),
  
  ## Original cohort: limited postoperative sensitivity
  run_multivariable_cox(
    dat = dat_original,
    cohort = "Original",
    endpoint = "DFS",
    model_type = "Original",
    adj_vars = adj_limited_postop,
    adj_label = "preoperative + limited postoperative variables"
  ),
  
  run_multivariable_cox(
    dat = dat_original,
    cohort = "Original",
    endpoint = "OS",
    model_type = "Original",
    adj_vars = adj_limited_postop,
    adj_label = "preoperative + limited postoperative variables"
  ),
  
  ## PSM cohort: preoperative adjustment
  run_multivariable_cox(
    dat = dat_psm,
    cohort = "PSM",
    endpoint = "DFS",
    model_type = "PSM",
    adj_vars = adj_preop,
    adj_label = "preoperative variables"
  ),
  
  run_multivariable_cox(
    dat = dat_psm,
    cohort = "PSM",
    endpoint = "OS",
    model_type = "PSM",
    adj_vars = adj_preop,
    adj_label = "preoperative variables"
  ),
  
  ## PSM cohort: limited postoperative sensitivity
  run_multivariable_cox(
    dat = dat_psm,
    cohort = "PSM",
    endpoint = "DFS",
    model_type = "PSM",
    adj_vars = adj_limited_postop,
    adj_label = "preoperative + limited postoperative variables"
  ),
  
  run_multivariable_cox(
    dat = dat_psm,
    cohort = "PSM",
    endpoint = "OS",
    model_type = "PSM",
    adj_vars = adj_limited_postop,
    adj_label = "preoperative + limited postoperative variables"
  ),
  
  ## IPTW cohort: weighted only
  run_multivariable_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "DFS",
    model_type = "IPTW",
    adj_vars = character(0),
    adj_label = "weighted only",
    weight_var = "iptw_weight"
  ),
  
  run_multivariable_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "OS",
    model_type = "IPTW",
    adj_vars = character(0),
    adj_label = "weighted only",
    weight_var = "iptw_weight"
  ),
  
  ## IPTW cohort: weighted + limited residual baseline adjustment
  run_multivariable_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "DFS",
    model_type = "IPTW",
    adj_vars = adj_iptw_limited,
    adj_label = "weighted + limited preoperative adjustment",
    weight_var = "iptw_weight"
  ),
  
  run_multivariable_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "OS",
    model_type = "IPTW",
    adj_vars = adj_iptw_limited,
    adj_label = "weighted + limited preoperative adjustment",
    weight_var = "iptw_weight"
  )
)

## ------------------------------------------------------------------
## 8. Format results
## ------------------------------------------------------------------

multi_results <- multi_results %>%
  mutate(
    HR_CI = ifelse(
      is.na(HR),
      NA,
      paste0(
        sprintf("%.2f", HR),
        " (",
        sprintf("%.2f", Lower95CI),
        "-",
        sprintf("%.2f", Upper95CI),
        ")"
      )
    ),
    P.value.formatted = format_p(P.value)
  )

print(multi_results)

## ------------------------------------------------------------------
## 9. Export results
## ------------------------------------------------------------------

write.csv(
  multi_results,
  "results/Survival/multivariable_cox_sensitivity_results.csv",
  row.names = FALSE
)

wb <- createWorkbook()

addWorksheet(wb, "Multivariable Cox")
writeData(wb, "Multivariable Cox", multi_results)

addWorksheet(wb, "Adjustment variables")
writeData(
  wb,
  "Adjustment variables",
  data.frame(
    Model = c(
      "Preoperative model",
      "Limited postoperative model",
      "IPTW limited residual model"
    ),
    Variables = c(
      paste(adj_preop, collapse = ", "),
      paste(adj_limited_postop, collapse = ", "),
      paste(adj_iptw_limited, collapse = ", ")
    )
  )
)

saveWorkbook(
  wb,
  "results/Survival/multivariable_cox_sensitivity_results.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 10. Console summary
## ------------------------------------------------------------------

cat("\nFinished multivariable Cox sensitivity analysis.\n")

cat("\nOutput files:\n")
cat("1. results/Survival/multivariable_cox_sensitivity_results.csv\n")
cat("2. results/Survival/multivariable_cox_sensitivity_results.xlsx\n")

cat("\nPrimary adjusted variables:\n")
cat(paste(adj_preop, collapse = ", "), "\n")

cat("\nLimited postoperative sensitivity variables:\n")
cat(paste(adj_limited_postop, collapse = ", "), "\n")

cat("\nIPTW limited residual adjustment variables:\n")
cat(paste(adj_iptw_limited, collapse = ", "), "\n")