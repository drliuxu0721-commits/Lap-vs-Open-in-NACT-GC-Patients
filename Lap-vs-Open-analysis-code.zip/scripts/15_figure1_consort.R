################################################################################
# 15_figure1_consort.R
# Figure 1 — graphical study flow diagram (IJC-style).
# The editable source is results/Panels/Figure1_CONSORT.svg (hand-authored:
# navy VS header, green exclusion box, 3 color-coded cohort boxes with
# red/blue patient icons, 2 blue-bordered outcome containers).
# This script just renders that SVG to publication PDF + high-res PNG.
# Numbers verified from the raw-data exclusion cascade (see CONSORT).
################################################################################

library(rsvg)

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
svg_in   <- file.path(root_dir, "results/Panels/Figure1_CONSORT.svg")

rsvg_pdf(svg_in, file.path(root_dir, "results/Panels/Figure1_CONSORT.pdf"))
rsvg_png(svg_in, file.path(root_dir, "results/Panels/Figure1_CONSORT.png"),
         width = 2760)   # ~300 dpi at the 9.2-inch canvas width

cat("Figure 1 rendered from SVG to PDF + PNG (results/Panels/).\n")
