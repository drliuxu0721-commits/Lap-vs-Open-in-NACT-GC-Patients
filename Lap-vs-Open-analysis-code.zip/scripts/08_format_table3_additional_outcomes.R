################################################################################
# 07_format_table3_additional_outcomes.R
# Format Table 3: additional short-term, ACT, and textbook outcomes
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(dplyr)
library(tibble)
library(stringr)
library(openxlsx)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Tables", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import results
## ------------------------------------------------------------------

file_in <- "results/Additional_Outcomes/additional_outcomes_TO_ACT_complication.xlsx"

if (!file.exists(file_in)) {
  file_in <- "additional_outcomes_TO_ACT_complication.xlsx"
}

sheet_names <- getSheetNames(file_in)
print(sheet_names)

## 自动识别 sheet
desc_sheet <- sheet_names[str_detect(
  tolower(sheet_names),
  "desc|descriptive|pathway|table"
)][1]

logistic_sheet <- sheet_names[str_detect(
  tolower(sheet_names),
  "logistic|regression"
)][1]

procedure_sheet <- sheet_names[str_detect(
  tolower(sheet_names),
  "procedure|stratified|subgroup"
)][1]

## 如果自动识别失败，就按顺序读取
if (is.na(desc_sheet)) {
  desc_sheet <- sheet_names[1]
}

if (is.na(logistic_sheet)) {
  logistic_sheet <- sheet_names[2]
}

if (is.na(procedure_sheet)) {
  procedure_sheet <- sheet_names[3]
}

cat("\nUsing sheets:\n")
cat("descriptive:", desc_sheet, "\n")
cat("logistic:", logistic_sheet, "\n")
cat("procedure:", procedure_sheet, "\n")

desc_results <- read.xlsx(file_in, sheet = desc_sheet)
logistic_results <- read.xlsx(file_in, sheet = logistic_sheet)
procedure_results <- read.xlsx(file_in, sheet = procedure_sheet)

cat("\nColumns in desc_results:\n")
print(names(desc_results))

cat("\nColumns in logistic_results:\n")
print(names(logistic_results))

cat("\nColumns in procedure_results:\n")
print(names(procedure_results))

## ------------------------------------------------------------------
## 4. Format P value
## ------------------------------------------------------------------

format_p <- function(p) {
  p <- as.numeric(p)
  ifelse(
    is.na(p),
    "",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

## ------------------------------------------------------------------
## 5. Outcome labels
## ------------------------------------------------------------------

outcome_label <- c(
  "any_complication"     = "Any postoperative complication",
  "major_complication"   = "Major complication, Clavien-Dindo grade III or higher",
  "ACT_receipt"          = "Receipt of adjuvant chemotherapy",
  "textbook_outcome"     = "Textbook outcome",
  "textbook_outcome_ACT" = "Textbook outcome plus adjuvant chemotherapy receipt"
)

outcome_order <- names(outcome_label)

## ------------------------------------------------------------------
## 6. Main integrated Table 3
## ------------------------------------------------------------------

desc_main <- desc_results %>%
  filter(Outcome %in% outcome_order) %>%
  mutate(
    Outcome = factor(Outcome, levels = outcome_order),
    Outcome_label = outcome_label[as.character(Outcome)],
    P.value = format_p(P.value)
  ) %>%
  arrange(Outcome)

table3 <- desc_main %>%
  select(Cohort, Outcome, Outcome_label, Open, Laparoscopic, P.value) %>%
  tidyr::pivot_wider(
    id_cols = c(Outcome, Outcome_label),
    names_from = Cohort,
    values_from = c(Open, Laparoscopic, P.value),
    names_glue = "{Cohort}_{.value}"
  ) %>%
  transmute(
    Outcome = Outcome_label,
    `Original Open` = Original_Open,
    `Original Laparoscopic` = Original_Laparoscopic,
    `Original P value` = Original_P.value,
    `PSM Open` = PSM_Open,
    `PSM Laparoscopic` = PSM_Laparoscopic,
    `PSM P value` = PSM_P.value,
    `IPTW Open` = IPTW_Open,
    `IPTW Laparoscopic` = IPTW_Laparoscopic,
    `IPTW P value` = IPTW_P.value
  )

## ------------------------------------------------------------------
## 7. Logistic regression table
## ------------------------------------------------------------------

logistic_table <- logistic_results %>%
  filter(Outcome %in% outcome_order) %>%
  filter(Cohort %in% c("Original", "IPTW")) %>%
  mutate(
    Outcome = factor(Outcome, levels = outcome_order),
    Outcome_label = outcome_label[as.character(Outcome)],
    OR_CI = paste0(
      sprintf("%.2f", as.numeric(OR)),
      " (",
      sprintf("%.2f", as.numeric(Lower95CI)),
      "-",
      sprintf("%.2f", as.numeric(Upper95CI)),
      ")"
    ),
    P.value = format_p(P.value)
  ) %>%
  arrange(Outcome, Cohort) %>%
  select(
    Cohort,
    Outcome = Outcome_label,
    N,
    Open_N,
    Laparoscopic_N,
    Events,
    OR_CI,
    P.value
  )

## ------------------------------------------------------------------
## 8. Procedure-stratified supplementary table
## ------------------------------------------------------------------

procedure_table <- procedure_results %>%
  filter(Outcome %in% c(
    "any_complication",
    "major_complication",
    "ACT_receipt",
    "textbook_outcome"
  )) %>%
  mutate(
    Outcome = factor(Outcome, levels = outcome_order),
    Outcome_label = outcome_label[as.character(Outcome)],
    P.value = format_p(P.value)
  ) %>%
  arrange(Cohort, Outcome) %>%
  select(
    Cohort,
    Outcome = Outcome_label,
    Open,
    Laparoscopic,
    P.value
  )

## ------------------------------------------------------------------
## 9. Export Excel
## ------------------------------------------------------------------

wb <- createWorkbook()

addWorksheet(wb, "Table3_main")
writeData(wb, "Table3_main", table3)

addWorksheet(wb, "Logistic_original_IPTW")
writeData(wb, "Logistic_original_IPTW", logistic_table)

addWorksheet(wb, "Supplement_procedure")
writeData(wb, "Supplement_procedure", procedure_table)

## Style
header_style <- createStyle(
  textDecoration = "bold",
  halign = "center",
  valign = "center",
  border = "Bottom"
)

body_style <- createStyle(
  valign = "center",
  wrapText = TRUE
)

for (s in names(wb)) {
  addStyle(
    wb,
    sheet = s,
    style = header_style,
    rows = 1,
    cols = 1:ncol(readWorkbook(wb, sheet = s)),
    gridExpand = TRUE
  )
  
  addStyle(
    wb,
    sheet = s,
    style = body_style,
    rows = 2:(nrow(readWorkbook(wb, sheet = s)) + 1),
    cols = 1:ncol(readWorkbook(wb, sheet = s)),
    gridExpand = TRUE
  )
  
  setColWidths(wb, sheet = s, cols = 1:ncol(readWorkbook(wb, sheet = s)), widths = "auto")
  freezePane(wb, sheet = s, firstRow = TRUE)
}

saveWorkbook(
  wb,
  file = "results/Tables/Table3_additional_outcomes_integrated.xlsx",
  overwrite = TRUE
)

write.csv(
  table3,
  "results/Tables/Table3_additional_outcomes_integrated.csv",
  row.names = FALSE
)

write.csv(
  logistic_table,
  "results/Tables/Table3_logistic_original_IPTW.csv",
  row.names = FALSE
)

write.csv(
  procedure_table,
  "results/Tables/Supplement_procedure_stratified_outcomes.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 10. Print outputs
## ------------------------------------------------------------------

print(table3)
print(logistic_table)
print(procedure_table)