################################################################################
# 07_figure_panels.R
# Generate publication-ready panel figures for manuscript
# Fig 2: KM panel, 3 cohorts x 2 endpoints (Original/PSM/IPTW x DFS/OS, 6 panels)
# Fig 3: Subgroup forest, 3 cohorts x 2 endpoints (6 panels A-F)
# Supp Fig 1: Covariate balance (Love plot PSM + IPTW)
# (Fig 1 CONSORT and Fig 4 sensitivity summary are built in separate scripts)
# NOTE: requires results/Subgroup/subgroup_results_ALL_cohorts_dfs_os.csv
#       (run 12_original_subgroup_analysis.R first)
################################################################################

rm(list = ls())

library(survival)
library(survminer)
library(cobalt)
library(MatchIt)
library(WeightIt)
library(survey)
library(dplyr)
library(tibble)
library(ggplot2)
library(patchwork)
library(cowplot)
library(stringr)
library(forcats)
library(grid)
library(gridExtra)

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Panels", showWarnings = FALSE, recursive = TRUE)

## Colors used consistently
col_open <- "#C24B3A"
col_lap  <- "#0F659D"

## ------------------------------------------------------------------
## Load objects and data
## ------------------------------------------------------------------

m.out      <- readRDS("results/PSM/matchit_object.rds")
w.out.trim <- readRDS("results/IPTW/weightit_object_trimmed.rds")

dat_original <- read.csv("results/analysis_dataset_before_psm_iptw.csv", check.names = TRUE)
dat_psm      <- read.csv("results/PSM/matched_dataset.csv",              check.names = TRUE)
dat_iptw     <- read.csv("results/IPTW/data_after_iptw.csv",             check.names = TRUE)

format_surv <- function(dat) {
  dat$Surgical.approach <- factor(dat$Surgical.approach, levels = c("Open", "Laparoscopic"))
  dat$DFS      <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS       <- as.numeric(dat$OS)
  dat$OS.time  <- as.numeric(dat$OS.time)
  dat %>% filter(!is.na(Surgical.approach),
                 !is.na(DFS), !is.na(DFS.time),
                 !is.na(OS),  !is.na(OS.time))
}

dat_original <- format_surv(dat_original)
dat_psm      <- format_surv(dat_psm)
dat_iptw     <- format_surv(dat_iptw)

## ------------------------------------------------------------------
## Variable label dictionary for Love plot
## ------------------------------------------------------------------

var_labels <- c(
  Age                       = "Age",
  Sex                       = "Sex",
  Tumor.site                = "Tumor site",
  cT                        = "cT stage",
  cN                        = "cN stage",
  Grade                     = "Histologic grade",
  Lauren.classification     = "Lauren classification",
  Bormann.classification    = "Borrmann classification",
  NACT.regimen              = "NACT regimen",
  NACT.cycles               = "NACT cycles",
  Surgical.procedure        = "Surgical procedure"
)

## ------------------------------------------------------------------
## FIGURE 2: Covariate balance
## ------------------------------------------------------------------

LP_psm <- love.plot(
  m.out,
  thresholds   = 0.1,
  var.order    = "unadjusted",
  abs          = TRUE,
  colors       = c(col_open, col_lap),
  var.names    = var_labels,
  sample.names = c("Unadjusted", "Matched"),
  title        = "A. Propensity score matching",
  themes       = list(theme(legend.position = "top",
                            plot.title       = element_text(face = "bold", size = 12)))
)

LP_iptw <- love.plot(
  w.out.trim,
  thresholds   = 0.1,
  var.order    = "unadjusted",
  abs          = TRUE,
  colors       = c(col_open, col_lap),
  var.names    = var_labels,
  sample.names = c("Unadjusted", "Weighted"),
  title        = "B. Inverse probability of treatment weighting",
  themes       = list(theme(legend.position = "top",
                            plot.title       = element_text(face = "bold", size = 12)))
)

supp1 <- LP_psm + LP_iptw + plot_layout(ncol = 2)

ggsave("results/Panels/SuppFigure1_balance_panel.pdf", supp1,
       width = 12, height = 6)
ggsave("results/Panels/SuppFigure1_balance_panel.png", supp1,
       width = 12, height = 6, dpi = 600)

cat("Supp Figure 1 (covariate balance panel) saved.\n")

## ------------------------------------------------------------------
## FIGURE 2: KM curves, 3 cohorts x 2 endpoints (6 panels, 3 rows x 2 cols)
## ------------------------------------------------------------------

format_p <- function(p) {
  if (is.na(p))     return("NA")
  if (p < 0.001)    return("<0.001")
  return(paste0("=", sprintf("%.3f", p)))
}

make_km <- function(dat, time_var, event_var,
                    title,
                    weight_var = NULL,
                    ylab_text  = "Disease-free survival probability",
                    is_psm     = FALSE) {

  rt <- dat
  surv_formula <- as.formula(
    paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach")
  )

  if (is.null(weight_var)) {
    if (is_psm && "subclass" %in% names(rt)) {
      cox_formula <- as.formula(
        paste0("Surv(", time_var, ", ", event_var,
               ") ~ Surgical.approach + cluster(subclass)")
      )
      coxfit <- coxph(cox_formula, data = rt)
    } else {
      coxfit <- coxph(surv_formula, data = rt)
    }
    cox.sum <- summary(coxfit)
    HR  <- cox.sum$conf.int["Surgical.approachLaparoscopic", "exp(coef)"]
    LCL <- cox.sum$conf.int["Surgical.approachLaparoscopic", "lower .95"]
    UCL <- cox.sum$conf.int["Surgical.approachLaparoscopic", "upper .95"]
    diff <- survdiff(surv_formula, data = rt)
    Logrank.P <- 1 - pchisq(diff$chisq, df = 1)
    fit <- survfit(surv_formula, data = rt)
  } else {
    design <- svydesign(ids = ~1,
                        weights = as.formula(paste0("~", weight_var)),
                        data = rt)
    coxfit <- svycoxph(surv_formula, design = design)
    cox.sum <- summary(coxfit)
    HR  <- exp(coef(coxfit)["Surgical.approachLaparoscopic"])
    CI  <- exp(confint(coxfit)["Surgical.approachLaparoscopic", ])
    LCL <- CI[1]; UCL <- CI[2]
    diff <- svylogrank(surv_formula, design = design)
    Logrank.P <- as.numeric(diff[[2]][2])
    fit <- survfit(surv_formula, data = rt, weights = rt[[weight_var]])
  }

  hr.txt <- paste0("HR = ", sprintf("%.2f", HR),
                   " (95% CI: ", sprintf("%.2f", LCL),
                   "-", sprintf("%.2f", UCL), ")")
  pValue <- paste0("Log-rank P", format_p(Logrank.P),
                   "\n", hr.txt)

  fit$call$formula <- surv_formula

  ggsurvplot(
    fit, data           = rt,
    conf.int            = TRUE,
    pval                = pValue,
    pval.size           = 4,
    pval.coord          = c(0, 0.15),
    legend.title        = "",
    legend.labs         = c("Open", "Laparoscopic"),
    xlab                = "Time (months)",
    ylab                = ylab_text,
    break.time.by       = 24,
    palette             = c(col_open, col_lap),
    risk.table          = TRUE,
    risk.table.title    = "",
    risk.table.height   = 0.25,
    risk.table.fontsize = 3,
    title               = title,
    font.title          = c(11, "bold"),
    font.x              = c(10),
    font.y              = c(10),
    font.tickslab       = c(9),
    legend              = c(0.8, 0.95)
  )
}

km_orig_dfs <- make_km(dat_original, "DFS.time", "DFS",
                       "A. Unadjusted cohort, disease-free survival",
                       ylab_text = "Disease-free survival probability")
km_orig_os  <- make_km(dat_original, "OS.time",  "OS",
                       "B. Unadjusted cohort, overall survival",
                       ylab_text = "Overall survival probability")
km_psm_dfs  <- make_km(dat_psm,  "DFS.time", "DFS",
                       "C. PSM cohort, disease-free survival",
                       is_psm = TRUE,
                       ylab_text = "Disease-free survival probability")
km_psm_os   <- make_km(dat_psm,  "OS.time",  "OS",
                       "D. PSM cohort, overall survival",
                       is_psm = TRUE,
                       ylab_text = "Overall survival probability")
km_iptw_dfs <- make_km(dat_iptw, "DFS.time", "DFS",
                       "E. IPTW cohort, disease-free survival",
                       weight_var = "iptw_weight",
                       ylab_text  = "Disease-free survival probability")
km_iptw_os  <- make_km(dat_iptw, "OS.time",  "OS",
                       "F. IPTW cohort, overall survival",
                       weight_var = "iptw_weight",
                       ylab_text  = "Overall survival probability")

# 3 rows (Original / PSM / IPTW) x 2 cols (DFS / OS).
# arrange_ggsurvplots fills COLUMN-major, so list down col1 (all DFS) then
# col2 (all OS) to get the intended A B / C D / E F reading order.
km_list <- list(km_orig_dfs, km_psm_dfs, km_iptw_dfs,   # left column: DFS
                km_orig_os,  km_psm_os,  km_iptw_os)     # right column: OS

pdf("results/Panels/Figure2_KM_panel.pdf", width = 12, height = 19.5)
print(arrange_ggsurvplots(km_list, ncol = 2, nrow = 3, print = FALSE))
dev.off()

png("results/Panels/Figure2_KM_panel.png",
    width = 12, height = 19.5, units = "in", res = 600)
print(arrange_ggsurvplots(km_list, ncol = 2, nrow = 3, print = FALSE))
dev.off()

cat("Figure 2 (KM 3x2 panel, all cohorts) saved.\n")

## ------------------------------------------------------------------
## FIGURE 3: Subgroup forest, 3 cohorts x 2 endpoints (6 panels)
## ------------------------------------------------------------------

sub <- read.csv("results/Subgroup/subgroup_results_ALL_cohorts_dfs_os.csv",
                check.names = TRUE)

subgroup_order <- c(
  "Surgical procedure",
  "NACT regimen",
  "cT stage",
  "cN status",
  "Lauren classification",
  "Borrmann classification"
)

make_forest <- function(d, title_text) {

  d <- d %>%
    mutate(
      Subgroup = factor(Subgroup, levels = subgroup_order),
      HR_txt   = sprintf("%.2f (%.2f-%.2f)", HR, Lower95CI, Upper95CI),
      N_txt    = sprintf("%d / %d", Open_N, Laparoscopic_N)
    ) %>%
    arrange(Subgroup)

  ## Build display rows: subgroup heading + level rows (manual loop, no group_modify)
  display_rows <- list()
  for (sg in levels(d$Subgroup)) {
    chunk <- d %>% filter(Subgroup == sg)
    if (nrow(chunk) == 0) next
    p_int_val <- as.character(unique(chunk$P.interaction.formatted)[1])
    if (is.na(p_int_val)) p_int_val <- ""
    heading <- tibble(
      Subgroup  = sg,
      Level     = sg,
      HR        = NA_real_,
      Lower95CI = NA_real_,
      Upper95CI = NA_real_,
      HR_txt    = "",
      N_txt     = "",
      P.interaction.formatted = p_int_val,
      is_heading = TRUE
    )
    level_rows <- chunk %>%
      transmute(Subgroup = as.character(Subgroup),
                Level    = as.character(Level),
                HR, Lower95CI, Upper95CI,
                HR_txt, N_txt,
                P.interaction.formatted = "",
                is_heading = FALSE)
    display_rows[[sg]] <- bind_rows(heading, level_rows)
  }
  display <- bind_rows(display_rows)

  ## y positions reversed so first subgroup is on top
  display$y <- nrow(display) - seq_len(nrow(display)) + 1

  ## X range for log scale
  x_range <- range(c(display$Lower95CI, display$Upper95CI), na.rm = TRUE)
  x_min <- max(0.3, x_range[1] * 0.8)
  x_max <- min(5,   x_range[2] * 1.2)

  ## ----- left text panel (subgroups + N) -----
  p_left <- ggplot(display, aes(y = y)) +
    geom_text(aes(x = 0,
                  label = ifelse(is_heading,
                                 as.character(Subgroup),
                                 paste0("  ", Level))),
              hjust = 0,
              fontface = ifelse(display$is_heading, "bold", "plain"),
              size = 3.2) +
    geom_text(aes(x = 1.0, label = N_txt),
              hjust = 0.5, size = 3.0) +
    annotate("text", x = 0,   y = max(display$y) + 1,
             label = "Subgroup",    hjust = 0, fontface = "bold", size = 3.3) +
    annotate("text", x = 1.0, y = max(display$y) + 1,
             label = "Open / Lap",  hjust = 0.5, fontface = "bold", size = 3.3) +
    scale_x_continuous(limits = c(-0.05, 1.4)) +
    scale_y_continuous(limits = c(0, max(display$y) + 1.5)) +
    theme_void() +
    theme(plot.margin = margin(5, 0, 5, 5))

  ## ----- forest middle panel -----
  p_mid <- ggplot(display, aes(y = y)) +
    geom_vline(xintercept = 1, linetype = 2, color = "grey50") +
    geom_errorbarh(aes(xmin = Lower95CI, xmax = Upper95CI),
                   height = 0.25, color = col_lap, na.rm = TRUE) +
    geom_point(aes(x = HR), size = 2.4, color = col_lap, na.rm = TRUE) +
    scale_x_log10(limits = c(x_min, x_max),
                  breaks = c(0.5, 1, 2, 4)) +
    scale_y_continuous(limits = c(0, max(display$y) + 1.5)) +
    annotate("text", x = sqrt(x_min * x_max),
             y = max(display$y) + 1, label = "Hazard Ratio (95% CI)",
             fontface = "bold", size = 3.3) +
    labs(x = NULL, y = NULL) +
    theme_classic() +
    theme(axis.text.y       = element_blank(),
          axis.ticks.y      = element_blank(),
          axis.line.y       = element_blank(),
          axis.text.x       = element_text(size = 8),
          plot.margin       = margin(5, 5, 5, 5))

  ## ----- right text panel (HR + P-interaction) -----
  p_right <- ggplot(display, aes(y = y)) +
    geom_text(aes(x = 0, label = HR_txt), hjust = 0, size = 3.0) +
    geom_text(aes(x = 1.4, label = P.interaction.formatted),
              hjust = 0.5, size = 3.0, fontface = "italic") +
    annotate("text", x = 0,   y = max(display$y) + 1,
             label = "HR (95% CI)",       hjust = 0, fontface = "bold", size = 3.3) +
    annotate("text", x = 1.4, y = max(display$y) + 1,
             label = "P-interaction",     hjust = 0.5, fontface = "bold", size = 3.3) +
    scale_x_continuous(limits = c(-0.05, 1.95)) +
    scale_y_continuous(limits = c(0, max(display$y) + 1.5)) +
    theme_void() +
    theme(plot.margin = margin(5, 5, 5, 0))

  combined <- p_left + p_mid + p_right +
    plot_layout(widths = c(1.6, 1.4, 1.4))

  return(combined)
}

## Helper: stack two forest panels with explicit A/B labels
stack_forests <- function(top, bottom, top_label, bottom_label) {
  cowplot::plot_grid(
    top, bottom,
    ncol           = 1,
    labels         = c(top_label, bottom_label),
    label_size     = 12,
    label_fontface = "bold",
    label_x        = 0,
    label_y        = 1,
    hjust          = -0.02,
    vjust          = 1.2
  )
}

## ---- Figure 3: subgroup forests for all 3 cohorts x 2 endpoints ----
## Order: cohort-grouped to mirror the KM figure (Original -> PSM -> IPTW),
## DFS before OS within each cohort. Labels A-F.
forest_spec <- list(
  list(cohort = "Original", endpoint = "DFS",
       label = "A. Unadjusted cohort: disease-free survival"),
  list(cohort = "Original", endpoint = "OS",
       label = "B. Unadjusted cohort: overall survival"),
  list(cohort = "PSM",      endpoint = "DFS",
       label = "C. PSM cohort: disease-free survival"),
  list(cohort = "PSM",      endpoint = "OS",
       label = "D. PSM cohort: overall survival"),
  list(cohort = "IPTW",     endpoint = "DFS",
       label = "E. IPTW cohort: disease-free survival"),
  list(cohort = "IPTW",     endpoint = "OS",
       label = "F. IPTW cohort: overall survival")
)

forest_plots <- lapply(forest_spec, function(s) {
  d <- sub %>% filter(Cohort == s$cohort, Endpoint == s$endpoint)
  make_forest(d, s$label)
})

fig3 <- cowplot::plot_grid(
  plotlist       = forest_plots,
  ncol           = 1,
  labels         = vapply(forest_spec, function(s) s$label, character(1)),
  label_size     = 12,
  label_fontface = "bold",
  label_x        = 0,
  hjust          = -0.02,
  vjust          = 1.3
)

pdf("results/Panels/Figure3_Subgroup_forest_all.pdf", width = 16, height = 27)
print(fig3)
dev.off()

png("results/Panels/Figure3_Subgroup_forest_all.png",
    width = 16, height = 27, units = "in", res = 400)
print(fig3)
dev.off()

cat("Figure 3 (subgroup forest, 6 panels, all cohorts) saved.\n")

## ------------------------------------------------------------------
cat("\n============================================================\n")
cat("All panel figures generated under results/Panels/\n")
cat("============================================================\n")
