################################################################################
# 18_subgroup_individual_panels.R
# Figure 3 (subgroup forest) — six INDIVIDUAL panels, styled to MATCH Figure 4
# (script 13): layout-coordinate forest, square markers, fixed 0.5-2.0 band with
# manual ticks, "Favors" labels and axis title, no whisker caps, theme_void.
# Adds the subgroup-specific columns (Open/Lap N, P-interaction).
#   Unadjusted / PSM / IPTW  x  DFS / OS  (no A-F letters)
################################################################################

rm(list = ls())

library(dplyr)
library(tibble)
library(ggplot2)
library(stringr)

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)
dir.create("results/Panels", showWarnings = FALSE, recursive = TRUE)

col_point <- "#0F659D"

sub <- read.csv("results/Subgroup/subgroup_results_ALL_cohorts_dfs_os.csv",
                check.names = TRUE)

subgroup_order <- c("Surgical procedure", "NACT regimen", "cT stage",
                    "cN status", "Lauren classification", "Borrmann classification")

## ------------------------------------------------------------------
## Build display rows (group heading + indented levels)
## ------------------------------------------------------------------
build_display <- function(d) {
  d <- d %>%
    mutate(Subgroup = factor(Subgroup, levels = subgroup_order),
           HR_txt   = sprintf("%.2f (%.2f-%.2f)", HR, Lower95CI, Upper95CI),
           N_txt    = sprintf("%d / %d", round(Open_N), round(Laparoscopic_N))) %>%
    arrange(Subgroup)
  rows <- list()
  for (sg in levels(d$Subgroup)) {
    chunk <- d %>% filter(Subgroup == sg)
    if (nrow(chunk) == 0) next
    pint <- as.character(unique(chunk$P.interaction.formatted)[1])
    if (is.na(pint)) pint <- ""
    rows[[length(rows)+1]] <- tibble(
      label = sg, HR = NA_real_, lo = NA_real_, hi = NA_real_,
      HR_txt = "", N_txt = "", Pint = pint, is_header = TRUE)
    for (j in seq_len(nrow(chunk))) {
      rows[[length(rows)+1]] <- tibble(
        label = paste0("   ", chunk$Level[j]),
        HR = chunk$HR[j], lo = chunk$Lower95CI[j], hi = chunk$Upper95CI[j],
        HR_txt = chunk$HR_txt[j], N_txt = chunk$N_txt[j], Pint = "",
        is_header = FALSE)
    }
  }
  out <- bind_rows(rows)
  out$y <- rev(seq_len(nrow(out)))
  out
}

## ------------------------------------------------------------------
## Forest renderer — same visual system as Figure 4
## ------------------------------------------------------------------
forest_sub <- function(d, title_text) {
  disp <- build_display(d)
  ymax <- max(disp$y)

  x_lab <- 0.15                       # subgroup labels (left)
  x_n   <- 4.05                       # Open / Lap N (centered)
  fx0   <- 4.9; fx1 <- 6.8            # forest band
  x_hr  <- 8.5                        # HR (95% CI), right-aligned
  x_p   <- 10.1                       # P-interaction, right-aligned
  hr_lo <- 0.5; hr_hi <- 2.0
  ticks <- c(0.5, 1.0, 1.5, 2.0)
  to_x  <- function(hr) fx0 + (log(hr) - log(hr_lo)) /
                              (log(hr_hi) - log(hr_lo)) * (fx1 - fx0)

  lv    <- disp[!disp$is_header, ]
  norm  <- lv[!is.na(lv$hi) & lv$hi <= hr_hi, ]   # CI fits inside band
  clamp <- lv[!is.na(lv$hi) & lv$hi >  hr_hi, ]   # upper CI truncated -> arrow

  ggplot(disp, aes(y = y)) +
    geom_segment(x = to_x(1), xend = to_x(1), y = 0.4, yend = ymax + 0.6,
                 linetype = 2, color = "grey55", linewidth = 0.4) +
    geom_segment(data = norm,
                 aes(x = to_x(pmax(lo, hr_lo)), xend = to_x(hi), y = y, yend = y),
                 color = col_point, linewidth = 0.6) +
    geom_segment(data = clamp,
                 aes(x = to_x(pmax(lo, hr_lo)), xend = to_x(hr_hi), y = y, yend = y),
                 color = col_point, linewidth = 0.6,
                 arrow = arrow(length = unit(3.5, "pt"), type = "closed")) +
    geom_point(aes(x = to_x(HR)), shape = 15, size = 2.3,
               color = col_point, na.rm = TRUE) +
    # labels (group headers bold)
    geom_text(aes(x = x_lab, label = label,
                  fontface = ifelse(is_header, "bold", "plain")),
              hjust = 0, size = 3.0) +
    # N column
    geom_text(aes(x = x_n, label = N_txt), hjust = 0.5, size = 2.9, na.rm = TRUE) +
    # HR + P-interaction
    geom_text(aes(x = x_hr, label = HR_txt), hjust = 1, size = 2.9, na.rm = TRUE) +
    geom_text(aes(x = x_p, label = Pint), hjust = 1, size = 2.9,
              fontface = "italic", na.rm = TRUE) +
    # column captions
    annotate("text", x = x_lab, y = ymax + 1.4, label = "Subgroup",
             hjust = 0, fontface = "bold", size = 3.1) +
    annotate("text", x = x_n, y = ymax + 1.4, label = "Open / Lap",
             hjust = 0.5, fontface = "bold", size = 3.1) +
    annotate("text", x = x_hr, y = ymax + 1.4, label = "HR (95% CI)",
             hjust = 1, fontface = "bold", size = 3.1) +
    annotate("text", x = x_p, y = ymax + 1.4, label = "P-interaction",
             hjust = 1, fontface = "bold", size = 3.1) +
    # manual x-axis under the forest band
    annotate("segment", x = to_x(hr_lo), xend = to_x(hr_hi),
             y = 0.1, yend = 0.1, color = "black", linewidth = 0.4) +
    annotate("segment", x = to_x(ticks), xend = to_x(ticks),
             y = 0.1, yend = -0.1, color = "black", linewidth = 0.4) +
    annotate("text", x = to_x(ticks), y = -0.6,
             label = sprintf("%.1f", ticks), size = 2.7) +
    annotate("text", x = to_x(0.66), y = -1.35, label = "Favors laparoscopic",
             hjust = 0.5, size = 2.5, color = "grey30") +
    annotate("text", x = to_x(1.52), y = -1.35, label = "Favors open",
             hjust = 0.5, size = 2.5, color = "grey30") +
    annotate("text", x = to_x(1), y = -2.1,
             label = "Hazard ratio (laparoscopic vs open)", size = 2.9) +
    scale_x_continuous(limits = c(0.0, 10.3)) +
    scale_y_continuous(limits = c(-2.5, ymax + 2)) +
    labs(title = title_text) +
    theme_void(base_size = 10) +
    theme(plot.title  = element_text(face = "bold", size = 12,
                                     margin = margin(t = 10, b = 10, l = 14)),
          plot.margin = margin(t = 6, r = 8, b = 6, l = 8))
}

## ------------------------------------------------------------------
## Six individual panels
## ------------------------------------------------------------------
spec <- list(
  list(c = "Original", e = "DFS", t = "Unadjusted cohort, disease-free survival", f = "Unadjusted_DFS"),
  list(c = "Original", e = "OS",  t = "Unadjusted cohort, overall survival",      f = "Unadjusted_OS"),
  list(c = "PSM",      e = "DFS", t = "PSM cohort, disease-free survival",        f = "PSM_DFS"),
  list(c = "PSM",      e = "OS",  t = "PSM cohort, overall survival",             f = "PSM_OS"),
  list(c = "IPTW",     e = "DFS", t = "IPTW cohort, disease-free survival",       f = "IPTW_DFS"),
  list(c = "IPTW",     e = "OS",  t = "IPTW cohort, overall survival",            f = "IPTW_OS")
)

for (s in spec) {
  d <- sub %>% filter(Cohort == s$c, Endpoint == s$e)
  if (nrow(d) == 0) { cat("skip (no data):", s$c, s$e, "\n"); next }
  p <- forest_sub(d, s$t)
  base <- paste0("results/Panels/Figure3_Subgroup_", s$f)
  ggsave(paste0(base, ".pdf"), p, width = 9.5, height = 6.0)
  ggsave(paste0(base, ".png"), p, width = 9.5, height = 6.0, dpi = 600)
}

cat("\nFigure 3: six individual subgroup panels (Figure-4 style) saved.\n")
