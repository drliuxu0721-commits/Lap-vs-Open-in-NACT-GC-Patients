################################################################################
# 04_subgroup_analysis.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# Clinically relevant subgroup analysis for DFS/OS in PSM and IPTW cohorts
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(survival)
library(survey)
library(dplyr)
library(tibble)
library(openxlsx)
library(ggplot2)
library(stringr)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Subgroup", showWarnings = FALSE, recursive = TRUE)
dir.create("results/Figures", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import data
## ------------------------------------------------------------------

dat_psm <- read.csv("results/PSM/matched_dataset.csv",
                    header = TRUE, check.names = TRUE)

dat_iptw <- read.csv("results/IPTW/data_after_iptw.csv",
                     header = TRUE, check.names = TRUE)

## ------------------------------------------------------------------
## 4. Data formatting
## ------------------------------------------------------------------

format_data <- function(dat) {
  
  dat$Surgical.approach <- factor(
    dat$Surgical.approach,
    levels = c("Open", "Laparoscopic")
  )
  dat$Surgical.approach <- relevel(dat$Surgical.approach, ref = "Open")
  
  dat$DFS <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS <- as.numeric(dat$OS)
  dat$OS.time <- as.numeric(dat$OS.time)
  
  numeric_vars <- c(
    "Age",
    "NACT.cycles",
    "Operation.time",
    "Positive.Lymph.Nodes.Count",
    "Total.Lymph.Nodes.Count"
  )
  
  numeric_vars <- intersect(numeric_vars, names(dat))
  dat[, numeric_vars] <- lapply(dat[, numeric_vars], as.numeric)
  
  factor_vars <- c(
    "Sex",
    "Tumor.site",
    "cT",
    "cN",
    "Grade",
    "Lauren.classification",
    "Bormann.classification",
    "NACT.regimen",
    "Surgical.procedure",
    "ypT",
    "ypN",
    "Mandard.TRG",
    "MPR",
    "pCR",
    "Margin",
    "Nerve.Invasion",
    "Lymphovascular.Tumor.Thrombus",
    "ACT",
    "ACT.regimen",
    "Complication",
    "Perioperative.mortality"
  )
  
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  
  dat <- dat %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(DFS), !is.na(DFS.time), !is.na(OS), !is.na(OS.time))
  
  return(dat)
}

dat_psm  <- format_data(dat_psm)
dat_iptw <- format_data(dat_iptw)

## ------------------------------------------------------------------
## 5. Create clinically relevant subgroup variables
## ------------------------------------------------------------------

make_subgroup_vars <- function(dat) {
  
  dat <- dat %>%
    mutate(
      cT.group = case_when(
        cT %in% c("T4", "4", "cT4") ~ "cT4",
        cT %in% c("T2", "2", "cT2", "T3", "3", "cT3") ~ "cT2-3",
        TRUE ~ as.character(cT)
      ),
      
      cN.group = case_when(
        cN %in% c("N0", "0", "cN0") ~ "cN0",
        cN %in% c("N1", "1", "cN1", "N2", "2", "cN2", "N3", "3", "cN3") ~ "cN+",
        TRUE ~ as.character(cN)
      ),
      
      Lauren.group = case_when(
        Lauren.classification %in% c("Diffuse type", "Diffuse") ~ "Diffuse type",
        Lauren.classification %in% c(
          "Intestinal type",
          "Mixed type",
          "Intestinal",
          "Mixed"
        ) ~ "Intestinal/Mixed type",
        TRUE ~ as.character(Lauren.classification)
      ),
      
      Borrmann.group = case_when(
        Bormann.classification %in% c(
          "Diffuse infiltrative type",
          "Borrmann 4",
          "Borrmann IV",
          "Type IV"
        ) ~ "Borrmann 4 / Diffuse infiltrative type",
        !is.na(Bormann.classification) ~ "Non-Borrmann 4",
        TRUE ~ NA_character_
      )
    )
  
  dat$cT.group <- factor(
    dat$cT.group,
    levels = c("cT2-3", "cT4")
  )
  
  dat$cN.group <- factor(
    dat$cN.group,
    levels = c("cN0", "cN+")
  )
  
  dat$Lauren.group <- factor(
    dat$Lauren.group,
    levels = c("Intestinal/Mixed type", "Diffuse type")
  )
  
  dat$Borrmann.group <- factor(
    dat$Borrmann.group,
    levels = c("Non-Borrmann 4", "Borrmann 4 / Diffuse infiltrative type")
  )
  
  return(dat)
}

dat_psm  <- make_subgroup_vars(dat_psm)
dat_iptw <- make_subgroup_vars(dat_iptw)

## ------------------------------------------------------------------
## 6. Subgroup settings
## ------------------------------------------------------------------

subgroup_list <- list(
  "Surgical procedure" = "Surgical.procedure",
  "NACT regimen" = "NACT.regimen",
  "cT stage" = "cT.group",
  "cN status" = "cN.group",
  "Lauren classification" = "Lauren.group",
  "Borrmann classification" = "Borrmann.group"
)

## Surgical-procedure subgroup levels (all three radical procedures)
procedure_keep <- c("Distal gastrectomy", "Proximal gastrectomy", "Total gastrectomy")

## ------------------------------------------------------------------
## 7. Helper functions
## ------------------------------------------------------------------

format_p <- function(p) {
  ifelse(
    is.na(p),
    "NA",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

safe_cox_extract <- function(fit,
                             coef_name = "Surgical.approachLaparoscopic") {
  
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    return(data.frame(
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA
    ))
  }
  
  if (inherits(fit, "svycoxph")) {
    
    HR <- exp(coef(fit)[coef_name])
    CI <- exp(confint(fit)[coef_name, ])
    P  <- s$coefficients[coef_name, "Pr(>|z|)"]
    
    out <- data.frame(
      HR = as.numeric(HR),
      Lower95CI = as.numeric(CI[1]),
      Upper95CI = as.numeric(CI[2]),
      P.value = as.numeric(P)
    )
    
  } else {
    
    out <- data.frame(
      HR = as.numeric(s$conf.int[coef_name, "exp(coef)"]),
      Lower95CI = as.numeric(s$conf.int[coef_name, "lower .95"]),
      Upper95CI = as.numeric(s$conf.int[coef_name, "upper .95"]),
      P.value = as.numeric(s$coefficients[coef_name, "Pr(>|z|)"])
    )
  }
  
  return(out)
}

get_interaction_p <- function(dat,
                              time_var,
                              event_var,
                              subgroup_var,
                              model_type = c("PSM", "IPTW"),
                              weight_var = NULL) {
  
  model_type <- match.arg(model_type)
  
  interaction_p <- NA
  
  fml_int <- as.formula(
    paste0(
      "Surv(", time_var, ", ", event_var, ") ~ Surgical.approach * ",
      subgroup_var
    )
  )
  
  fit_int <- try({
    
    if (model_type == "PSM") {
      
      coxph(
        update(fml_int, . ~ . + cluster(subclass)),
        data = dat
      )
      
    } else {
      
      design <- svydesign(
        ids = ~1,
        weights = as.formula(paste0("~", weight_var)),
        data = dat
      )
      
      svycoxph(fml_int, design = design)
    }
    
  }, silent = TRUE)
  
  if (inherits(fit_int, "try-error")) {
    return(NA)
  }
  
  s_int <- summary(fit_int)
  int_rows <- grep(
    "Surgical.approachLaparoscopic:",
    rownames(s_int$coefficients)
  )
  
  if (length(int_rows) > 0) {
    interaction_p <- max(
      s_int$coefficients[int_rows, "Pr(>|z|)"],
      na.rm = TRUE
    )
  }
  
  return(as.numeric(interaction_p))
}

## ------------------------------------------------------------------
## 8. Run subgroup Cox
## ------------------------------------------------------------------

run_subgroup_cox <- function(dat,
                             cohort,
                             endpoint = c("DFS", "OS"),
                             model_type = c("PSM", "IPTW"),
                             weight_var = NULL) {
  
  endpoint <- match.arg(endpoint)
  model_type <- match.arg(model_type)
  
  if (endpoint == "DFS") {
    time_var <- "DFS.time"
    event_var <- "DFS"
  } else {
    time_var <- "OS.time"
    event_var <- "OS"
  }
  
  all_out <- list()
  k <- 1
  
  for (subgroup_name in names(subgroup_list)) {
    
    subgroup_var <- subgroup_list[[subgroup_name]]
    
    if (!subgroup_var %in% names(dat)) {
      next
    }
    
    subgroup_levels <- levels(factor(dat[[subgroup_var]]))
    
    if (subgroup_var == "Surgical.procedure") {
      subgroup_levels <- intersect(subgroup_levels, procedure_keep)
    }
    
    interaction_p <- get_interaction_p(
      dat = dat,
      time_var = time_var,
      event_var = event_var,
      subgroup_var = subgroup_var,
      model_type = model_type,
      weight_var = weight_var
    )
    
    for (lv in subgroup_levels) {
      
      sub_dat <- dat %>%
        filter(.data[[subgroup_var]] == lv)
      
      n_open <- sum(sub_dat$Surgical.approach == "Open", na.rm = TRUE)
      n_lap  <- sum(sub_dat$Surgical.approach == "Laparoscopic", na.rm = TRUE)
      events <- sum(sub_dat[[event_var]] == 1, na.rm = TRUE)
      
      if (n_open < 10 | n_lap < 10 | events < 10) {
        
        tmp <- data.frame(
          HR = NA,
          Lower95CI = NA,
          Upper95CI = NA,
          P.value = NA
        )
        
      } else {
        
        fml <- as.formula(
          paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach")
        )
        
        if (model_type == "PSM") {
          
          fit <- try(
            coxph(
              update(fml, . ~ . + cluster(subclass)),
              data = sub_dat
            ),
            silent = TRUE
          )
          
          if (inherits(fit, "try-error")) {
            tmp <- data.frame(
              HR = NA,
              Lower95CI = NA,
              Upper95CI = NA,
              P.value = NA
            )
          } else {
            tmp <- safe_cox_extract(fit)
          }
          
        } else {
          
          design_sub <- svydesign(
            ids = ~1,
            weights = as.formula(paste0("~", weight_var)),
            data = sub_dat
          )
          
          fit <- try(
            svycoxph(fml, design = design_sub),
            silent = TRUE
          )
          
          if (inherits(fit, "try-error")) {
            tmp <- data.frame(
              HR = NA,
              Lower95CI = NA,
              Upper95CI = NA,
              P.value = NA
            )
          } else {
            tmp <- safe_cox_extract(fit)
          }
        }
      }
      
      all_out[[k]] <- data.frame(
        Cohort = cohort,
        Endpoint = endpoint,
        Model = model_type,
        Subgroup = subgroup_name,
        Level = lv,
        N = nrow(sub_dat),
        Open_N = n_open,
        Laparoscopic_N = n_lap,
        Events = events,
        HR = tmp$HR,
        Lower95CI = tmp$Lower95CI,
        Upper95CI = tmp$Upper95CI,
        P.value = tmp$P.value,
        P.for.interaction = interaction_p,
        stringsAsFactors = FALSE
      )
      
      k <- k + 1
    }
  }
  
  out <- bind_rows(all_out) %>%
    mutate(
      HR_CI = ifelse(
        is.na(HR),
        "NA",
        paste0(
          sprintf("%.2f", HR),
          " (",
          sprintf("%.2f", Lower95CI),
          "-",
          sprintf("%.2f", Upper95CI),
          ")"
        )
      ),
      P.value.formatted = format_p(P.value),
      P.interaction.formatted = format_p(P.for.interaction)
    )
  
  return(out)
}

## ------------------------------------------------------------------
## 9. Run subgroup analyses
## ------------------------------------------------------------------

subgroup_results <- bind_rows(
  
  run_subgroup_cox(
    dat = dat_psm,
    cohort = "PSM",
    endpoint = "DFS",
    model_type = "PSM"
  ),
  
  run_subgroup_cox(
    dat = dat_psm,
    cohort = "PSM",
    endpoint = "OS",
    model_type = "PSM"
  ),
  
  run_subgroup_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "DFS",
    model_type = "IPTW",
    weight_var = "iptw_weight"
  ),
  
  run_subgroup_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "OS",
    model_type = "IPTW",
    weight_var = "iptw_weight"
  )
)

write.csv(
  subgroup_results,
  "results/Subgroup/subgroup_results_clinical_psm_iptw_dfs_os.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 10. Forest plot function
## ------------------------------------------------------------------

make_forest_plot <- function(df,
                             cohort = "PSM",
                             endpoint = "DFS") {
  
  plot_df <- df %>%
    filter(Cohort == cohort, Endpoint == endpoint) %>%
    mutate(
      Subgroup = factor(Subgroup, levels = names(subgroup_list)),
      Level_show = paste0("  ", Level),
      HR_CI_show = ifelse(is.na(HR), "", HR_CI),
      P_show = ifelse(is.na(P.value), "", P.value.formatted),
      P_int_show = ifelse(
        duplicated(Subgroup),
        "",
        P.interaction.formatted
      )
    ) %>%
    arrange(Subgroup)
  
  header_df <- plot_df %>%
    distinct(Subgroup) %>%
    mutate(
      Level = as.character(Subgroup),
      Level_show = as.character(Subgroup),
      N = NA,
      Open_N = NA,
      Laparoscopic_N = NA,
      Events = NA,
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      P.for.interaction = NA,
      HR_CI = "",
      HR_CI_show = "",
      P.value.formatted = "",
      P.interaction.formatted = "",
      P_show = "",
      P_int_show = "",
      is_header = TRUE
    )
  
  plot_df <- plot_df %>%
    mutate(is_header = FALSE)
  
  plot_df2 <- bind_rows(plot_df, header_df) %>%
    arrange(
      Subgroup,
      desc(is_header)
    ) %>%
    mutate(
      y = rev(row_number()),
      label_left = ifelse(
        is_header,
        Level_show,
        paste0(Level_show, "    N=", N, " / Events=", Events)
      ),
      label_right = ifelse(
        is_header,
        "",
        paste0(HR_CI_show, "    P=", P_show)
      )
    )
  
  p <- ggplot(plot_df2, aes(x = HR, y = y)) +
    geom_vline(xintercept = 1, linetype = 2) +
    geom_errorbarh(
      aes(xmin = Lower95CI, xmax = Upper95CI),
      height = 0.20,
      na.rm = TRUE
    ) +
    geom_point(size = 2.3, na.rm = TRUE) +
    scale_x_log10(
      limits = c(0.25, 4),
      breaks = c(0.25, 0.5, 1, 2, 4)
    ) +
    scale_y_continuous(
      breaks = plot_df2$y,
      labels = plot_df2$label_left
    ) +
    labs(
      title = paste0(cohort, " cohort: subgroup analysis for ", endpoint),
      x = "Hazard ratio for laparoscopic vs open surgery",
      y = ""
    ) +
    theme_bw() +
    theme(
      axis.text.y = element_text(size = 9),
      plot.title = element_text(hjust = 0.5, size = 12),
      panel.grid.minor = element_blank()
    )
  
  pdf(
    file = paste0("results/Figures/Forest_", cohort, "_", endpoint, "_clinical.pdf"),
    width = 8,
    height = 7
  )
  print(p)
  dev.off()
  
  return(p)
}

## ------------------------------------------------------------------
## 11. Generate forest plots
## ------------------------------------------------------------------

make_forest_plot(subgroup_results, cohort = "PSM", endpoint = "DFS")
make_forest_plot(subgroup_results, cohort = "PSM", endpoint = "OS")
make_forest_plot(subgroup_results, cohort = "IPTW", endpoint = "DFS")
make_forest_plot(subgroup_results, cohort = "IPTW", endpoint = "OS")

## ------------------------------------------------------------------
## 12. Export Excel summary
## ------------------------------------------------------------------

wb <- createWorkbook()

addWorksheet(wb, "All subgroup results")
writeData(wb, "All subgroup results", subgroup_results)

addWorksheet(wb, "PSM DFS")
writeData(
  wb,
  "PSM DFS",
  subgroup_results %>% filter(Cohort == "PSM", Endpoint == "DFS")
)

addWorksheet(wb, "PSM OS")
writeData(
  wb,
  "PSM OS",
  subgroup_results %>% filter(Cohort == "PSM", Endpoint == "OS")
)

addWorksheet(wb, "IPTW DFS")
writeData(
  wb,
  "IPTW DFS",
  subgroup_results %>% filter(Cohort == "IPTW", Endpoint == "DFS")
)

addWorksheet(wb, "IPTW OS")
writeData(
  wb,
  "IPTW OS",
  subgroup_results %>% filter(Cohort == "IPTW", Endpoint == "OS")
)

saveWorkbook(
  wb,
  "results/Subgroup/subgroup_results_clinical_psm_iptw_dfs_os.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 13. Console output
## ------------------------------------------------------------------

cat("\n============================================================\n")
cat("Clinical subgroup analysis completed.\n")
cat("============================================================\n")

cat("\nOutput files:\n")
cat("results/Subgroup/subgroup_results_clinical_psm_iptw_dfs_os.csv\n")
cat("results/Subgroup/subgroup_results_clinical_psm_iptw_dfs_os.xlsx\n")
cat("results/Figures/Forest_PSM_DFS_clinical.pdf\n")
cat("results/Figures/Forest_PSM_OS_clinical.pdf\n")
cat("results/Figures/Forest_IPTW_DFS_clinical.pdf\n")
cat("results/Figures/Forest_IPTW_OS_clinical.pdf\n")