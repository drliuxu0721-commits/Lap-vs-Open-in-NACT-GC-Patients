################################################################################
# 12_original_subgroup_analysis.R
# Add the unadjusted (Original cohort) subgroup Cox analysis, using the SAME
# subgroup definitions and cell-size rules as 04_subgroup_analysis.R, then
# merge Original + PSM + IPTW into one combined CSV for the 6-panel forests.
################################################################################

rm(list = ls())

library(survival)
library(dplyr)
library(tibble)
library(stringr)

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

## ------------------------------------------------------------------
## Data
## ------------------------------------------------------------------

dat_original <- read.csv("results/analysis_dataset_before_psm_iptw.csv",
                         header = TRUE, check.names = TRUE)

format_data <- function(dat) {
  dat$Surgical.approach <- factor(dat$Surgical.approach,
                                  levels = c("Open", "Laparoscopic"))
  dat$Surgical.approach <- relevel(dat$Surgical.approach, ref = "Open")
  dat$DFS      <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS       <- as.numeric(dat$OS)
  dat$OS.time  <- as.numeric(dat$OS.time)
  factor_vars <- c("Sex","Tumor.site","cT","cN","Grade","Lauren.classification",
                   "Bormann.classification","NACT.regimen","Surgical.procedure")
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  dat %>% filter(!is.na(Surgical.approach),
                 !is.na(DFS), !is.na(DFS.time), !is.na(OS), !is.na(OS.time))
}

dat_original <- format_data(dat_original)

## ------------------------------------------------------------------
## Subgroup variables (identical to 04_subgroup_analysis.R)
## ------------------------------------------------------------------

make_subgroup_vars <- function(dat) {
  dat <- dat %>%
    mutate(
      cT.group = case_when(
        cT %in% c("T4","4","cT4") ~ "cT4",
        cT %in% c("T2","2","cT2","T3","3","cT3") ~ "cT2-3",
        TRUE ~ as.character(cT)),
      cN.group = case_when(
        cN %in% c("N0","0","cN0") ~ "cN0",
        cN %in% c("N1","1","cN1","N2","2","cN2","N3","3","cN3") ~ "cN+",
        TRUE ~ as.character(cN)),
      Lauren.group = case_when(
        Lauren.classification %in% c("Diffuse type","Diffuse") ~ "Diffuse type",
        Lauren.classification %in% c("Intestinal type","Mixed type",
                                     "Intestinal","Mixed") ~ "Intestinal/Mixed type",
        TRUE ~ as.character(Lauren.classification)),
      Borrmann.group = case_when(
        Bormann.classification %in% c("Diffuse infiltrative type","Borrmann 4",
                                      "Borrmann IV","Type IV") ~
          "Borrmann 4 / Diffuse infiltrative type",
        !is.na(Bormann.classification) ~ "Non-Borrmann 4",
        TRUE ~ NA_character_))
  dat$cT.group       <- factor(dat$cT.group, levels = c("cT2-3","cT4"))
  dat$cN.group       <- factor(dat$cN.group, levels = c("cN0","cN+"))
  dat$Lauren.group   <- factor(dat$Lauren.group,
                               levels = c("Intestinal/Mixed type","Diffuse type"))
  dat$Borrmann.group <- factor(dat$Borrmann.group,
                               levels = c("Non-Borrmann 4",
                                          "Borrmann 4 / Diffuse infiltrative type"))
  dat
}

dat_original <- make_subgroup_vars(dat_original)

subgroup_list <- list(
  "Surgical procedure"      = "Surgical.procedure",
  "NACT regimen"            = "NACT.regimen",
  "cT stage"                = "cT.group",
  "cN status"               = "cN.group",
  "Lauren classification"   = "Lauren.group",
  "Borrmann classification" = "Borrmann.group"
)
procedure_keep <- c("Distal gastrectomy", "Proximal gastrectomy", "Total gastrectomy")

format_p <- function(p) ifelse(is.na(p), "NA",
                               ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))

## ------------------------------------------------------------------
## Unadjusted subgroup Cox + interaction p (Original cohort)
## ------------------------------------------------------------------

get_interaction_p_unadj <- function(dat, time_var, event_var, subgroup_var) {
  fml_int <- as.formula(paste0("Surv(", time_var, ", ", event_var,
                               ") ~ Surgical.approach * ", subgroup_var))
  fit_int <- try(coxph(fml_int, data = dat), silent = TRUE)
  if (inherits(fit_int, "try-error")) return(NA)
  s_int <- summary(fit_int)
  rows <- grep("Surgical.approachLaparoscopic:", rownames(s_int$coefficients))
  if (length(rows) > 0)
    return(as.numeric(max(s_int$coefficients[rows, "Pr(>|z|)"], na.rm = TRUE)))
  NA
}

run_subgroup_original <- function(dat, endpoint = c("DFS","OS")) {
  endpoint <- match.arg(endpoint)
  time_var  <- if (endpoint == "DFS") "DFS.time" else "OS.time"
  event_var <- if (endpoint == "DFS") "DFS" else "OS"

  out <- list(); k <- 1
  for (sg_name in names(subgroup_list)) {
    sg_var <- subgroup_list[[sg_name]]
    if (!sg_var %in% names(dat)) next
    levs <- levels(factor(dat[[sg_var]]))
    if (sg_var == "Surgical.procedure") levs <- intersect(levs, procedure_keep)

    int_p <- get_interaction_p_unadj(dat, time_var, event_var, sg_var)

    for (lv in levs) {
      sd <- dat %>% filter(.data[[sg_var]] == lv)
      n_open <- sum(sd$Surgical.approach == "Open", na.rm = TRUE)
      n_lap  <- sum(sd$Surgical.approach == "Laparoscopic", na.rm = TRUE)
      events <- sum(sd[[event_var]] == 1, na.rm = TRUE)

      if (n_open < 10 | n_lap < 10 | events < 10) {
        tmp <- data.frame(HR=NA, Lower95CI=NA, Upper95CI=NA, P.value=NA)
      } else {
        fml <- as.formula(paste0("Surv(", time_var, ", ", event_var,
                                 ") ~ Surgical.approach"))
        fit <- try(coxph(fml, data = sd), silent = TRUE)
        if (inherits(fit, "try-error")) {
          tmp <- data.frame(HR=NA, Lower95CI=NA, Upper95CI=NA, P.value=NA)
        } else {
          s <- summary(fit)
          cn <- "Surgical.approachLaparoscopic"
          tmp <- data.frame(
            HR        = as.numeric(s$conf.int[cn, "exp(coef)"]),
            Lower95CI = as.numeric(s$conf.int[cn, "lower .95"]),
            Upper95CI = as.numeric(s$conf.int[cn, "upper .95"]),
            P.value   = as.numeric(s$coefficients[cn, "Pr(>|z|)"]))
        }
      }

      out[[k]] <- data.frame(
        Cohort = "Original", Endpoint = endpoint, Model = "Original",
        Subgroup = sg_name, Level = lv, N = nrow(sd),
        Open_N = n_open, Laparoscopic_N = n_lap, Events = events,
        HR = tmp$HR, Lower95CI = tmp$Lower95CI, Upper95CI = tmp$Upper95CI,
        P.value = tmp$P.value, P.for.interaction = int_p,
        stringsAsFactors = FALSE)
      k <- k + 1
    }
  }
  bind_rows(out) %>%
    mutate(
      HR_CI = ifelse(is.na(HR), "NA",
                     paste0(sprintf("%.2f", HR), " (",
                            sprintf("%.2f", Lower95CI), "-",
                            sprintf("%.2f", Upper95CI), ")")),
      P.value.formatted = format_p(P.value),
      P.interaction.formatted = format_p(P.for.interaction))
}

orig_sub <- bind_rows(
  run_subgroup_original(dat_original, "DFS"),
  run_subgroup_original(dat_original, "OS")
)

## ------------------------------------------------------------------
## Merge with existing PSM + IPTW results -> combined CSV
## ------------------------------------------------------------------

existing <- read.csv("results/Subgroup/subgroup_results_clinical_psm_iptw_dfs_os.csv",
                     check.names = TRUE, stringsAsFactors = FALSE)

## Harmonize column types (formatted cols may be read as numeric)
chr_cols <- c("Cohort","Endpoint","Model","Subgroup","Level",
              "HR_CI","P.value.formatted","P.interaction.formatted")
for (cc in intersect(chr_cols, names(existing))) existing[[cc]] <- as.character(existing[[cc]])
for (cc in intersect(chr_cols, names(orig_sub))) orig_sub[[cc]] <- as.character(orig_sub[[cc]])

combined <- bind_rows(orig_sub, existing) %>%
  mutate(Cohort = factor(Cohort, levels = c("Original","PSM","IPTW"))) %>%
  arrange(Cohort, Endpoint)

write.csv(combined,
          "results/Subgroup/subgroup_results_ALL_cohorts_dfs_os.csv",
          row.names = FALSE)

cat("\n============================================================\n")
cat("Original-cohort subgroup analysis added.\n")
cat("Combined 3-cohort file: results/Subgroup/subgroup_results_ALL_cohorts_dfs_os.csv\n")
cat("Rows:", nrow(combined), " (Original:", nrow(orig_sub), ")\n")
cat("============================================================\n")
print(orig_sub %>% select(Endpoint, Subgroup, Level, HR_CI, P.interaction.formatted))
