################################################################################
# 11_format_table3_cox_results_xlsx.R
# Format Table 3: Cox regression analyses, Excel only
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(dplyr)
library(openxlsx)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Final_Tables", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Helper functions
## ------------------------------------------------------------------

format_p <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  ifelse(
    is.na(p),
    "",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

format_ci <- function(est, lower, upper) {
  est <- suppressWarnings(as.numeric(est))
  lower <- suppressWarnings(as.numeric(lower))
  upper <- suppressWarnings(as.numeric(upper))
  
  ifelse(
    is.na(est) | is.na(lower) | is.na(upper),
    "",
    paste0(
      sprintf("%.2f", est),
      " (",
      sprintf("%.2f", lower),
      "-",
      sprintf("%.2f", upper),
      ")"
    )
  )
}

clean_endpoint <- function(x) {
  recode(
    x,
    "DFS" = "Disease-free survival",
    "OS"  = "Overall survival",
    .default = x
  )
}

## ------------------------------------------------------------------
## 4. Import Cox results
## ------------------------------------------------------------------

cox_file <- "results/Survival/cox_results_original_psm_iptw.csv"

if (!file.exists(cox_file)) {
  cox_file <- "cox_results_original_psm_iptw.csv"
}

cox_results <- read.csv(cox_file, header = TRUE, check.names = TRUE)

p_col <- if ("Cox.P.value" %in% names(cox_results)) {
  "Cox.P.value"
} else if ("P.value" %in% names(cox_results)) {
  "P.value"
} else if ("p.value" %in% names(cox_results)) {
  "p.value"
} else {
  stop("P-value column not found.")
}

need_cols <- c("Cohort", "Endpoint", "HR", "Lower95CI", "Upper95CI", p_col)
missing_cols <- setdiff(need_cols, names(cox_results))

if (length(missing_cols) > 0) {
  stop(paste("Missing columns:", paste(missing_cols, collapse = ", ")))
}

## ------------------------------------------------------------------
## 5. Build manuscript-style Table 3
## ------------------------------------------------------------------

table3_raw <- cox_results %>%
  mutate(
    Cohort = factor(Cohort, levels = c("Original", "PSM", "IPTW")),
    Endpoint = factor(
      clean_endpoint(Endpoint),
      levels = c("Disease-free survival", "Overall survival")
    ),
    `HR (95% CI)` = format_ci(HR, Lower95CI, Upper95CI),
    `P value` = format_p(.data[[p_col]])
  ) %>%
  arrange(Cohort, Endpoint) %>%
  select(
    Cohort,
    Endpoint,
    `HR (95% CI)`,
    `P value`
  ) %>%
  mutate(
    Cohort = as.character(Cohort),
    Endpoint = as.character(Endpoint)
  )

table3 <- table3_raw

table3$Cohort[duplicated(table3$Cohort)] <- ""

## ------------------------------------------------------------------
## 6. Export styled Excel
## ------------------------------------------------------------------

wb <- createWorkbook()
addWorksheet(wb, "Table 3")

## table title
writeData(
  wb,
  sheet = "Table 3",
  x = "Table 3. Cox regression analyses for disease-free survival and overall survival",
  startRow = 1,
  startCol = 1
)

## table body
writeData(
  wb,
  sheet = "Table 3",
  x = table3,
  startRow = 3,
  startCol = 1,
  colNames = TRUE
)

n_row <- nrow(table3)
n_col <- ncol(table3)

title_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 11,
  textDecoration = "bold",
  halign = "left",
  valign = "center"
)

header_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  textDecoration = "bold",
  halign = "center",
  valign = "center",
  border = c("top", "bottom"),
  borderStyle = "thin",
  borderColour = "black"
)

body_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  halign = "center",
  valign = "center"
)

left_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  halign = "left",
  valign = "center"
)

bottom_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  halign = "center",
  valign = "center",
  border = "bottom",
  borderStyle = "thin",
  borderColour = "black"
)

bottom_left_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 10,
  halign = "left",
  valign = "center",
  border = "bottom",
  borderStyle = "thin",
  borderColour = "black"
)

footnote_style <- createStyle(
  fontName = "Times New Roman",
  fontSize = 9,
  halign = "left",
  valign = "top",
  wrapText = TRUE
)

addStyle(
  wb,
  sheet = "Table 3",
  style = title_style,
  rows = 1,
  cols = 1,
  gridExpand = TRUE
)

addStyle(
  wb,
  sheet = "Table 3",
  style = header_style,
  rows = 3,
  cols = 1:n_col,
  gridExpand = TRUE
)

addStyle(
  wb,
  sheet = "Table 3",
  style = body_style,
  rows = 4:(3 + n_row),
  cols = 1:n_col,
  gridExpand = TRUE
)

addStyle(
  wb,
  sheet = "Table 3",
  style = left_style,
  rows = 4:(3 + n_row),
  cols = 1:2,
  gridExpand = TRUE
)

addStyle(
  wb,
  sheet = "Table 3",
  style = bottom_style,
  rows = 3 + n_row,
  cols = 1:n_col,
  gridExpand = TRUE,
  stack = TRUE
)

addStyle(
  wb,
  sheet = "Table 3",
  style = bottom_left_style,
  rows = 3 + n_row,
  cols = 1:2,
  gridExpand = TRUE,
  stack = TRUE
)

## footnote
footnote_row <- 5 + n_row

writeData(
  wb,
  sheet = "Table 3",
  x = "HRs are for laparoscopic gastrectomy compared with open gastrectomy. DFS, disease-free survival; OS, overall survival; PSM, propensity score matching; IPTW, inverse probability of treatment weighting; HR, hazard ratio; CI, confidence interval.",
  startRow = footnote_row,
  startCol = 1
)

mergeCells(
  wb,
  sheet = "Table 3",
  cols = 1:n_col,
  rows = footnote_row
)

addStyle(
  wb,
  sheet = "Table 3",
  style = footnote_style,
  rows = footnote_row,
  cols = 1:n_col,
  gridExpand = TRUE
)

## layout
setColWidths(wb, "Table 3", cols = 1, widths = 14)
setColWidths(wb, "Table 3", cols = 2, widths = 28)
setColWidths(wb, "Table 3", cols = 3, widths = 18)
setColWidths(wb, "Table 3", cols = 4, widths = 12)

setRowHeights(wb, "Table 3", rows = 1, heights = 22)
setRowHeights(wb, "Table 3", rows = 3:(3 + n_row), heights = 20)
setRowHeights(wb, "Table 3", rows = footnote_row, heights = 42)

freezePane(wb, "Table 3", firstActiveRow = 4)

## remove gridline
showGridLines(wb, "Table 3", showGridLines = FALSE)

saveWorkbook(
  wb,
  file = "results/Final_Tables/Table3_Cox_regression_styled.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 7. Print output
## ------------------------------------------------------------------

print(table3)

cat("\nExported:\n")
cat("results/Final_Tables/Table3_Cox_regression_styled.xlsx\n")