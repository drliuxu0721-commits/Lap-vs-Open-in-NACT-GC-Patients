#!/usr/bin/env python3
"""
17_figure1_pptx.py
Editable PowerPoint version of Figure 1 (IJC-style study flow diagram).
Boxes, text and triangles are NATIVE PowerPoint shapes (fully editable);
the 4 source icons (stomach, instruments, KM, forest) and the red/blue
patient figures are embedded as pictures from results/Panels/fig1_assets/.
Layout mirrors the verified SVG (920x700 coordinate space) 1:1.
"""

import os
from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn

root   = "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
assets = os.path.join(root, "results/Panels/fig1_assets")
out    = os.path.join(root, "results/Panels/Figure1_CONSORT.pptx")

# SVG coordinate space -> slide EMU (920 px wide -> 10 in)
SW, SH = 920, 700
EMU_PER_IN = 914400
SCALE = 10.0 / SW                      # inches per px (uniform)
def E(px): return Emu(int(round(px * SCALE * EMU_PER_IN)))
def PT(px): return Pt(px * 720.0 / SW)  # px font size -> pt

C = lambda h: RGBColor(int(h[0:2],16), int(h[2:4],16), int(h[4:6],16))
GRAY = C("5a5a5a")

prs = Presentation()
prs.slide_width  = E(SW)
prs.slide_height = E(SH)
slide = prs.slides.add_slide(prs.slide_layouts[6])   # blank


def box(x, y, w, h, fill, line, lw=1.5, radius=0.08):
    sp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, E(x), E(y), E(w), E(h))
    sp.fill.solid(); sp.fill.fore_color.rgb = C(fill)
    sp.line.color.rgb = C(line); sp.line.width = Pt(lw)
    try: sp.adjustments[0] = radius
    except Exception: pass
    sp.shadow.inherit = False
    return sp


def text(x, y_base, w, s, fpx, color, bold=True, align="l"):
    fpt_h = fpx * 1.7
    cy = y_base - 0.35 * fpx
    left = x - w/2 if align == "c" else x
    tb = slide.shapes.add_textbox(E(left), E(cy - fpt_h/2), E(w), E(fpt_h))
    tf = tb.text_frame; tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    for m in ("margin_left","margin_right","margin_top","margin_bottom"):
        setattr(tf, m, 0)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER if align == "c" else PP_ALIGN.LEFT
    r = p.add_run(); r.text = s
    f = r.font; f.size = PT(fpx); f.bold = bold; f.name = "Arial"; f.color.rgb = color
    return tb


def multiline(x, y_top, w, lines, fpx, color):
    fpt_h = fpx * 1.55 * len(lines)
    tb = slide.shapes.add_textbox(E(x), E(y_top), E(w), E(fpt_h))
    tf = tb.text_frame; tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.TOP
    for m in ("margin_left","margin_right","margin_top","margin_bottom"):
        setattr(tf, m, 0)
    for i, (s, bold) in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        r = p.add_run(); r.text = s
        f = r.font; f.size = PT(fpx); f.bold = bold; f.name = "Arial"; f.color.rgb = color


def tri(x, y, w, h, fill):
    sp = slide.shapes.add_shape(MSO_SHAPE.ISOSCELES_TRIANGLE, E(x), E(y), E(w), E(h))
    sp.fill.solid(); sp.fill.fore_color.rgb = C(fill); sp.line.fill.background()
    sp.shadow.inherit = False
    return sp


def pic(name, x, y, w, h):
    slide.shapes.add_picture(os.path.join(assets, name), E(x), E(y), E(w), E(h))


def line(x1, y1, x2, y2, arrow=False):
    cn = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, E(x1), E(y1), E(x2), E(y2))
    cn.line.color.rgb = GRAY; cn.line.width = Pt(1.2)
    if arrow:
        ln = cn.line._get_or_add_ln()
        te = ln.makeelement(qn('a:tailEnd'), {'type':'triangle','w':'med','len':'med'})
        ln.append(te)


# ---- Header (navy) + VS ----
box(180, 20, 560, 132, "1f3a5f", "1f3a5f", lw=0, radius=0.09)
text(460, 50, 560, "1283 patients with gastric cancer who underwent", 15.5, C("ffffff"), align="c")
text(460, 71, 560, "surgery after neoadjuvant chemotherapy", 15.5, C("ffffff"), align="c")
pic("person_hblue.png", 262, 92, 22, 27)
text(296, 112, 130, "Laparoscopic", 13.5, C("ffffff"))
text(345, 130, 110, "gastrectomy", 11, C("cfe0f1"), bold=False, align="c")
ovl = slide.shapes.add_shape(MSO_SHAPE.OVAL, E(442), E(94), E(36), E(36))
ovl.fill.solid(); ovl.fill.fore_color.rgb = C("ffffff"); ovl.line.fill.background(); ovl.shadow.inherit=False
text(460, 118, 36, "VS", 16, C("1f3a5f"), align="c")
pic("person_hred.png", 556, 92, 22, 27)
text(590, 112, 90, "Open", 13.5, C("ffffff"))
text(600, 130, 90, "gastrectomy", 11, C("f3d4d4"), bold=False, align="c")

# ---- Exclusion box ----
box(648, 178, 256, 106, "e2efda", "70ad47")
multiline(664, 190, 232, [
    ("Patients excluded (n = 133)", True),
    ("-  Laparoscopic exploration", False),
    ("    without resection (n = 97)", False),
    ("-  Palliative gastrojejunostomy", False),
    ("    (n = 36)", False),
], 11.5, C("375623"))

# ---- Connectors: header -> cohorts ----
line(460, 152, 460, 272)
line(460, 212, 646, 212, arrow=True)
line(460, 272, 172, 272); line(172, 272, 172, 298, arrow=True)
line(460, 272, 460, 298, arrow=True)
line(460, 272, 748, 272); line(748, 272, 748, 298, arrow=True)

# ---- Cohort boxes ----
def cohort(x, fill, border, title_col, title, n_open, n_lap):
    box(x, 300, 248, 122, fill, border)
    text(x+124, 324, 240, title, 13, C(title_col), align="c")
    pic("person_cred.png",  x+24, 342, 18, 23)
    text(x+52, 360, 180, n_open, 12.5, C("1a1a1a"), bold=False)
    pic("person_cblue.png", x+24, 378, 18, 23)
    text(x+52, 396, 180, n_lap, 12.5, C("1a1a1a"), bold=False)

cohort(48,  "d9ead5", "52af6d", "2f5218", "Overall cohort (unadjusted)", "Open, n = 638", "Laparoscopic, n = 512")
cohort(336, "f4d1c1", "d3899a", "843c0c", "PSM cohort (1:1 matched)",     "Open, n = 477", "Laparoscopic, n = 477")
cohort(624, "ffe699", "bf9000", "7f6000", "IPTW cohort (weighted)",       "Open, n = 637.31", "Laparoscopic, n = 509.49")

# ---- Connectors: cohorts -> outcomes ----
line(172, 422, 172, 446); line(460, 422, 460, 446); line(748, 422, 748, 446)
line(172, 446, 748, 446)
line(240, 446, 240, 470, arrow=True); line(680, 446, 680, 470, arrow=True)

# ---- Pathological & surgical outcomes (blue) ----
box(40, 472, 400, 200, "ffffff", "2e75b6", lw=2, radius=0.08)
text(240, 500, 400, "Pathological and surgical outcomes", 14.5, C("1f4e79"), align="c")
pic("stomach.png", 56, 512, 74, 92)
pic("instruments.png", 50, 606, 86, 58)
for ty, col, label in [(518,"ff0000","MPR, pCR, Mandard TRG"),
                       (552,"2e75b6","ypT stage, ypN stage"),
                       (594,"ff0000","R0 margin, complications"),
                       (628,"2e75b6","Operation time, total LNs")]:
    tri(158, ty, 16, 14, col); text(182, ty+14, 250, label, 12.5, C("1a1a1a"), bold=False)

# ---- Survival outcomes (purple) ----
box(480, 472, 400, 200, "ffffff", "7030a0", lw=2, radius=0.08)
text(680, 500, 400, "Survival outcomes", 14.5, C("7030a0"), align="c")
pic("km.png", 500, 516, 106, 72)
pic("forest.png", 506, 596, 94, 66)
for ty, col, label in [(526,"ff0000","Kaplan-Meier curves"),
                       (566,"2e75b6","Cox regression models"),
                       (606,"7030a0","Subgroup & sensitivity analyses")]:
    tri(620, ty, 16, 14, col); text(644, ty+14, 250, label, 12.5, C("1a1a1a"), bold=False)

prs.save(out)
print("PPTX saved:", out)
