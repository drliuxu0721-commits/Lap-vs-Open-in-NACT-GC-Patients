################################################################################
# 11_format_table2_surgical_pathological.R
# Table 2: Surgical and pathological outcomes across three cohorts
# Style matches existing Table 1/2/3 in 投稿/:
#   - A4 landscape, Times New Roman 9pt
#   - 12-column three-line table with empty spacer columns between cohorts
#   - Variable name bold (category header rows); P<0.05 bold + asterisk
#   - "n (X.X%)" categorical; "med [Q1;Q3]" continuous; P to 3 decimals
################################################################################

rm(list = ls())

library(dplyr)
library(tibble)
library(stringr)
library(openxlsx)
library(flextable)
library(officer)

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Final_Tables", showWarnings = FALSE, recursive = TRUE)

raw <- read.csv("results/Tables/table2_surgical_pathological_outcomes_integrated.csv",
                check.names = TRUE, stringsAsFactors = FALSE)

## Sample sizes
n_orig_open <- as.numeric(raw$Original_Open[1])
n_orig_lap  <- as.numeric(raw$Original_Laparoscopic[1])
n_psm_open  <- as.numeric(raw$PSM_Open[1])
n_psm_lap   <- as.numeric(raw$PSM_Laparoscopic[1])
n_iptw_open <- as.numeric(raw$IPTW_Open[1])
n_iptw_lap  <- as.numeric(raw$IPTW_Laparoscopic[1])

## ------------------------------------------------------------------
## Formatting helpers (matched to Table 1 conventions)
## ------------------------------------------------------------------

# "190.00 [155.00, 228.75]"  ->  "190.0 [155.0;228.8]"
fmt_median <- function(s, digits = 1) {
  if (is.na(s) || s == "") return("")
  m <- str_match(s, "([\\d.\\-]+)\\s*\\[\\s*([\\d.\\-]+)\\s*,\\s*([\\d.\\-]+)\\s*\\]")
  if (any(is.na(m))) return(s)
  fc <- function(x) formatC(round(as.numeric(x), digits), format = "f", digits = digits)
  paste0(fc(m[1, 2]), " [", fc(m[1, 3]), ";", fc(m[1, 4]), "]")
}

# "606 (94.98)"  ->  "606 (95.0%)"
fmt_n_pct <- function(s, pct_digits = 1) {
  if (is.na(s) || s == "") return("")
  m <- str_match(s, "([\\d.]+)\\s*\\(\\s*([\\d.]+)\\s*\\)")
  if (any(is.na(m))) return(s)
  n   <- round(as.numeric(m[1, 2]))
  pct <- formatC(round(as.numeric(m[1, 3]), pct_digits), format = "f", digits = pct_digits)
  paste0(n, " (", pct, "%)")
}

# P value -> list(text, sig) for use in compose()
fmt_p_obj <- function(p) {
  if (is.na(p) || p == "") return(list(text = "", sig = FALSE))
  if (str_detect(p, "<")) return(list(text = p, sig = TRUE))
  pn <- suppressWarnings(as.numeric(p))
  if (is.na(pn)) return(list(text = p, sig = FALSE))
  sig <- pn < 0.05
  txt <- if (pn < 0.001) "<0.001" else formatC(round(pn, 3), format = "f", digits = 3)
  list(text = txt, sig = sig)
}

## ------------------------------------------------------------------
## Build rows into a tibble
##
## Columns:
##   Variable, Orig_Open, Orig_Lap, Orig_P, sep1,
##              PSM_Open,  PSM_Lap,  PSM_P,  sep2,
##              IPTW_Open, IPTW_Lap, IPTW_P
##   plus meta: bold_var (T/F first col), row_type (cont/cat_header/cat_level)
## ------------------------------------------------------------------

rows <- list()
push <- function(...) rows[[length(rows) + 1]] <<- tibble(...)

# Continuous (single row, variable name bold, P shown)
add_cont <- function(label, idx, digits = 1) {
  push(Variable  = label,
       Orig_Open = fmt_median(raw$Original_Open[idx], digits),
       Orig_Lap  = fmt_median(raw$Original_Laparoscopic[idx], digits),
       Orig_P    = raw$Original_p[idx],
       sep1 = "",
       PSM_Open  = fmt_median(raw$PSM_Open[idx], digits),
       PSM_Lap   = fmt_median(raw$PSM_Laparoscopic[idx], digits),
       PSM_P     = raw$PSM_p[idx],
       sep2 = "",
       IPTW_Open = fmt_median(raw$IPTW_Open[idx], digits),
       IPTW_Lap  = fmt_median(raw$IPTW_Laparoscopic[idx], digits),
       IPTW_P    = raw$IPTW_p[idx],
       row_type  = "cont")
}

# Categorical category-header row (variable name bold, P shown, counts empty)
add_cat_header <- function(label, idx) {
  push(Variable  = label,
       Orig_Open = "", Orig_Lap = "",
       Orig_P    = raw$Original_p[idx],
       sep1 = "",
       PSM_Open  = "", PSM_Lap = "",
       PSM_P     = raw$PSM_p[idx],
       sep2 = "",
       IPTW_Open = "", IPTW_Lap = "",
       IPTW_P    = raw$IPTW_p[idx],
       row_type  = "cat_header")
}

# Categorical level row (indented level name, counts, P blank)
add_cat_level <- function(level_label, idx) {
  push(Variable  = paste0("   ", level_label),
       Orig_Open = fmt_n_pct(raw$Original_Open[idx]),
       Orig_Lap  = fmt_n_pct(raw$Original_Laparoscopic[idx]),
       Orig_P    = "",
       sep1 = "",
       PSM_Open  = fmt_n_pct(raw$PSM_Open[idx]),
       PSM_Lap   = fmt_n_pct(raw$PSM_Laparoscopic[idx]),
       PSM_P     = "",
       sep2 = "",
       IPTW_Open = fmt_n_pct(raw$IPTW_Open[idx]),
       IPTW_Lap  = fmt_n_pct(raw$IPTW_Laparoscopic[idx]),
       IPTW_P    = "",
       row_type  = "cat_level")
}

# Multi-level convenience
add_multilevel <- function(label, first_idx, n_levels) {
  add_cat_header(label, first_idx)
  for (i in 0:(n_levels - 1)) {
    r <- first_idx + i
    add_cat_level(raw$Original_level[r], r)
  }
}

# Binary outcome shown as a single row
# `idx` is the "No" row (carries P); `idx+1` is the "Yes" row (counts).
add_binary <- function(label, idx) {
  yes <- idx + 1
  push(Variable  = label,
       Orig_Open = fmt_n_pct(raw$Original_Open[yes]),
       Orig_Lap  = fmt_n_pct(raw$Original_Laparoscopic[yes]),
       Orig_P    = raw$Original_p[idx],
       sep1 = "",
       PSM_Open  = fmt_n_pct(raw$PSM_Open[yes]),
       PSM_Lap   = fmt_n_pct(raw$PSM_Laparoscopic[yes]),
       PSM_P     = raw$PSM_p[idx],
       sep2 = "",
       IPTW_Open = fmt_n_pct(raw$IPTW_Open[yes]),
       IPTW_Lap  = fmt_n_pct(raw$IPTW_Laparoscopic[yes]),
       IPTW_P    = raw$IPTW_p[idx],
       row_type  = "cont")  # treat as continuous-style row: bold var, single line
}

## ------------------------------------------------------------------
## Build Table 2 — row order
## ------------------------------------------------------------------

add_cont   ("Operation time, min",                idx = 2,  digits = 1)
add_cont   ("Lymph nodes harvested",              idx = 3,  digits = 1)
add_cont   ("Positive lymph nodes",               idx = 4,  digits = 1)
add_binary ("R0 resection",                       idx = 5)
add_multilevel("ypT stage",     first_idx = 7,  n_levels = 7)
add_multilevel("ypN stage",     first_idx = 14, n_levels = 5)
add_multilevel("Mandard TRG",   first_idx = 19, n_levels = 5)
add_binary ("Major pathologic response",          idx = 24)
add_binary ("Pathologic complete response",       idx = 26)
add_binary ("Perineural invasion",                idx = 28)
add_binary ("Lymphovascular invasion",            idx = 30)

tbl <- bind_rows(rows)

## ------------------------------------------------------------------
## CSV archive (without spacers, P values raw)
## ------------------------------------------------------------------

write.csv(tbl %>% select(-sep1, -sep2),
          "results/Final_Tables/Table2_surgical_pathological.csv",
          row.names = FALSE, fileEncoding = "UTF-8")

## ------------------------------------------------------------------
## XLSX with the same column structure
## ------------------------------------------------------------------

xlsx_df <- tbl %>% select(-row_type) %>%
  mutate(across(c(Orig_P, PSM_P, IPTW_P), function(x) {
    sapply(x, function(p) {
      o <- fmt_p_obj(p)
      if (o$sig && o$text != "") paste0(o$text, "*") else o$text
    })
  }))

wb <- createWorkbook()
addWorksheet(wb, "Table 2")

header_top <- c("",
                paste0("Overall cohort (Open=", n_orig_open,
                       ", Laparoscopic=", n_orig_lap, ")"), "", "", "",
                paste0("After PSM (Open=", n_psm_open,
                       ", Laparoscopic=", n_psm_lap, ")"), "", "", "",
                paste0("After IPTW (Open=", round(n_iptw_open, 1),
                       ", Laparoscopic=", round(n_iptw_lap, 1), ")"), "", "")
header_sub <- c("",
                "Open", "Laparoscopic", "P value", "",
                "Open", "Laparoscopic", "P value", "",
                "Open", "Laparoscopic", "P value")

writeData(wb, "Table 2", as.data.frame(t(header_top)), startRow = 1, colNames = FALSE)
writeData(wb, "Table 2", as.data.frame(t(header_sub)), startRow = 2, colNames = FALSE)
writeData(wb, "Table 2", xlsx_df, startRow = 3, colNames = FALSE)

mergeCells(wb, "Table 2", cols = 2:4,  rows = 1)
mergeCells(wb, "Table 2", cols = 6:8,  rows = 1)
mergeCells(wb, "Table 2", cols = 10:12, rows = 1)

header_style <- createStyle(textDecoration = "bold", halign = "center", valign = "center")
addStyle(wb, "Table 2", header_style, rows = 1:2, cols = 1:12, gridExpand = TRUE)

# Bold variable name on "cont" and "cat_header" rows (col 1)
bold_var_idx <- which(tbl$row_type %in% c("cont", "cat_header")) + 2
addStyle(wb, "Table 2",
         createStyle(textDecoration = "bold"),
         rows = bold_var_idx, cols = 1,
         gridExpand = TRUE, stack = TRUE)

setColWidths(wb, "Table 2", cols = 1, widths = 32)
setColWidths(wb, "Table 2", cols = c(2, 3, 4, 6, 7, 8, 10, 11, 12), widths = 13)
setColWidths(wb, "Table 2", cols = c(5, 9), widths = 2)

saveWorkbook(wb, "results/Final_Tables/Table2_surgical_pathological.xlsx",
             overwrite = TRUE)

## ------------------------------------------------------------------
## DOCX via flextable — match Table 1 style precisely
## ------------------------------------------------------------------

# col_keys defines the visible column order (and excludes row_type)
col_keys <- c("Variable",
              "Orig_Open", "Orig_Lap", "Orig_P", "sep1",
              "PSM_Open",  "PSM_Lap",  "PSM_P",  "sep2",
              "IPTW_Open", "IPTW_Lap", "IPTW_P")

ft <- flextable(tbl, col_keys = col_keys)

# Header labels — sample sizes go INSIDE the Open/Laparoscopic sub-header
# cells (matching Table 1); top cohort row carries clean names only.
# IPTW N shown with 2 decimals as in Table 1 (N=637.31 / 509.49).
ft <- ft %>%
  set_header_labels(
    Variable  = "",
    Orig_Open = paste0("Open N=", n_orig_open),
    Orig_Lap  = paste0("Laparoscopic N=", n_orig_lap),
    Orig_P    = "P",
    sep1      = "",
    PSM_Open  = paste0("Open N=", n_psm_open),
    PSM_Lap   = paste0("Laparoscopic N=", n_psm_lap),
    PSM_P     = "P",
    sep2      = "",
    IPTW_Open = paste0("Open N=", sprintf("%.2f", n_iptw_open)),
    IPTW_Lap  = paste0("Laparoscopic N=", sprintf("%.2f", n_iptw_lap)),
    IPTW_P    = "P"
  ) %>%
  add_header_row(
    values   = c("",
                 "Overall cohort (unadjusted)", "",
                 "After PSM", "",
                 "After IPTW"),
    colwidths = c(1, 3, 1, 3, 1, 3),
    top       = TRUE
  )

# Compose P columns: bold + "*" when significant
compose_p <- function(ft, j, pvec) {
  for (i in seq_along(pvec)) {
    o <- fmt_p_obj(pvec[i])
    if (o$text == "") next
    if (o$sig) {
      ft <- compose(ft, i = i, j = j, part = "body",
                    value = as_paragraph(
                      as_chunk(paste0(o$text, "*"),
                               props = fp_text(font.family = "Times New Roman",
                                               font.size   = 6.5,
                                               bold        = TRUE))
                    ))
    } else {
      ft <- compose(ft, i = i, j = j, part = "body",
                    value = as_paragraph(
                      as_chunk(o$text,
                               props = fp_text(font.family = "Times New Roman",
                                               font.size   = 6.5))
                    ))
    }
  }
  ft
}

ft <- compose_p(ft, "Orig_P", tbl$Orig_P)
ft <- compose_p(ft, "PSM_P",  tbl$PSM_P)
ft <- compose_p(ft, "IPTW_P", tbl$IPTW_P)

# Bold variable name on cont and cat_header rows (column 1)
bold_rows <- which(tbl$row_type %in% c("cont", "cat_header"))
ft <- ft %>%
  bold(i = bold_rows, j = "Variable", part = "body")

# Theme: three-line booktabs, Times New Roman 6.5pt (matching Table 1),
# all centered except col 1. Column widths sized to fit A4 landscape
# (usable width ~9.7"): 2.1 + 9*0.78 + 2*0.12 = 9.36".
ft <- ft %>%
  theme_booktabs() %>%
  font(fontname = "Times New Roman", part = "all") %>%
  fontsize(size = 6.5, part = "all") %>%
  bold(part = "header") %>%
  align(align = "center", part = "header") %>%
  align(j = 1, align = "left", part = "body") %>%
  align(j = c("Orig_Open", "Orig_Lap", "Orig_P",
              "PSM_Open",  "PSM_Lap",  "PSM_P",
              "IPTW_Open", "IPTW_Lap", "IPTW_P"),
        align = "center", part = "body") %>%
  padding(padding.top = 1, padding.bottom = 1, part = "all") %>%
  width(j = "Variable",  width = 2.1) %>%
  width(j = c("Orig_Open","Orig_Lap","Orig_P",
              "PSM_Open","PSM_Lap","PSM_P",
              "IPTW_Open","IPTW_Lap","IPTW_P"), width = 0.78) %>%
  width(j = c("sep1","sep2"), width = 0.12)

## ------------------------------------------------------------------
## Header rule logic — replicate Table 1 exactly (four-line layout):
##   (1) full-width top line (above cohort group names)
##   (2) spanner lines under each cohort group name only (header row 1),
##       broken at the Variable column and the spacer columns
##   (3) full-width line under the complete header (below sub-header row)
##   (4) full-width bottom line under the body
## ------------------------------------------------------------------
rule <- fp_border(color = "black", width = 0.5)

ft <- ft %>%
  border_remove() %>%
  hline_top(part = "header", border = rule) %>%
  hline(i = 1, j = c("Orig_Open", "Orig_Lap", "Orig_P"),
        part = "header", border = rule) %>%
  hline(i = 1, j = c("PSM_Open", "PSM_Lap", "PSM_P"),
        part = "header", border = rule) %>%
  hline(i = 1, j = c("IPTW_Open", "IPTW_Lap", "IPTW_P"),
        part = "header", border = rule) %>%
  hline_bottom(part = "header", border = rule) %>%
  hline_bottom(part = "body", border = rule)

# Page setup: A4 landscape, margins matching old tables
ps <- prop_section(
  page_size    = page_size(width = 16838 / 1440, height = 11906 / 1440,
                           orient = "landscape"),
  page_margins = page_mar(top = 1800 / 1440, bottom = 1800 / 1440,
                          left = 1440 / 1440, right = 1440 / 1440,
                          header = 851 / 1440, footer = 992 / 1440,
                          gutter = 0)
)

title_fp <- fp_text(font.family = "Times New Roman", font.size = 11, bold = TRUE)
note_fp  <- fp_text(font.family = "Times New Roman", font.size = 9)

doc <- read_docx() %>%
  body_add_fpar(fpar(ftext(
    "Table 2. Surgical and pathological outcomes according to surgical approach.",
    prop = title_fp))) %>%
  body_add_flextable(ft) %>%
  body_add_fpar(fpar(ftext("*P<0.05", prop = note_fp))) %>%
  body_add_fpar(fpar(ftext(
    paste0("Abbreviations: IPTW, inverse probability of treatment weighting; ",
           "PSM, propensity score matching; ",
           "TRG, tumor regression grade; ",
           "ypN, pathological nodal stage after neoadjuvant chemotherapy; ",
           "ypT, pathological tumor stage after neoadjuvant chemotherapy."),
    prop = note_fp))) %>%
  body_set_default_section(value = ps)

print(doc, target = "results/Final_Tables/Table2_surgical_pathological.docx")

file.copy(
  from = "results/Final_Tables/Table2_surgical_pathological.docx",
  to   = "投稿/Table 2.docx",
  overwrite = TRUE
)

cat("\n============================================================\n")
cat("Table 2 saved (CSV/XLSX/DOCX) in results/Final_Tables/\n")
cat("Style matched to existing Table 1/2/3 in 投稿/.\n")
cat("============================================================\n")
