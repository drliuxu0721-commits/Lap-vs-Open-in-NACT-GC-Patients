################################################################################
# 02_surgical_pathological_outcomes.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# Surgical and pathological outcomes in Original, PSM, and IPTW cohorts
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(dplyr)
library(tibble)
library(stringr)
library(tableone)
library(survey)
library(openxlsx)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Tables", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import datasets
## ------------------------------------------------------------------

original_df <- read.csv("results/analysis_dataset_before_psm_iptw.csv",
                        header = TRUE, check.names = TRUE)

psm_df <- read.csv("results/PSM/matched_dataset.csv",
                   header = TRUE, check.names = TRUE)

iptw_df <- read.csv("results/IPTW/data_after_iptw.csv",
                    header = TRUE, check.names = TRUE)

## ------------------------------------------------------------------
## 4. Variable formatting function
## ------------------------------------------------------------------

format_data <- function(dat) {
  
  ## treatment variable
  if (!"treat" %in% names(dat)) {
    dat$treat <- dat$Surgical.approach
  }
  
  dat$treat <- factor(dat$treat, levels = c("Open", "Laparoscopic"))
  
  ## Derived variables
  dat <- dat %>%
    mutate(
      R0.resection = ifelse(Margin == "R0", "Yes", "No"),
      
      Any.complication = case_when(
        Complication == "No" ~ "No",
        is.na(Complication) ~ NA_character_,
        TRUE ~ "Yes"
      ),
      
      CD.ge3 = case_when(
        CD == "Higher than grade 3" ~ "Yes",
        CD == "Lower than grade 3" ~ "No",
        CD == "No" ~ "No",
        is.na(CD) ~ NA_character_,
        TRUE ~ NA_character_
      )
    )
  
  factor_vars <- c(
    "treat",
    "Surgical.procedure",
    "ypT",
    "ypN",
    "ypM",
    "Peritoneal.washing.cytology",
    "Mandard.TRG",
    "MPR",
    "pCR",
    "Margin",
    "R0.resection",
    "Nerve.Invasion",
    "Lymphovascular.Tumor.Thrombus",
    "Complication",
    "CD",
    "CD.ge3",
    "Perioperative.mortality"
  )
  
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  
  numeric_vars <- c(
    "Operation.time",
    "Positive.Lymph.Nodes.Count",
    "Total.Lymph.Nodes.Count"
  )
  
  numeric_vars <- intersect(numeric_vars, names(dat))
  dat[, numeric_vars] <- lapply(dat[, numeric_vars], as.numeric)
  
  return(dat)
}

original_df <- format_data(original_df)
psm_df <- format_data(psm_df)
iptw_df <- format_data(iptw_df)

## ------------------------------------------------------------------
## 5. Define surgical and pathological outcome variables
## ------------------------------------------------------------------

outcome_vars <- c(
  "Operation.time",
  "Total.Lymph.Nodes.Count",
  "Positive.Lymph.Nodes.Count",
  "R0.resection",
  "ypT",
  "ypN",
  "Mandard.TRG",
  "MPR",
  "pCR",
  "Nerve.Invasion",
  "Lymphovascular.Tumor.Thrombus",
  "Any.complication",
  "CD.ge3",
  "Perioperative.mortality"
)

outcome_vars <- intersect(outcome_vars, names(original_df))

cat_vars <- c(
  "R0.resection",
  "ypT",
  "ypN",
  "Mandard.TRG",
  "MPR",
  "pCR",
  "Nerve.Invasion",
  "Lymphovascular.Tumor.Thrombus",
  "Any.complication",
  "CD.ge3",
  "Perioperative.mortality"
)

cat_vars <- intersect(cat_vars, outcome_vars)

nonnorm_vars <- c(
  "Operation.time",
  "Total.Lymph.Nodes.Count",
  "Positive.Lymph.Nodes.Count"
)

nonnorm_vars <- intersect(nonnorm_vars, outcome_vars)

## ------------------------------------------------------------------
## 6. Function: unweighted TableOne
## ------------------------------------------------------------------

make_unweighted_table <- function(dat, cohort_name) {
  
  tab <- CreateTableOne(
    vars       = outcome_vars,
    strata     = "treat",
    data       = dat,
    factorVars = cat_vars,
    test       = TRUE,
    smd        = TRUE
  )
  
  mat <- print(
    tab,
    quote         = FALSE,
    noSpaces      = TRUE,
    showAllLevels = TRUE,
    printToggle   = FALSE,
    smd           = TRUE,
    nonnormal     = nonnorm_vars,
    contDigits    = 2,
    catDigits     = 2,
    smdDigits     = 3,
    pDigits       = 3
  )
  
  df <- as.data.frame(mat, stringsAsFactors = FALSE) %>%
    rownames_to_column("Variable")
  
  names(df) <- paste0(cohort_name, "_", names(df))
  names(df)[1] <- "Variable"
  
  return(df)
}

## ------------------------------------------------------------------
## 7. Function: IPTW TableOne
## ------------------------------------------------------------------

make_iptw_table <- function(dat, cohort_name) {
  
  design <- svydesign(
    ids = ~1,
    weights = ~iptw_weight,
    data = dat
  )
  
  tab <- svyCreateTableOne(
    vars       = outcome_vars,
    strata     = "treat",
    data       = design,
    factorVars = cat_vars,
    test       = TRUE,
    smd        = TRUE
  )
  
  mat <- print(
    tab,
    quote         = FALSE,
    noSpaces      = TRUE,
    showAllLevels = TRUE,
    printToggle   = FALSE,
    smd           = TRUE,
    nonnormal     = nonnorm_vars,
    contDigits    = 2,
    catDigits     = 2,
    smdDigits     = 3,
    pDigits       = 3
  )
  
  df <- as.data.frame(mat, stringsAsFactors = FALSE) %>%
    rownames_to_column("Variable")
  
  names(df) <- paste0(cohort_name, "_", names(df))
  names(df)[1] <- "Variable"
  
  return(df)
}

## ------------------------------------------------------------------
## 8. Generate tables
## ------------------------------------------------------------------

tab_original <- make_unweighted_table(original_df, "Original")
tab_psm      <- make_unweighted_table(psm_df, "PSM")
tab_iptw     <- make_iptw_table(iptw_df, "IPTW")

table2_integrated <- tab_original %>%
  full_join(tab_psm, by = "Variable") %>%
  full_join(tab_iptw, by = "Variable")

write.csv(
  table2_integrated,
  "results/Tables/table2_surgical_pathological_outcomes_integrated.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 9. Export to Excel
## ------------------------------------------------------------------

wb <- createWorkbook()

addWorksheet(wb, "Table 2 Outcomes")
writeData(wb, "Table 2 Outcomes", table2_integrated)

addWorksheet(wb, "Cohort size")
cohort_size <- data.frame(
  Cohort = c("Original", "PSM", "IPTW"),
  Open = c(
    sum(original_df$treat == "Open", na.rm = TRUE),
    sum(psm_df$treat == "Open", na.rm = TRUE),
    sum(iptw_df$treat == "Open", na.rm = TRUE)
  ),
  Laparoscopic = c(
    sum(original_df$treat == "Laparoscopic", na.rm = TRUE),
    sum(psm_df$treat == "Laparoscopic", na.rm = TRUE),
    sum(iptw_df$treat == "Laparoscopic", na.rm = TRUE)
  )
)
writeData(wb, "Cohort size", cohort_size)

addWorksheet(wb, "Notes")
notes <- data.frame(
  Item = c(
    "Continuous variables",
    "Categorical variables",
    "SMD",
    "Original cohort",
    "PSM cohort",
    "IPTW cohort",
    "CD.ge3",
    "R0.resection"
  ),
  Explanation = c(
    "Presented as median [IQR] by default because nonnormal_vars were specified.",
    "Presented as n (%).",
    "Standardized mean difference. SMD < 0.1 indicates acceptable balance.",
    "Unweighted comparison in the original cohort.",
    "Unweighted comparison in the matched cohort.",
    "Weighted comparison using stabilized IPTW weights.",
    "Defined as Clavien-Dindo grade III or higher.",
    "Defined as Margin == R0."
  )
)
writeData(wb, "Notes", notes)

saveWorkbook(
  wb,
  "results/Tables/table2_surgical_pathological_outcomes_integrated.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 10. Console summary
## ------------------------------------------------------------------

cat("\n============================================================\n")
cat("Table 2 surgical and pathological outcomes completed.\n")
cat("============================================================\n")

cat("\nOriginal cohort:\n")
print(table(original_df$treat, useNA = "ifany"))

cat("\nPSM cohort:\n")
print(table(psm_df$treat, useNA = "ifany"))

cat("\nIPTW cohort:\n")
print(table(iptw_df$treat, useNA = "ifany"))

cat("\nOutput files:\n")
cat("results/Tables/table2_surgical_pathological_outcomes_integrated.csv\n")
cat("results/Tables/table2_surgical_pathological_outcomes_integrated.xlsx\n")