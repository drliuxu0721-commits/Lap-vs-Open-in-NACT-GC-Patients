#!/usr/bin/env python3
"""
16_figure1_build.py
Build the IJC-style Figure 1 (study flow diagram) for the lap-vs-open study.
Authentic icons (KM curve, forest plot, surgical instruments, stomach) are
reused from the IJC manuscript source and embedded as base64 so the SVG is
self-contained. Run, then convert SVG -> PDF/PNG with rsvg (script 15).
Numbers verified from the raw-data exclusion cascade.
"""

import base64, os

root = "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
assets = os.path.join(root, "results/Panels/fig1_assets")
out_svg = os.path.join(root, "results/Panels/Figure1_CONSORT.svg")


def b64(name):
    with open(os.path.join(assets, name), "rb") as f:
        return "data:image/png;base64," + base64.b64encode(f.read()).decode()


km, forest, instr, stomach = (b64("km.png"), b64("forest.png"),
                              b64("instruments.png"), b64("stomach.png"))

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 920 700" font-family="Arial, Helvetica, sans-serif">
  <defs>
    <symbol id="person" viewBox="0 0 20 25">
      <circle cx="10" cy="6" r="5"/>
      <path d="M2,25 C2,13.5 18,13.5 18,25 Z"/>
    </symbol>
    <marker id="ar" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <path d="M0,0 L10,5 L0,10 z" fill="#5a5a5a"/>
    </marker>
  </defs>

  <rect x="0" y="0" width="920" height="700" fill="#ffffff"/>

  <!-- Header (navy) with VS -->
  <rect x="180" y="20" width="560" height="132" rx="12" fill="#1f3a5f"/>
  <text x="460" y="50" text-anchor="middle" fill="#ffffff" font-size="15.5" font-weight="bold">1283 patients with gastric cancer who underwent</text>
  <text x="460" y="71" text-anchor="middle" fill="#ffffff" font-size="15.5" font-weight="bold">surgery after neoadjuvant chemotherapy</text>
  <use xlink:href="#person" x="262" y="92" width="22" height="27" fill="#5b9bd5"/>
  <text x="296" y="112" fill="#ffffff" font-size="13.5" font-weight="bold">Laparoscopic</text>
  <text x="345" y="130" text-anchor="middle" fill="#cfe0f1" font-size="11">gastrectomy</text>
  <circle cx="460" cy="112" r="18" fill="#ffffff"/>
  <text x="460" y="118" text-anchor="middle" fill="#1f3a5f" font-size="16" font-weight="bold" font-style="italic">VS</text>
  <use xlink:href="#person" x="556" y="92" width="22" height="27" fill="#e06666"/>
  <text x="590" y="112" fill="#ffffff" font-size="13.5" font-weight="bold">Open</text>
  <text x="600" y="130" text-anchor="middle" fill="#f3d4d4" font-size="11">gastrectomy</text>

  <!-- Exclusion box -->
  <rect x="648" y="178" width="256" height="106" rx="8" fill="#e2efda" stroke="#70ad47" stroke-width="1.5"/>
  <text x="664" y="200" fill="#375623" font-size="12.5" font-weight="bold">Patients excluded (n = 133)</text>
  <text x="664" y="221" fill="#375623" font-size="11.5">- Laparoscopic exploration</text>
  <text x="664" y="237" fill="#375623" font-size="11.5">  without resection (n = 97)</text>
  <text x="664" y="258" fill="#375623" font-size="11.5">- Palliative gastrojejunostomy</text>
  <text x="664" y="274" fill="#375623" font-size="11.5">  (n = 36)</text>

  <!-- Connectors: header -> cohorts -->
  <path d="M460,152 L460,272" fill="none" stroke="#5a5a5a" stroke-width="1.6"/>
  <path d="M460,212 L646,212" fill="none" stroke="#5a5a5a" stroke-width="1.6" marker-end="url(#ar)"/>
  <path d="M460,272 L172,272 L172,298" fill="none" stroke="#5a5a5a" stroke-width="1.6" marker-end="url(#ar)"/>
  <path d="M460,272 L460,298" fill="none" stroke="#5a5a5a" stroke-width="1.6" marker-end="url(#ar)"/>
  <path d="M460,272 L748,272 L748,298" fill="none" stroke="#5a5a5a" stroke-width="1.6" marker-end="url(#ar)"/>

  <!-- Cohort boxes -->
  <rect x="48" y="300" width="248" height="122" rx="10" fill="#d9ead5" stroke="#52af6d" stroke-width="1.5"/>
  <text x="172" y="324" text-anchor="middle" fill="#2f5218" font-size="13" font-weight="bold">Overall cohort (unadjusted)</text>
  <use xlink:href="#person" x="72" y="342" width="18" height="23" fill="#c24b3a"/>
  <text x="100" y="360" fill="#1a1a1a" font-size="12.5">Open, n = 638</text>
  <use xlink:href="#person" x="72" y="378" width="18" height="23" fill="#0f659d"/>
  <text x="100" y="396" fill="#1a1a1a" font-size="12.5">Laparoscopic, n = 512</text>

  <rect x="336" y="300" width="248" height="122" rx="10" fill="#f4d1c1" stroke="#d3899a" stroke-width="1.5"/>
  <text x="460" y="324" text-anchor="middle" fill="#843c0c" font-size="13" font-weight="bold">PSM cohort (1:1 matched)</text>
  <use xlink:href="#person" x="360" y="342" width="18" height="23" fill="#c24b3a"/>
  <text x="388" y="360" fill="#1a1a1a" font-size="12.5">Open, n = 477</text>
  <use xlink:href="#person" x="360" y="378" width="18" height="23" fill="#0f659d"/>
  <text x="388" y="396" fill="#1a1a1a" font-size="12.5">Laparoscopic, n = 477</text>

  <rect x="624" y="300" width="248" height="122" rx="10" fill="#ffe699" stroke="#bf9000" stroke-width="1.5"/>
  <text x="748" y="324" text-anchor="middle" fill="#7f6000" font-size="13" font-weight="bold">IPTW cohort (weighted)</text>
  <use xlink:href="#person" x="648" y="342" width="18" height="23" fill="#c24b3a"/>
  <text x="676" y="360" fill="#1a1a1a" font-size="12.5">Open, n = 637.31</text>
  <use xlink:href="#person" x="648" y="378" width="18" height="23" fill="#0f659d"/>
  <text x="676" y="396" fill="#1a1a1a" font-size="12.5">Laparoscopic, n = 509.49</text>

  <!-- Connectors: cohorts -> outcomes -->
  <path d="M172,422 L172,446" fill="none" stroke="#5a5a5a" stroke-width="1.6"/>
  <path d="M460,422 L460,446" fill="none" stroke="#5a5a5a" stroke-width="1.6"/>
  <path d="M748,422 L748,446" fill="none" stroke="#5a5a5a" stroke-width="1.6"/>
  <path d="M172,446 L748,446" fill="none" stroke="#5a5a5a" stroke-width="1.6"/>
  <path d="M240,446 L240,470" fill="none" stroke="#5a5a5a" stroke-width="1.6" marker-end="url(#ar)"/>
  <path d="M680,446 L680,470" fill="none" stroke="#5a5a5a" stroke-width="1.6" marker-end="url(#ar)"/>

  <!-- Pathological & surgical outcomes (blue border) -->
  <rect x="40" y="472" width="400" height="200" rx="16" fill="#ffffff" stroke="#2e75b6" stroke-width="2"/>
  <text x="240" y="500" text-anchor="middle" fill="#1f4e79" font-size="14.5" font-weight="bold">Pathological and surgical outcomes</text>
  <image xlink:href="{stomach}" x="56" y="512" width="74" height="92" preserveAspectRatio="xMidYMid meet"/>
  <image xlink:href="{instr}" x="50" y="606" width="86" height="58" preserveAspectRatio="xMidYMid meet"/>
  <polygon points="158,532 166,518 174,532" fill="#ff0000"/>
  <text x="182" y="532" fill="#1a1a1a" font-size="12.5">MPR, pCR, Mandard TRG</text>
  <polygon points="158,566 166,552 174,566" fill="#2e75b6"/>
  <text x="182" y="566" fill="#1a1a1a" font-size="12.5">ypT stage, ypN stage</text>
  <polygon points="158,608 166,594 174,608" fill="#ff0000"/>
  <text x="182" y="608" fill="#1a1a1a" font-size="12.5">R0 margin, complications</text>
  <polygon points="158,642 166,628 174,642" fill="#2e75b6"/>
  <text x="182" y="642" fill="#1a1a1a" font-size="12.5">Operation time, total LNs</text>

  <!-- Survival outcomes (purple border) -->
  <rect x="480" y="472" width="400" height="200" rx="16" fill="#ffffff" stroke="#7030a0" stroke-width="2"/>
  <text x="680" y="500" text-anchor="middle" fill="#7030a0" font-size="14.5" font-weight="bold">Survival outcomes</text>
  <image xlink:href="{km}" x="500" y="516" width="106" height="72" preserveAspectRatio="xMidYMid meet"/>
  <image xlink:href="{forest}" x="506" y="596" width="94" height="66" preserveAspectRatio="xMidYMid meet"/>
  <polygon points="620,540 628,526 636,540" fill="#ff0000"/>
  <text x="644" y="540" fill="#1a1a1a" font-size="12.5">Kaplan-Meier curves</text>
  <polygon points="620,580 628,566 636,580" fill="#2e75b6"/>
  <text x="644" y="580" fill="#1a1a1a" font-size="12.5">Cox regression models</text>
  <polygon points="620,620 628,606 636,620" fill="#7030a0"/>
  <text x="644" y="620" fill="#1a1a1a" font-size="12.5">Subgroup &amp; sensitivity analyses</text>
</svg>
'''

with open(out_svg, "w") as f:
    f.write(svg)
print("SVG written:", out_svg, "(%.0f KB)" % (len(svg) / 1024))
