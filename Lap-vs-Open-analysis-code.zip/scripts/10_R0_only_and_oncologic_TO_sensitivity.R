################################################################################
# 09_R0_only_and_oncologic_TO_sensitivity.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# R0-only survival sensitivity + oncologic textbook outcome analysis
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(dplyr)
library(tibble)
library(survival)
library(survey)
library(openxlsx)
library(stringr)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/R0_Oncologic_TO", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import data
## ------------------------------------------------------------------

dat_original <- read.csv("results/analysis_dataset_before_psm_iptw.csv",
                         header = TRUE, check.names = TRUE)

dat_psm <- read.csv("results/PSM/matched_dataset.csv",
                    header = TRUE, check.names = TRUE)

dat_iptw <- read.csv("results/IPTW/data_after_iptw.csv",
                     header = TRUE, check.names = TRUE)

## ------------------------------------------------------------------
## 4. Format data
## ------------------------------------------------------------------

format_data <- function(dat) {
  
  dat$Surgical.approach <- factor(
    dat$Surgical.approach,
    levels = c("Open", "Laparoscopic")
  )
  dat$Surgical.approach <- relevel(dat$Surgical.approach, ref = "Open")
  
  dat$DFS <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS <- as.numeric(dat$OS)
  dat$OS.time <- as.numeric(dat$OS.time)
  
  numeric_vars <- c(
    "Age",
    "NACT.cycles",
    "Operation.time",
    "Positive.Lymph.Nodes.Count",
    "Total.Lymph.Nodes.Count"
  )
  
  numeric_vars <- intersect(numeric_vars, names(dat))
  dat[, numeric_vars] <- lapply(dat[, numeric_vars], as.numeric)
  
  factor_vars <- c(
    "Sex",
    "Tumor.site",
    "cT",
    "cN",
    "Grade",
    "Lauren.classification",
    "Bormann.classification",
    "NACT.regimen",
    "Surgical.procedure",
    "ypT",
    "ypN",
    "Mandard.TRG",
    "MPR",
    "pCR",
    "Margin",
    "Nerve.Invasion",
    "Lymphovascular.Tumor.Thrombus",
    "ACT",
    "ACT.regimen",
    "Complication",
    "CD",
    "Perioperative.mortality"
  )
  
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  
  dat <- dat %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(DFS), !is.na(DFS.time), !is.na(OS), !is.na(OS.time))
  
  return(dat)
}

dat_original <- format_data(dat_original)
dat_psm      <- format_data(dat_psm)
dat_iptw     <- format_data(dat_iptw)

## ------------------------------------------------------------------
## 5. Create oncologic textbook outcome
## ------------------------------------------------------------------
## Definition:
## oncologic_textbook_outcome =
## R0 resection + harvested lymph nodes >=16 +
## no perioperative mortality +
## no major complication

create_oncologic_to <- function(dat) {
  
  dat <- dat %>%
    mutate(
      major_complication = ifelse(CD == "Higher than grade 3", 1, 0),
      
      oncologic_textbook_outcome = ifelse(
        Margin == "R0" &
          Total.Lymph.Nodes.Count >= 16 &
          Perioperative.mortality == "No" &
          major_complication == 0,
        1, 0
      )
    )
  
  return(dat)
}

dat_original <- create_oncologic_to(dat_original)
dat_psm      <- create_oncologic_to(dat_psm)
dat_iptw     <- create_oncologic_to(dat_iptw)

## ------------------------------------------------------------------
## 6. Helper functions
## ------------------------------------------------------------------

format_p <- function(p) {
  ifelse(
    is.na(p),
    "NA",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

format_ci <- function(est, lower, upper) {
  paste0(
    sprintf("%.2f", est),
    " (",
    sprintf("%.2f", lower),
    "-",
    sprintf("%.2f", upper),
    ")"
  )
}

extract_cox <- function(fit, cohort, endpoint, model_name, dat_cc, event_var) {
  
  coef_name <- "Surgical.approachLaparoscopic"
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    return(data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = model_name,
      N = nrow(dat_cc),
      Open_N = sum(dat_cc$Surgical.approach == "Open", na.rm = TRUE),
      Laparoscopic_N = sum(dat_cc$Surgical.approach == "Laparoscopic", na.rm = TRUE),
      Events = sum(dat_cc[[event_var]] == 1, na.rm = TRUE),
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA,
      stringsAsFactors = FALSE
    ))
  }
  
  if (inherits(fit, "svycoxph")) {
    
    HR <- exp(coef(fit)[coef_name])
    CI <- exp(confint(fit)[coef_name, ])
    P  <- s$coefficients[coef_name, "Pr(>|z|)"]
    
  } else {
    
    HR <- s$conf.int[coef_name, "exp(coef)"]
    CI <- c(
      s$conf.int[coef_name, "lower .95"],
      s$conf.int[coef_name, "upper .95"]
    )
    P <- s$coefficients[coef_name, "Pr(>|z|)"]
  }
  
  data.frame(
    Cohort = cohort,
    Endpoint = endpoint,
    Model = model_name,
    N = nrow(dat_cc),
    Open_N = sum(dat_cc$Surgical.approach == "Open", na.rm = TRUE),
    Laparoscopic_N = sum(dat_cc$Surgical.approach == "Laparoscopic", na.rm = TRUE),
    Events = sum(dat_cc[[event_var]] == 1, na.rm = TRUE),
    HR = as.numeric(HR),
    Lower95CI = as.numeric(CI[1]),
    Upper95CI = as.numeric(CI[2]),
    P.value = as.numeric(P),
    stringsAsFactors = FALSE
  )
}

run_r0_cox <- function(dat,
                       cohort,
                       endpoint,
                       model_type = c("Original", "PSM", "IPTW"),
                       weight_var = NULL) {
  
  model_type <- match.arg(model_type)
  
  if (endpoint == "DFS") {
    time_var <- "DFS.time"
    event_var <- "DFS"
  } else {
    time_var <- "OS.time"
    event_var <- "OS"
  }
  
  dat_cc <- dat %>%
    filter(Margin == "R0") %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(.data[[time_var]]), !is.na(.data[[event_var]]))
  
  if (model_type == "PSM") {
    
    dat_cc <- dat_cc %>% filter(!is.na(subclass))
    
    fml <- as.formula(
      paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach + cluster(subclass)")
    )
    
    fit <- coxph(fml, data = dat_cc)
    model_name <- "R0-only PSM Cox with matched-pair cluster"
    
  } else if (model_type == "IPTW") {
    
    dat_cc <- dat_cc %>% filter(!is.na(.data[[weight_var]]))
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = dat_cc
    )
    
    fml <- as.formula(
      paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach")
    )
    
    fit <- svycoxph(fml, design = design)
    model_name <- "R0-only IPTW weighted Cox"
    
  } else {
    
    fml <- as.formula(
      paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach")
    )
    
    fit <- coxph(fml, data = dat_cc)
    model_name <- "R0-only unadjusted Cox"
  }
  
  out <- extract_cox(
    fit = fit,
    cohort = cohort,
    endpoint = endpoint,
    model_name = model_name,
    dat_cc = dat_cc,
    event_var = event_var
  )
  
  return(out)
}

desc_binary <- function(dat, cohort, outcome, weight_var = NULL) {
  
  if (is.null(weight_var)) {
    
    tmp <- dat %>%
      filter(!is.na(Surgical.approach), !is.na(.data[[outcome]]))
    
    out <- tmp %>%
      group_by(Surgical.approach) %>%
      summarise(
        n = n(),
        event = sum(.data[[outcome]] == 1, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      mutate(
        value = paste0(event, "/", n, " (", sprintf("%.1f", event / n * 100), "%)")
      )
    
    p <- fisher.test(table(tmp$Surgical.approach, tmp[[outcome]]))$p.value
    
    open_value <- out$value[out$Surgical.approach == "Open"]
    lap_value  <- out$value[out$Surgical.approach == "Laparoscopic"]
    
  } else {
    
    tmp <- dat %>%
      filter(!is.na(Surgical.approach), !is.na(.data[[outcome]]), !is.na(.data[[weight_var]]))
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = tmp
    )
    
    tab <- svyby(
      as.formula(paste0("~", outcome)),
      ~Surgical.approach,
      design,
      svymean,
      na.rm = TRUE
    )
    
    n_tab <- tmp %>%
      group_by(Surgical.approach) %>%
      summarise(
        n_raw = n(),
        event_raw = sum(.data[[outcome]] == 1, na.rm = TRUE),
        .groups = "drop"
      )
    
    p <- svychisq(
      as.formula(paste0("~Surgical.approach + ", outcome)),
      design
    )$p.value
    
    open_rate <- tab[[outcome]][tab$Surgical.approach == "Open"]
    lap_rate  <- tab[[outcome]][tab$Surgical.approach == "Laparoscopic"]
    
    open_raw <- n_tab[n_tab$Surgical.approach == "Open", ]
    lap_raw  <- n_tab[n_tab$Surgical.approach == "Laparoscopic", ]
    
    open_value <- paste0(
      open_raw$event_raw, "/", open_raw$n_raw,
      " (", sprintf("%.1f", open_rate * 100), "%)"
    )
    
    lap_value <- paste0(
      lap_raw$event_raw, "/", lap_raw$n_raw,
      " (", sprintf("%.1f", lap_rate * 100), "%)"
    )
  }
  
  data.frame(
    Cohort = cohort,
    Outcome = outcome,
    Open = open_value,
    Laparoscopic = lap_value,
    P.value = p,
    stringsAsFactors = FALSE
  )
}

run_logistic <- function(dat,
                         cohort,
                         outcome,
                         model_type = c("Original", "PSM", "IPTW"),
                         weight_var = NULL) {
  
  model_type <- match.arg(model_type)
  
  dat_cc <- dat %>%
    filter(!is.na(Surgical.approach), !is.na(.data[[outcome]]))
  
  if (model_type == "PSM") {
    
    ## PSM already controls baseline imbalance by design.
    ## Do not use strata(subclass), otherwise glm becomes unstable and very slow.
    dat_cc <- dat_cc %>% filter(!is.na(subclass))
    
    fml <- as.formula(
      paste0(outcome, " ~ Surgical.approach")
    )
    
    fit <- glm(
      fml,
      data = dat_cc,
      family = binomial()
    )
    
    model_name <- "PSM logistic regression"
    
  } else if (model_type == "IPTW") {
    
    dat_cc <- dat_cc %>% filter(!is.na(.data[[weight_var]]))
    
    fml <- as.formula(
      paste0(outcome, " ~ Surgical.approach")
    )
    
    fit <- glm(
      fml,
      data = dat_cc,
      weights = dat_cc[[weight_var]],
      family = binomial()
    )
    
    model_name <- "IPTW weighted logistic regression"
    
  } else {
    
    fml <- as.formula(
      paste0(outcome, " ~ Surgical.approach")
    )
    
    fit <- glm(
      fml,
      data = dat_cc,
      family = binomial()
    )
    
    model_name <- "Original logistic regression"
  }
  
  coef_name <- "Surgical.approachLaparoscopic"
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    
    OR <- NA
    CI <- c(NA, NA)
    P <- NA
    
  } else {
    
    beta <- coef(fit)[coef_name]
    se <- s$coefficients[coef_name, "Std. Error"]
    
    OR <- exp(beta)
    CI <- exp(c(beta - 1.96 * se, beta + 1.96 * se))
    P <- s$coefficients[coef_name, "Pr(>|z|)"]
  }
  
  data.frame(
    Cohort = cohort,
    Outcome = outcome,
    Model = model_name,
    N = nrow(dat_cc),
    Open_N = sum(dat_cc$Surgical.approach == "Open", na.rm = TRUE),
    Laparoscopic_N = sum(dat_cc$Surgical.approach == "Laparoscopic", na.rm = TRUE),
    Events = sum(dat_cc[[outcome]] == 1, na.rm = TRUE),
    OR = as.numeric(OR),
    Lower95CI = as.numeric(CI[1]),
    Upper95CI = as.numeric(CI[2]),
    P.value = as.numeric(P),
    stringsAsFactors = FALSE
  )
}

## ------------------------------------------------------------------
## 7. Run R0-only survival sensitivity analysis
## ------------------------------------------------------------------

r0_survival_results <- bind_rows(
  
  run_r0_cox(dat_original, "Original", "DFS", "Original"),
  run_r0_cox(dat_original, "Original", "OS",  "Original"),
  
  run_r0_cox(dat_psm, "PSM", "DFS", "PSM"),
  run_r0_cox(dat_psm, "PSM", "OS",  "PSM"),
  
  run_r0_cox(dat_iptw, "IPTW", "DFS", "IPTW", weight_var = "iptw_weight"),
  run_r0_cox(dat_iptw, "IPTW", "OS",  "IPTW", weight_var = "iptw_weight")
) %>%
  mutate(
    HR_CI = format_ci(HR, Lower95CI, Upper95CI),
    P.value.formatted = format_p(P.value)
  )

## ------------------------------------------------------------------
## 8. Run oncologic textbook outcome analysis
## ------------------------------------------------------------------

oncologic_to_desc <- bind_rows(
  desc_binary(dat_original, "Original", "oncologic_textbook_outcome"),
  desc_binary(dat_psm,      "PSM",      "oncologic_textbook_outcome"),
  desc_binary(dat_iptw,     "IPTW",     "oncologic_textbook_outcome", weight_var = "iptw_weight")
) %>%
  mutate(
    P.value.formatted = format_p(P.value)
  )

oncologic_to_logistic <- bind_rows(
  run_logistic(dat_original, "Original", "oncologic_textbook_outcome", "Original"),
  run_logistic(dat_psm,      "PSM",      "oncologic_textbook_outcome", "PSM"),
  run_logistic(dat_iptw,     "IPTW",     "oncologic_textbook_outcome", "IPTW", weight_var = "iptw_weight")
) %>%
  mutate(
    OR_CI = format_ci(OR, Lower95CI, Upper95CI),
    P.value.formatted = format_p(P.value)
  )

## ------------------------------------------------------------------
## 9. Format tables
## ------------------------------------------------------------------

r0_table <- r0_survival_results %>%
  select(
    Cohort,
    Endpoint,
    N,
    Open_N,
    Laparoscopic_N,
    Events,
    HR_CI,
    P.value.formatted
  ) %>%
  rename(
    `HR (95% CI)` = HR_CI,
    `P value` = P.value.formatted
  )

oncologic_to_table <- oncologic_to_desc %>%
  select(
    Cohort,
    Open,
    Laparoscopic,
    P.value.formatted
  ) %>%
  rename(
    `P value` = P.value.formatted
  )

oncologic_to_model_table <- oncologic_to_logistic %>%
  select(
    Cohort,
    Model,
    N,
    Open_N,
    Laparoscopic_N,
    Events,
    OR_CI,
    P.value.formatted
  ) %>%
  rename(
    `OR (95% CI)` = OR_CI,
    `P value` = P.value.formatted
  )

## ------------------------------------------------------------------
## 10. Export results
## ------------------------------------------------------------------

write.csv(
  r0_survival_results,
  "results/R0_Oncologic_TO/R0_only_survival_results.csv",
  row.names = FALSE
)

write.csv(
  oncologic_to_desc,
  "results/R0_Oncologic_TO/oncologic_textbook_outcome_descriptive.csv",
  row.names = FALSE
)

write.csv(
  oncologic_to_logistic,
  "results/R0_Oncologic_TO/oncologic_textbook_outcome_logistic.csv",
  row.names = FALSE
)

wb <- createWorkbook()

addWorksheet(wb, "R0_survival_results")
writeData(wb, "R0_survival_results", r0_survival_results)

addWorksheet(wb, "R0_table")
writeData(wb, "R0_table", r0_table)

addWorksheet(wb, "Oncologic_TO_desc")
writeData(wb, "Oncologic_TO_desc", oncologic_to_desc)

addWorksheet(wb, "Oncologic_TO_table")
writeData(wb, "Oncologic_TO_table", oncologic_to_table)

addWorksheet(wb, "Oncologic_TO_logistic")
writeData(wb, "Oncologic_TO_logistic", oncologic_to_logistic)

addWorksheet(wb, "Oncologic_TO_model_table")
writeData(wb, "Oncologic_TO_model_table", oncologic_to_model_table)

saveWorkbook(
  wb,
  "results/R0_Oncologic_TO/R0_only_and_oncologic_TO_results.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 11. Print key outputs
## ------------------------------------------------------------------

print(r0_table)
print(oncologic_to_table)
print(oncologic_to_model_table)