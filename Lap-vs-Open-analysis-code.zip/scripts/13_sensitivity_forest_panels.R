################################################################################
# 13_sensitivity_forest_panels.R
# Figure 4 (sensitivity HR summary) — individual panels, user assembles composite
#   Panel A: DFS — HR for laparoscopic vs open across all analytic methods
#   Panel B: OS  — same
# Pulls HRs from primary, multivariable, center-adjusted, and R0-only analyses.
################################################################################

rm(list = ls())

library(dplyr)
library(tibble)
library(ggplot2)
library(stringr)

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)
dir.create("results/Panels", showWarnings = FALSE, recursive = TRUE)

col_point <- "#0F659D"

## ------------------------------------------------------------------
## Load all source tables
## ------------------------------------------------------------------

primary  <- read.csv("results/Survival/cox_results_original_psm_iptw.csv",       check.names = TRUE)
multivar <- read.csv("results/Survival/multivariable_cox_sensitivity_results.csv", check.names = TRUE)
center   <- read.csv("results/Center_Adjusted/center_adjusted_cox_results.csv",  check.names = TRUE)
r0       <- read.csv("results/R0_Oncologic_TO/R0_only_survival_results.csv",     check.names = TRUE)

## Extract one (HR, lo, hi, p) given source/cohort/model-substring/endpoint
pull <- function(src, cohort, model_sub, endpoint) {
  row <- src %>%
    filter(Cohort == cohort, Endpoint == endpoint,
           str_detect(Model, fixed(model_sub)))
  if (nrow(row) == 0) stop(paste("No match:", cohort, model_sub, endpoint))
  row <- row[1, ]
  # primary table uses Cox.P.value; others use P.value
  pval <- if ("P.value" %in% names(row)) row$P.value else row$Cox.P.value
  tibble(HR = row$HR, lo = row$Lower95CI, hi = row$Upper95CI, p = pval)
}

## ------------------------------------------------------------------
## Ordered model specification (group, label, source, cohort, model match)
## ------------------------------------------------------------------

spec <- tribble(
  ~group,                ~label,                              ~src,        ~cohort,    ~model,
  "Primary analyses",    "Unadjusted",                        "primary",   "Original", "Unadjusted Cox",
  "Primary analyses",    "PSM (1:1 matched)",                 "primary",   "PSM",      "PSM Cox with matched-pair cluster",
  "Primary analyses",    "IPTW",                              "primary",   "IPTW",     "IPTW weighted Cox",
  "Multivariable adjustment", "+ Preoperative covariates",    "multivar",  "Original", "preoperative variables",
  "Multivariable adjustment", "+ Preop & postoperative",      "multivar",  "Original", "preoperative + limited postoperative variables",
  "Doubly robust",       "PSM + multivariable",               "multivar",  "PSM",      "PSM multivariable Cox: preoperative variables",
  "Doubly robust",       "IPTW + multivariable",              "multivar",  "IPTW",     "weighted + limited preoperative adjustment",
  "Center-stratified",   "Unadjusted + center",               "center",    "Original", "Original center-adjusted Cox",
  "Center-stratified",   "IPTW + center",                     "center",    "IPTW",     "IPTW center-adjusted Cox",
  "Margin-negative (R0) subset", "Unadjusted",                "r0",        "Original", "R0-only unadjusted Cox",
  "Margin-negative (R0) subset", "PSM",                       "r0",        "PSM",      "R0-only PSM Cox with matched-pair cluster",
  "Margin-negative (R0) subset", "IPTW",                      "r0",        "IPTW",     "R0-only IPTW weighted Cox"
)

src_map <- list(primary = primary, multivar = multivar, center = center, r0 = r0)

build_endpoint <- function(endpoint) {
  rows <- lapply(seq_len(nrow(spec)), function(i) {
    s <- spec[i, ]
    v <- pull(src_map[[s$src]], s$cohort, s$model, endpoint)
    bind_cols(s[, c("group", "label")], v)
  })
  bind_rows(rows)
}

## ------------------------------------------------------------------
## Assemble display rows (group headers + model rows), top-to-bottom
## ------------------------------------------------------------------

make_display <- function(df) {
  groups <- unique(df$group)
  out <- list()
  for (g in groups) {
    out[[length(out) + 1]] <- tibble(
      label = g, HR = NA, lo = NA, hi = NA, p = NA, is_header = TRUE)
    chunk <- df %>% filter(group == g)
    for (j in seq_len(nrow(chunk))) {
      out[[length(out) + 1]] <- tibble(
        label = paste0("   ", chunk$label[j]),
        HR = chunk$HR[j], lo = chunk$lo[j], hi = chunk$hi[j], p = chunk$p[j],
        is_header = FALSE)
    }
  }
  d <- bind_rows(out)
  d$y <- rev(seq_len(nrow(d)))   # first row at top
  d$HR_txt <- ifelse(d$is_header, "",
                     sprintf("%.2f (%.2f-%.2f)", d$HR, d$lo, d$hi))
  d$P_txt <- ifelse(d$is_header, "",
                    ifelse(d$p < 0.001, "<0.001", sprintf("%.3f", d$p)))
  d
}

## ------------------------------------------------------------------
## Forest panel renderer
## ------------------------------------------------------------------

## Layout-unit forest: text columns and forest band occupy disjoint x-zones,
## so label/forest/HR spacing is fully controlled. HR is mapped into the
## forest band [fx0, fx1] on a log scale via to_x().
forest_panel <- function(d, title_text) {
  ymax <- max(d$y)

  x_lab <- 2.0                       # labels, left-aligned (shifted right)
  fx0   <- 4.5; fx1 <- 6.4           # forest band
  x_hr  <- 7.9                       # HR (95% CI) text, right-aligned
  x_p   <- 9.4                       # P value text, right-aligned
  hr_lo <- 0.5; hr_hi <- 2.0
  ticks <- c(0.5, 1.0, 1.5, 2.0)

  to_x <- function(hr) {
    fx0 + (log(hr) - log(hr_lo)) / (log(hr_hi) - log(hr_lo)) * (fx1 - fx0)
  }

  ggplot(d, aes(y = y)) +
    # reference line at HR = 1
    geom_segment(x = to_x(1), xend = to_x(1), y = 0.4, yend = ymax + 0.6,
                 linetype = 2, color = "grey55", linewidth = 0.4) +
    # CI + point (HR mapped into forest band)
    geom_segment(aes(x = to_x(pmax(lo, hr_lo)), xend = to_x(pmin(hi, hr_hi)),
                     y = y, yend = y),
                 color = col_point, linewidth = 0.6, na.rm = TRUE) +
    geom_point(aes(x = to_x(HR)), shape = 15, size = 2.6,
               color = col_point, na.rm = TRUE) +
    # left labels (group headers bold)
    geom_text(aes(x = x_lab, label = label,
                  fontface = ifelse(is_header, "bold", "plain")),
              hjust = 0, size = 3.0) +
    # right text columns
    geom_text(aes(x = x_hr, label = HR_txt), hjust = 1, size = 3.0, na.rm = TRUE) +
    geom_text(aes(x = x_p,  label = P_txt),  hjust = 1, size = 3.0, na.rm = TRUE) +
    # column captions
    annotate("text", x = x_lab, y = ymax + 1.5, label = "Analysis",
             hjust = 0, fontface = "bold", size = 3.1) +
    annotate("text", x = x_hr,  y = ymax + 1.5, label = "HR (95% CI)",
             hjust = 1, fontface = "bold", size = 3.1) +
    annotate("text", x = x_p,   y = ymax + 1.5, label = "P value",
             hjust = 1, fontface = "bold", size = 3.1) +
    # manual x-axis under the forest band
    annotate("segment", x = to_x(hr_lo), xend = to_x(hr_hi),
             y = 0.1, yend = 0.1, color = "black", linewidth = 0.4) +
    annotate("segment", x = to_x(ticks), xend = to_x(ticks),
             y = 0.1, yend = -0.1, color = "black", linewidth = 0.4) +
    annotate("text", x = to_x(ticks), y = -0.55,
             label = sprintf("%.1f", ticks), size = 2.7) +
    annotate("text", x = to_x(0.66), y = -1.25, label = "Favors laparoscopic",
             hjust = 0.5, size = 2.5, color = "grey30") +
    annotate("text", x = to_x(1.52), y = -1.25, label = "Favors open",
             hjust = 0.5, size = 2.5, color = "grey30") +
    annotate("text", x = to_x(1), y = -2.0,
             label = "Hazard ratio (laparoscopic vs open)", size = 2.9) +
    scale_x_continuous(limits = c(1.9, 9.5)) +
    scale_y_continuous(limits = c(-2.4, ymax + 2.2)) +
    labs(title = title_text) +
    theme_void(base_size = 10) +
    theme(
      plot.title  = element_text(face = "bold", size = 11,
                                 margin = margin(t = 12, b = 10, l = 16)),
      plot.margin = margin(t = 6, r = 8, b = 6, l = 8)
    )
}

## ------------------------------------------------------------------
## Build and save the two panels
## ------------------------------------------------------------------

d_dfs <- make_display(build_endpoint("DFS"))
d_os  <- make_display(build_endpoint("OS"))

p_dfs <- forest_panel(d_dfs, "Disease-free survival")
p_os  <- forest_panel(d_os,  "Overall survival")

ggsave("results/Panels/Figure4A_sensitivity_DFS.pdf", p_dfs, width = 8.2, height = 5.4)
ggsave("results/Panels/Figure4A_sensitivity_DFS.png", p_dfs, width = 8.2, height = 5.4, dpi = 600)
ggsave("results/Panels/Figure4B_sensitivity_OS.pdf",  p_os,  width = 8.2, height = 5.4)
ggsave("results/Panels/Figure4B_sensitivity_OS.png",  p_os,  width = 8.2, height = 5.4, dpi = 600)

## Also archive the underlying numbers
write.csv(bind_rows(
  build_endpoint("DFS") %>% mutate(Endpoint = "DFS"),
  build_endpoint("OS")  %>% mutate(Endpoint = "OS")
), "results/Panels/Figure4_sensitivity_data.csv", row.names = FALSE)

cat("\n============================================================\n")
cat("Figure 4 panels saved (A: DFS, B: OS) under results/Panels/\n")
cat("============================================================\n")
print(d_dfs %>% filter(!is_header) %>% select(label, HR_txt, P_txt))
