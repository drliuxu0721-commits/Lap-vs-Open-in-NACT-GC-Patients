################################################################################
# 08_center_adjusted_sensitivity_analysis.R
# Gastric cancer after NACT: laparoscopic vs open gastrectomy
# Center-adjusted sensitivity analysis
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(dplyr)
library(tibble)
library(survival)
library(survey)
library(openxlsx)
library(stringr)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Center_Adjusted", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import data
## ------------------------------------------------------------------

dat_center <- read.csv("data str center.csv", header = TRUE, check.names = TRUE)

dat_iptw <- read.csv("results/IPTW/data_after_iptw.csv",
                     header = TRUE, check.names = TRUE)

## ------------------------------------------------------------------
## 4. Check ID
## ------------------------------------------------------------------

cat("\nID check in data str center.csv:\n")
print(anyDuplicated(dat_center$X))

cat("\nID check in IPTW data:\n")
print(anyDuplicated(dat_iptw$X))

## ------------------------------------------------------------------
## 5. Add Center to IPTW data
## ------------------------------------------------------------------
## 如果 X 有重复，先只保留 X-Center 的唯一对应关系。
## 如果一个 X 对应多个 Center，会停止运行，提示手动检查。

center_map <- dat_center %>%
  select(X, Center) %>%
  distinct()

center_check <- center_map %>%
  count(X) %>%
  filter(n > 1)

if (nrow(center_check) > 0) {
  print(center_check)
  stop("Some X IDs map to more than one Center. Please check data str center.csv.")
}

dat_iptw <- dat_iptw %>%
  left_join(center_map, by = "X")

cat("\nMissing Center in IPTW data:\n")
print(sum(is.na(dat_iptw$Center)))

## ------------------------------------------------------------------
## 6. Define radical surgery cohort
## ------------------------------------------------------------------

keep_procedure <- c(
  "Distal gastrectomy",
  "Proximal gastrectomy",
  "Total gastrectomy"
)

dat_original <- dat_center %>%
  filter(Surgical.approach %in% c("Open", "Laparoscopic")) %>%
  filter(Surgical.procedure %in% keep_procedure)

dat_iptw <- dat_iptw %>%
  filter(Surgical.approach %in% c("Open", "Laparoscopic")) %>%
  filter(Surgical.procedure %in% keep_procedure)

## ------------------------------------------------------------------
## 7. Format data
## ------------------------------------------------------------------

format_data <- function(dat) {
  
  dat$Surgical.approach <- factor(
    dat$Surgical.approach,
    levels = c("Open", "Laparoscopic")
  )
  dat$Surgical.approach <- relevel(dat$Surgical.approach, ref = "Open")
  
  dat$Center <- factor(dat$Center)
  
  dat$DFS <- as.numeric(dat$DFS)
  dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS <- as.numeric(dat$OS)
  dat$OS.time <- as.numeric(dat$OS.time)
  
  numeric_vars <- c(
    "Age",
    "NACT.cycles",
    "Operation.time",
    "Positive.Lymph.Nodes.Count",
    "Total.Lymph.Nodes.Count"
  )
  
  numeric_vars <- intersect(numeric_vars, names(dat))
  dat[, numeric_vars] <- lapply(dat[, numeric_vars], as.numeric)
  
  factor_vars <- c(
    "Sex",
    "Tumor.site",
    "cT",
    "cN",
    "Grade",
    "Lauren.classification",
    "Bormann.classification",
    "NACT.regimen",
    "Surgical.procedure",
    "ypT",
    "ypN",
    "Mandard.TRG",
    "MPR",
    "pCR",
    "Margin",
    "ACT",
    "ACT.regimen",
    "Complication",
    "CD",
    "Perioperative.mortality"
  )
  
  factor_vars <- intersect(factor_vars, names(dat))
  dat[, factor_vars] <- lapply(dat[, factor_vars], factor)
  
  dat <- dat %>%
    filter(!is.na(Surgical.approach)) %>%
    filter(!is.na(Center)) %>%
    filter(!is.na(DFS), !is.na(DFS.time), !is.na(OS), !is.na(OS.time))
  
  return(dat)
}

dat_original <- format_data(dat_original)
dat_iptw <- format_data(dat_iptw)

## ------------------------------------------------------------------
## 8. Create additional outcomes
## ------------------------------------------------------------------

create_outcomes <- function(dat) {
  
  dat <- dat %>%
    mutate(
      any_complication = ifelse(Complication == "No", 0, 1),
      major_complication = ifelse(CD == "Higher than grade 3", 1, 0),
      ACT_receipt = ifelse(ACT == "Yes", 1, 0),
      
      textbook_outcome = ifelse(
        Margin == "R0" &
          Perioperative.mortality == "No" &
          any_complication == 0,
        1, 0
      ),
      
      textbook_outcome_ACT = ifelse(
        textbook_outcome == 1 &
          ACT_receipt == 1,
        1, 0
      )
    )
  
  return(dat)
}

dat_original <- create_outcomes(dat_original)
dat_iptw <- create_outcomes(dat_iptw)

## ------------------------------------------------------------------
## 9. Adjustment variables
## ------------------------------------------------------------------
## Center-adjusted sensitivity analysis uses preoperative variables only.
## Extended postoperative adjustment is intentionally not used here.

adj_center <- c(
  "Center",
  "Age",
  "Sex",
  "Tumor.site",
  "cT",
  "cN",
  "Grade",
  "Lauren.classification",
  "Bormann.classification",
  "NACT.regimen",
  "NACT.cycles",
  "Surgical.procedure"
)

## ------------------------------------------------------------------
## 10. Helper functions
## ------------------------------------------------------------------

format_p <- function(p) {
  ifelse(
    is.na(p),
    "NA",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

complete_case_data <- function(dat, vars) {
  vars <- intersect(vars, names(dat))
  dat %>%
    filter(if_all(all_of(vars), ~ !is.na(.)))
}

drop_sparse_factor_levels <- function(dat, vars, event_var = NULL, min_n = 5) {
  
  vars <- intersect(vars, names(dat))
  
  for (v in vars) {
    
    if (is.factor(dat[[v]]) || is.character(dat[[v]])) {
      
      tab <- table(dat[[v]], useNA = "no")
      keep_levels <- names(tab)[tab >= min_n]
      
      dat <- dat %>%
        filter(.data[[v]] %in% keep_levels)
      
      dat[[v]] <- droplevels(factor(dat[[v]]))
    }
  }
  
  return(dat)
}

extract_cox <- function(fit, cohort, endpoint, model_name) {
  
  coef_name <- "Surgical.approachLaparoscopic"
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    return(data.frame(
      Cohort = cohort,
      Endpoint = endpoint,
      Model = model_name,
      HR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA
    ))
  }
  
  if (inherits(fit, "svycoxph")) {
    
    HR <- exp(coef(fit)[coef_name])
    CI <- exp(confint(fit)[coef_name, ])
    P <- s$coefficients[coef_name, "Pr(>|z|)"]
    
  } else {
    
    HR <- s$conf.int[coef_name, "exp(coef)"]
    CI <- c(
      s$conf.int[coef_name, "lower .95"],
      s$conf.int[coef_name, "upper .95"]
    )
    P <- s$coefficients[coef_name, "Pr(>|z|)"]
  }
  
  data.frame(
    Cohort = cohort,
    Endpoint = endpoint,
    Model = model_name,
    HR = as.numeric(HR),
    Lower95CI = as.numeric(CI[1]),
    Upper95CI = as.numeric(CI[2]),
    P.value = as.numeric(P)
  )
}

run_center_cox <- function(dat,
                           cohort,
                           endpoint,
                           adj_vars,
                           weight_var = NULL) {
  
  if (endpoint == "DFS") {
    time_var <- "DFS.time"
    event_var <- "DFS"
  } else {
    time_var <- "OS.time"
    event_var <- "OS"
  }
  
  model_vars <- c(
    "Surgical.approach",
    time_var,
    event_var,
    adj_vars
  )
  
  if (!is.null(weight_var)) {
    model_vars <- c(model_vars, weight_var)
  }
  
  dat_cc <- complete_case_data(dat, model_vars)
  dat_cc <- drop_sparse_factor_levels(dat_cc, adj_vars, min_n = 5)
  
  adj_use <- intersect(adj_vars, names(dat_cc))
  
  fml <- as.formula(
    paste0(
      "Surv(", time_var, ", ", event_var, ") ~ Surgical.approach + ",
      paste(adj_use, collapse = " + ")
    )
  )
  
  if (is.null(weight_var)) {
    
    fit <- coxph(fml, data = dat_cc)
    model_name <- "Original center-adjusted Cox"
    
  } else {
    
    design <- svydesign(
      ids = ~1,
      weights = as.formula(paste0("~", weight_var)),
      data = dat_cc
    )
    
    fit <- svycoxph(fml, design = design)
    model_name <- "IPTW center-adjusted Cox"
  }
  
  out <- extract_cox(
    fit = fit,
    cohort = cohort,
    endpoint = endpoint,
    model_name = model_name
  )
  
  out <- out %>%
    mutate(
      N = nrow(dat_cc),
      Open_N = sum(dat_cc$Surgical.approach == "Open"),
      Laparoscopic_N = sum(dat_cc$Surgical.approach == "Laparoscopic"),
      Events = sum(dat_cc[[event_var]] == 1)
    ) %>%
    select(
      Cohort,
      Endpoint,
      Model,
      N,
      Open_N,
      Laparoscopic_N,
      Events,
      HR,
      Lower95CI,
      Upper95CI,
      P.value
    )
  
  return(out)
}

extract_logistic <- function(fit, cohort, outcome, model_name) {
  
  coef_name <- "Surgical.approachLaparoscopic"
  s <- summary(fit)
  
  if (!coef_name %in% rownames(s$coefficients)) {
    return(data.frame(
      Cohort = cohort,
      Outcome = outcome,
      Model = model_name,
      OR = NA,
      Lower95CI = NA,
      Upper95CI = NA,
      P.value = NA
    ))
  }
  
  beta <- coef(fit)[coef_name]
  se <- s$coefficients[coef_name, "Std. Error"]
  p <- s$coefficients[coef_name, "Pr(>|z|)"]
  
  data.frame(
    Cohort = cohort,
    Outcome = outcome,
    Model = model_name,
    OR = exp(beta),
    Lower95CI = exp(beta - 1.96 * se),
    Upper95CI = exp(beta + 1.96 * se),
    P.value = p
  )
}

run_center_logistic <- function(dat,
                                cohort,
                                outcome,
                                adj_vars,
                                weight_var = NULL) {
  
  model_vars <- c(
    "Surgical.approach",
    outcome,
    adj_vars
  )
  
  if (!is.null(weight_var)) {
    model_vars <- c(model_vars, weight_var)
  }
  
  dat_cc <- complete_case_data(dat, model_vars)
  dat_cc <- drop_sparse_factor_levels(dat_cc, adj_vars, min_n = 5)
  
  adj_use <- intersect(adj_vars, names(dat_cc))
  
  fml <- as.formula(
    paste0(
      outcome, " ~ Surgical.approach + ",
      paste(adj_use, collapse = " + ")
    )
  )
  
  if (is.null(weight_var)) {
    
    fit <- glm(fml, data = dat_cc, family = binomial())
    model_name <- "Original center-adjusted logistic regression"
    
  } else {
    
    fit <- glm(
      fml,
      data = dat_cc,
      weights = dat_cc[[weight_var]],
      family = binomial()
    )
    model_name <- "IPTW center-adjusted weighted logistic regression"
  }
  
  out <- extract_logistic(
    fit = fit,
    cohort = cohort,
    outcome = outcome,
    model_name = model_name
  )
  
  out <- out %>%
    mutate(
      N = nrow(dat_cc),
      Open_N = sum(dat_cc$Surgical.approach == "Open"),
      Laparoscopic_N = sum(dat_cc$Surgical.approach == "Laparoscopic"),
      Events = sum(dat_cc[[outcome]] == 1)
    ) %>%
    select(
      Cohort,
      Outcome,
      Model,
      N,
      Open_N,
      Laparoscopic_N,
      Events,
      OR,
      Lower95CI,
      Upper95CI,
      P.value
    )
  
  return(out)
}

## ------------------------------------------------------------------
## 11. Run center-adjusted Cox
## ------------------------------------------------------------------

center_cox_results <- bind_rows(
  
  run_center_cox(
    dat = dat_original,
    cohort = "Original",
    endpoint = "DFS",
    adj_vars = adj_center
  ),
  
  run_center_cox(
    dat = dat_original,
    cohort = "Original",
    endpoint = "OS",
    adj_vars = adj_center
  ),
  
  run_center_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "DFS",
    adj_vars = adj_center,
    weight_var = "iptw_weight"
  ),
  
  run_center_cox(
    dat = dat_iptw,
    cohort = "IPTW",
    endpoint = "OS",
    adj_vars = adj_center,
    weight_var = "iptw_weight"
  )
)

center_cox_results <- center_cox_results %>%
  mutate(
    HR_CI = paste0(
      sprintf("%.2f", HR),
      " (",
      sprintf("%.2f", Lower95CI),
      "-",
      sprintf("%.2f", Upper95CI),
      ")"
    ),
    P.value.formatted = format_p(P.value)
  )

## ------------------------------------------------------------------
## 12. Run center-adjusted logistic
## ------------------------------------------------------------------

outcomes_binary <- c(
  "any_complication",
  "major_complication",
  "ACT_receipt",
  "textbook_outcome",
  "textbook_outcome_ACT"
)

center_logistic_results <- bind_rows(
  
  lapply(outcomes_binary, function(x) {
    run_center_logistic(
      dat = dat_original,
      cohort = "Original",
      outcome = x,
      adj_vars = adj_center
    )
  }),
  
  lapply(outcomes_binary, function(x) {
    run_center_logistic(
      dat = dat_iptw,
      cohort = "IPTW",
      outcome = x,
      adj_vars = adj_center,
      weight_var = "iptw_weight"
    )
  })
)

center_logistic_results <- center_logistic_results %>%
  mutate(
    OR_CI = paste0(
      sprintf("%.2f", OR),
      " (",
      sprintf("%.2f", Lower95CI),
      "-",
      sprintf("%.2f", Upper95CI),
      ")"
    ),
    P.value.formatted = format_p(P.value)
  )

## ------------------------------------------------------------------
## 13. Center distribution
## ------------------------------------------------------------------

center_distribution <- dat_original %>%
  group_by(Center, Surgical.approach) %>%
  summarise(N = n(), .groups = "drop") %>%
  group_by(Center) %>%
  mutate(Percent = N / sum(N) * 100) %>%
  ungroup()

center_summary <- dat_original %>%
  group_by(Center) %>%
  summarise(
    N = n(),
    Open_N = sum(Surgical.approach == "Open"),
    Laparoscopic_N = sum(Surgical.approach == "Laparoscopic"),
    DFS_events = sum(DFS == 1, na.rm = TRUE),
    OS_events = sum(OS == 1, na.rm = TRUE),
    .groups = "drop"
  )

## ------------------------------------------------------------------
## 14. Export results
## ------------------------------------------------------------------

write.csv(
  center_cox_results,
  "results/Center_Adjusted/center_adjusted_cox_results.csv",
  row.names = FALSE
)

write.csv(
  center_logistic_results,
  "results/Center_Adjusted/center_adjusted_logistic_results.csv",
  row.names = FALSE
)

write.csv(
  center_distribution,
  "results/Center_Adjusted/center_distribution.csv",
  row.names = FALSE
)

write.csv(
  center_summary,
  "results/Center_Adjusted/center_summary.csv",
  row.names = FALSE
)

wb <- createWorkbook()

addWorksheet(wb, "center_adjusted_cox")
writeData(wb, "center_adjusted_cox", center_cox_results)

addWorksheet(wb, "center_adjusted_logistic")
writeData(wb, "center_adjusted_logistic", center_logistic_results)

addWorksheet(wb, "center_distribution")
writeData(wb, "center_distribution", center_distribution)

addWorksheet(wb, "center_summary")
writeData(wb, "center_summary", center_summary)

saveWorkbook(
  wb,
  "results/Center_Adjusted/center_adjusted_sensitivity_results.xlsx",
  overwrite = TRUE
)

## ------------------------------------------------------------------
## 15. Print outputs
## ------------------------------------------------------------------

print(center_summary)
print(center_cox_results)
print(center_logistic_results)