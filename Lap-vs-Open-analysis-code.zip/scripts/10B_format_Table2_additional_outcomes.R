################################################################################
# 10B_format_Table2_additional_outcomes.R
# Format Table 2: additional outcomes for manuscript
################################################################################

rm(list = ls())

## ------------------------------------------------------------------
## 1. Load packages
## ------------------------------------------------------------------

library(dplyr)
library(tidyr)
library(stringr)
library(openxlsx)

## ------------------------------------------------------------------
## 2. Working directory
## ------------------------------------------------------------------

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)

dir.create("results/Final_Tables", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------------
## 3. Import Table 2 source
## ------------------------------------------------------------------

file_in <- "results/Final_Tables/Table3_additional_outcomes.csv"

if (!file.exists(file_in)) {
  file_in <- "Table3_additional_outcomes.csv"
}

dat <- read.csv(file_in, header = TRUE, check.names = FALSE)

## ------------------------------------------------------------------
## 4. Clean names
## ------------------------------------------------------------------

dat <- dat %>%
  mutate(
    Outcome = recode(
      Outcome,
      "Any postoperative complication" =
        "Any postoperative complication",
      "Major complication, Clavien-Dindo grade III or higher" =
        "Major complication, Clavien-Dindo grade III or higher",
      "Receipt of adjuvant chemotherapy" =
        "Receipt of adjuvant chemotherapy",
      "Textbook outcome" =
        "Textbook outcome",
      "Textbook outcome plus adjuvant chemotherapy receipt" =
        "Textbook outcome plus adjuvant chemotherapy receipt",
      .default = Outcome
    ),
    Cohort = recode(
      Cohort,
      "Original" = "Original cohort",
      "PSM" = "PSM cohort",
      "IPTW" = "IPTW cohort",
      .default = Cohort
    )
  )

## ------------------------------------------------------------------
## 5. Reshape to manuscript format
## ------------------------------------------------------------------

table2 <- dat %>%
  select(Cohort, Outcome, Open, Laparoscopic, `P value`) %>%
  pivot_wider(
    id_cols = Outcome,
    names_from = Cohort,
    values_from = c(Open, Laparoscopic, `P value`),
    names_glue = "{Cohort}_{.value}"
  ) %>%
  select(
    Outcome,
    `Original cohort_Open`,
    `Original cohort_Laparoscopic`,
    `Original cohort_P value`,
    `PSM cohort_Open`,
    `PSM cohort_Laparoscopic`,
    `PSM cohort_P value`,
    `IPTW cohort_Open`,
    `IPTW cohort_Laparoscopic`,
    `IPTW cohort_P value`
  )

colnames(table2) <- c(
  "Outcome",
  "Open",
  "Laparoscopic",
  "P value",
  "Open",
  "Laparoscopic",
  "P value",
  "Open",
  "Laparoscopic",
  "P value"
)

## ------------------------------------------------------------------
## 6. Create workbook
## ------------------------------------------------------------------

wb <- createWorkbook()
addWorksheet(wb, "Table 2")

## ------------------------------------------------------------------
## 7. Write title and table
## ------------------------------------------------------------------

writeData(
  wb,
  "Table 2",
  "Table 2. Postoperative, adjuvant chemotherapy, and textbook outcomes according to surgical approach",
  startRow = 1,
  startCol = 1,
  colNames = FALSE
)

writeData(wb, "Table 2", "", startRow = 2, startCol = 1, colNames = FALSE)

writeData(
  wb,
  "Table 2",
  x = data.frame(
    A = "",
    B = "Original cohort",
    C = "",
    D = "",
    E = "PSM cohort",
    F = "",
    G = "",
    H = "IPTW cohort",
    I = "",
    J = ""
  ),
  startRow = 2,
  startCol = 1,
  colNames = FALSE
)

writeData(
  wb,
  "Table 2",
  x = as.data.frame(t(colnames(table2))),
  startRow = 3,
  startCol = 1,
  colNames = FALSE
)

writeData(
  wb,
  "Table 2",
  x = table2,
  startRow = 4,
  startCol = 1,
  colNames = FALSE
)

note_row <- nrow(table2) + 5

writeData(
  wb,
  "Table 2",
  paste0(
    "Values are presented as number/total number (%). ",
    "PSM, propensity score matching; IPTW, inverse probability of treatment weighting. ",
    "Textbook outcome was defined as R0 resection, absence of perioperative mortality, ",
    "and absence of postoperative complications. ",
    "Textbook outcome plus adjuvant chemotherapy receipt additionally required receipt of postoperative adjuvant chemotherapy."
  ),
  startRow = note_row,
  startCol = 1,
  colNames = FALSE
)

## ------------------------------------------------------------------
## 8. Merge cells
## ------------------------------------------------------------------

mergeCells(wb, "Table 2", cols = 1:10, rows = 1)

mergeCells(wb, "Table 2", cols = 2:4, rows = 2)
mergeCells(wb, "Table 2", cols = 5:7, rows = 2)
mergeCells(wb, "Table 2", cols = 8:10, rows = 2)

mergeCells(wb, "Table 2", cols = 1:10, rows = note_row)

## ------------------------------------------------------------------
## 9. Styles
## ------------------------------------------------------------------

title_style <- createStyle(
  textDecoration = "bold",
  fontSize = 11,
  halign = "left"
)

group_style <- createStyle(
  textDecoration = "bold",
  halign = "center",
  border = "top",
  borderStyle = "thin"
)

header_style <- createStyle(
  textDecoration = "bold",
  halign = "center",
  border = "bottom",
  borderStyle = "thin"
)

body_center_style <- createStyle(
  halign = "center",
  valign = "center"
)

body_left_style <- createStyle(
  halign = "left",
  valign = "center"
)

bottom_center_style <- createStyle(
  halign = "center",
  valign = "center",
  border = "bottom",
  borderStyle = "thin"
)

bottom_left_style <- createStyle(
  halign = "left",
  valign = "center",
  border = "bottom",
  borderStyle = "thin"
)

note_style <- createStyle(
  fontSize = 9,
  halign = "left",
  valign = "top",
  wrapText = TRUE
)

## ------------------------------------------------------------------
## 10. Apply styles
## ------------------------------------------------------------------

addStyle(
  wb,
  "Table 2",
  title_style,
  rows = 1,
  cols = 1,
  gridExpand = TRUE
)

addStyle(
  wb,
  "Table 2",
  group_style,
  rows = 2,
  cols = 1:10,
  gridExpand = TRUE
)

addStyle(
  wb,
  "Table 2",
  header_style,
  rows = 3,
  cols = 1:10,
  gridExpand = TRUE
)

addStyle(
  wb,
  "Table 2",
  body_left_style,
  rows = 4:(nrow(table2) + 3),
  cols = 1,
  gridExpand = TRUE
)

addStyle(
  wb,
  "Table 2",
  body_center_style,
  rows = 4:(nrow(table2) + 3),
  cols = 2:10,
  gridExpand = TRUE
)

last_data_row <- nrow(table2) + 3

addStyle(
  wb,
  "Table 2",
  bottom_left_style,
  rows = last_data_row,
  cols = 1,
  gridExpand = TRUE,
  stack = TRUE
)

addStyle(
  wb,
  "Table 2",
  bottom_center_style,
  rows = last_data_row,
  cols = 2:10,
  gridExpand = TRUE,
  stack = TRUE
)

addStyle(
  wb,
  "Table 2",
  note_style,
  rows = note_row,
  cols = 1:10,
  gridExpand = TRUE
)

## ------------------------------------------------------------------
## 11. Widths and layout
## ------------------------------------------------------------------

setColWidths(wb, "Table 2", cols = 1, widths = 48)
setColWidths(wb, "Table 2", cols = 2:10, widths = 15)

setRowHeights(wb, "Table 2", rows = 1, heights = 24)
setRowHeights(wb, "Table 2", rows = 2:3, heights = 22)
setRowHeights(wb, "Table 2", rows = 4:last_data_row, heights = 22)
setRowHeights(wb, "Table 2", rows = note_row, heights = 45)

freezePane(wb, "Table 2", firstActiveRow = 4)

## ------------------------------------------------------------------
## 12. Export
## ------------------------------------------------------------------

file_out <- "results/Final_Tables/Table2_additional_outcomes_manuscript.xlsx"

saveWorkbook(wb, file_out, overwrite = TRUE)

write.csv(
  table2,
  "results/Final_Tables/Table2_additional_outcomes_manuscript.csv",
  row.names = FALSE
)

## ------------------------------------------------------------------
## 13. Print output
## ------------------------------------------------------------------

print(table2)

cat("\nExported:\n")
cat(file_out, "\n")
cat("results/Final_Tables/Table2_additional_outcomes_manuscript.csv\n")