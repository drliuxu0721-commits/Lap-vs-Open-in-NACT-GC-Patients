################################################################################
# 14_km_individual_panels.R
# Figure 2 (KM survival) — six INDIVIDUAL panels for self-assembly (3x2 grid)
#   Original / PSM / IPTW  x  DFS / OS
# No A-F letter labels; each panel keeps its risk table.
# Styling reused from script 07 (make_km), already approved.
################################################################################

rm(list = ls())

library(survival)
library(survminer)
library(survey)
library(dplyr)

root_dir <- "/Users/dr.xuliu/Work/Research/Clinical Research/Lap vs Open"
setwd(root_dir)
dir.create("results/Panels", showWarnings = FALSE, recursive = TRUE)

col_open <- "#C24B3A"
col_lap  <- "#0F659D"

## ------------------------------------------------------------------
## Data
## ------------------------------------------------------------------

dat_original <- read.csv("results/analysis_dataset_before_psm_iptw.csv", check.names = TRUE)
dat_psm      <- read.csv("results/PSM/matched_dataset.csv",              check.names = TRUE)
dat_iptw     <- read.csv("results/IPTW/data_after_iptw.csv",             check.names = TRUE)

format_surv <- function(dat) {
  dat$Surgical.approach <- factor(dat$Surgical.approach, levels = c("Open", "Laparoscopic"))
  dat$DFS <- as.numeric(dat$DFS); dat$DFS.time <- as.numeric(dat$DFS.time)
  dat$OS  <- as.numeric(dat$OS);  dat$OS.time  <- as.numeric(dat$OS.time)
  dat %>% filter(!is.na(Surgical.approach), !is.na(DFS), !is.na(DFS.time),
                 !is.na(OS), !is.na(OS.time))
}

dat_original <- format_surv(dat_original)
dat_psm      <- format_surv(dat_psm)
dat_iptw     <- format_surv(dat_iptw)

## ------------------------------------------------------------------
## Helpers (identical styling to script 07)
## ------------------------------------------------------------------

format_p <- function(p) {
  if (is.na(p))  return("NA")
  if (p < 0.001) return("<0.001")
  paste0("=", sprintf("%.3f", p))
}

make_km <- function(dat, time_var, event_var, title,
                    weight_var = NULL,
                    ylab_text  = "Disease-free survival probability",
                    is_psm     = FALSE) {
  rt <- dat
  surv_formula <- as.formula(paste0("Surv(", time_var, ", ", event_var, ") ~ Surgical.approach"))

  if (is.null(weight_var)) {
    if (is_psm && "subclass" %in% names(rt)) {
      coxfit <- coxph(as.formula(paste0("Surv(", time_var, ", ", event_var,
                       ") ~ Surgical.approach + cluster(subclass)")), data = rt)
    } else {
      coxfit <- coxph(surv_formula, data = rt)
    }
    cs  <- summary(coxfit)
    HR  <- cs$conf.int["Surgical.approachLaparoscopic", "exp(coef)"]
    LCL <- cs$conf.int["Surgical.approachLaparoscopic", "lower .95"]
    UCL <- cs$conf.int["Surgical.approachLaparoscopic", "upper .95"]
    Logrank.P <- 1 - pchisq(survdiff(surv_formula, data = rt)$chisq, df = 1)
    fit <- survfit(surv_formula, data = rt)
  } else {
    design <- svydesign(ids = ~1, weights = as.formula(paste0("~", weight_var)), data = rt)
    coxfit <- svycoxph(surv_formula, design = design)
    HR  <- exp(coef(coxfit)["Surgical.approachLaparoscopic"])
    CI  <- exp(confint(coxfit)["Surgical.approachLaparoscopic", ])
    LCL <- CI[1]; UCL <- CI[2]
    Logrank.P <- as.numeric(svylogrank(surv_formula, design = design)[[2]][2])
    fit <- survfit(surv_formula, data = rt, weights = rt[[weight_var]])
  }

  hr.txt <- paste0("HR = ", sprintf("%.2f", HR), " (95% CI: ",
                   sprintf("%.2f", LCL), "-", sprintf("%.2f", UCL), ")")
  pValue <- paste0("Log-rank P", format_p(Logrank.P), "\n", hr.txt)
  fit$call$formula <- surv_formula

  ggsurvplot(
    fit, data = rt, conf.int = TRUE,
    pval = pValue, pval.size = 4, pval.coord = c(0, 0.15),
    legend.title = "", legend.labs = c("Open", "Laparoscopic"),
    xlab = "Time (months)", ylab = ylab_text, break.time.by = 24,
    palette = c(col_open, col_lap),
    risk.table = TRUE, risk.table.title = "", risk.table.height = 0.25,
    risk.table.fontsize = 3, title = title,
    font.title = c(11, "bold"), font.x = c(10), font.y = c(10),
    font.tickslab = c(9), legend = c(0.8, 0.95)
  )
}

save_km <- function(km, base, width = 6, height = 6.5) {
  pdf(paste0(base, ".pdf"), width = width, height = height, onefile = FALSE)
  print(km); dev.off()
  png(paste0(base, ".png"), width = width, height = height, units = "in", res = 600)
  print(km); dev.off()
}

## ------------------------------------------------------------------
## Build and save six individual panels (no letter labels)
## ------------------------------------------------------------------

ylab_dfs <- "Disease-free survival probability"
ylab_os  <- "Overall survival probability"
pre <- "results/Panels/Figure2_KM_"

save_km(make_km(dat_original, "DFS.time", "DFS",
                "Unadjusted cohort, disease-free survival", ylab_text = ylab_dfs),
        paste0(pre, "Unadjusted_DFS"))
save_km(make_km(dat_original, "OS.time", "OS",
                "Unadjusted cohort, overall survival", ylab_text = ylab_os),
        paste0(pre, "Unadjusted_OS"))

save_km(make_km(dat_psm, "DFS.time", "DFS",
                "PSM cohort, disease-free survival", is_psm = TRUE, ylab_text = ylab_dfs),
        paste0(pre, "PSM_DFS"))
save_km(make_km(dat_psm, "OS.time", "OS",
                "PSM cohort, overall survival", is_psm = TRUE, ylab_text = ylab_os),
        paste0(pre, "PSM_OS"))

save_km(make_km(dat_iptw, "DFS.time", "DFS",
                "IPTW cohort, disease-free survival", weight_var = "iptw_weight", ylab_text = ylab_dfs),
        paste0(pre, "IPTW_DFS"))
save_km(make_km(dat_iptw, "OS.time", "OS",
                "IPTW cohort, overall survival", weight_var = "iptw_weight", ylab_text = ylab_os),
        paste0(pre, "IPTW_OS"))

cat("\n============================================================\n")
cat("Figure 2 KM: six individual panels saved under results/Panels/\n")
cat("  Figure2_KM_{Unadjusted,PSM,IPTW}_{DFS,OS}.{pdf,png}\n")
cat("============================================================\n")
