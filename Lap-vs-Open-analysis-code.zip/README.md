# Analysis code — Laparoscopic versus open gastrectomy after neoadjuvant chemotherapy for locally advanced gastric cancer

This repository contains the statistical analysis and figure/table generation code for the multicenter, retrospective cohort study comparing **totally laparoscopic** versus **open** radical gastrectomy in patients with HER2-negative locally advanced gastric adenocarcinoma treated with neoadjuvant SOX or DOS chemotherapy at four Chinese cancer centers (2010–2024).

## Software
- **R version 4.4.3** (R Foundation for Statistical Computing).
- Key R packages: `MatchIt`, `WeightIt`, `cobalt`, `survey`, `survival`, `survminer`, `tableone`, `compareGroups`, `mice`, plus `ggplot2`/`dplyr`/`readr` for figures and data handling.
- Two figure-assembly helpers are in Python 3 (`matplotlib`/`python-pptx`).

## Data availability
The individual-patient clinical dataset is **not included** because of institutional ethics and patient-privacy requirements (see the manuscript Data Availability statement). The scripts expect a single input table (`data str.csv`) with one row per patient and the following columns: `Sex, Age, Tumor.site, cT, cN, Grade, Lauren.classification, Bormann.classification, NACT.regimen, NACT.cycles, Surgical.procedure, Surgical.approach, Operation.time, ypT, ypN, Mandard.TRG, MPR, pCR, Margin, Nerve.Invasion, Lymphovascular.Tumor.Thrombus, Positive.Lymph.Nodes.Count, Total.Lymph.Nodes.Count, ACT, Complication, CD, Perioperative.mortality, Recurrence, Metastasis, OS, OS.time, DFS, DFS.time` (a per-center version adds a center identifier). Missing data were handled as described in the manuscript (variables with >20% missingness excluded from multivariable models; ≤20% imputed by multivariate imputation by chained equations).

## Analysis pipeline (run in order)
| Script | Purpose |
|---|---|
| `scripts/01_lap_open_psm_iptw.R` | Cohort build, propensity-score matching (477 pairs) and IPTW, baseline tables and standardized mean differences (Table 1). |
| `scripts/02_surgical_pathological_outcomes.R` | Surgical and pathological outcomes across Original/PSM/IPTW cohorts (Table 2). |
| `scripts/03_survival_analysis.R` | Kaplan–Meier estimates and Cox models for DFS and OS across the three cohorts. |
| `scripts/04_subgroup_analysis.R` | Pre-specified subgroup analyses and treatment-by-subgroup interaction tests (PSM and IPTW). |
| `scripts/05_multivariable_cox_sensitivity_analysis.R` | Multivariable-adjusted Cox sensitivity analyses for DFS and OS. |
| `scripts/06_exploratory_act_pathway_analysis.R` | Exploratory adjuvant-chemotherapy pathway analysis (exploratory; **not reported** in the manuscript). |
| `scripts/09_center_adjusted_sensitivity_analysis.R` | Center-adjusted Cox sensitivity analysis. |
| `scripts/10_R0_only_and_oncologic_TO_sensitivity.R` | R0-restricted survival sensitivity analysis and oncologic textbook-outcome analysis. |
| `scripts/12_original_subgroup_analysis.R` | Unadjusted (Original cohort) subgroup Cox analysis. |

### Table / figure formatting
| Script | Output |
|---|---|
| `scripts/11_format_table2_surgical_pathological.R`, `08_format_table3_additional_outcomes.R`, `10B_format_Table2_additional_outcomes.R`, `format_table3_cox_results.R` | Formatted manuscript Tables 2–4. |
| `scripts/07_figure_panels.R`, `14_km_individual_panels.R` | Figure 2 (Kaplan–Meier panels). |
| `scripts/18_subgroup_individual_panels.R` | Figure 3 (subgroup forest plot). |
| `scripts/13_sensitivity_forest_panels.R` | Figure 4 (sensitivity-analysis forest plot). |
| `scripts/15_figure1_consort.R`, `16_figure1_build.py`, `17_figure1_pptx.py` | Figure 1 (study flow diagram). |

## How to run
1. Place the input `data str.csv` (and, for center-adjusted analyses, the per-center file) in the working directory.
2. Open R 4.4.3, install the packages listed above, then source the scripts in the numeric order shown.
3. Analysis outputs (tables, model estimates) and figure panels are written to the working directory.

## Citation
If you use this code, please cite the associated article (World Journal of Gastroenterology; full citation to be added on publication).

## Contact
Corresponding author: Yantao Tian (tianyantao@cicams.ac.cn), National Cancer Center/Cancer Hospital, Chinese Academy of Medical Sciences and Peking Union Medical College.
