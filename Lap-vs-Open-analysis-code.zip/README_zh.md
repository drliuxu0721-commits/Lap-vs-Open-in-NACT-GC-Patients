# 分析代码 — 新辅助化疗后腹腔镜与开腹胃切除术治疗局部进展期胃癌

本仓库包含该多中心回顾性队列研究的统计分析与图表生成代码。研究比较了 HER2 阴性、局部进展期胃腺癌患者在接受新辅助 SOX 或 DOS 化疗后,行**全腹腔镜**与**开腹**根治性胃切除术的结局(四家中国肿瘤中心,2010–2024)。

## 运行环境
- **R 4.4.3**(R Foundation for Statistical Computing)。
- 主要 R 包:`MatchIt`、`WeightIt`、`cobalt`、`survey`、`survival`、`survminer`、`tableone`、`compareGroups`、`mice`,以及作图/数据处理用的 `ggplot2`/`dplyr`/`readr`。
- 两个拼图辅助脚本为 Python 3(`matplotlib`/`python-pptx`)。

## 数据可用性
出于机构伦理与患者隐私要求,**个体患者数据不包含在本仓库中**(见正文 Data Availability 声明)。脚本期望一个输入表 `data str.csv`(每行一名患者),列名如下:`Sex, Age, Tumor.site, cT, cN, Grade, Lauren.classification, Bormann.classification, NACT.regimen, NACT.cycles, Surgical.procedure, Surgical.approach, Operation.time, ypT, ypN, Mandard.TRG, MPR, pCR, Margin, Nerve.Invasion, Lymphovascular.Tumor.Thrombus, Positive.Lymph.Nodes.Count, Total.Lymph.Nodes.Count, ACT, Complication, CD, Perioperative.mortality, Recurrence, Metastasis, OS, OS.time, DFS, DFS.time`(分中心版本另加中心标识列)。缺失数据按正文所述处理:缺失 >20% 的变量不进入多因素模型;缺失 ≤20% 的变量以链式方程多重插补(MICE)填补。

## 分析流程(按顺序运行)
| 脚本 | 用途 |
|---|---|
| `scripts/01_lap_open_psm_iptw.R` | 构建队列,倾向评分匹配(477 对)与 IPTW,基线表与标准化均数差(表 1)。 |
| `scripts/02_surgical_pathological_outcomes.R` | 原始/PSM/IPTW 三队列的外科与病理结局(表 2)。 |
| `scripts/03_survival_analysis.R` | 三队列 DFS 与 OS 的 Kaplan–Meier 与 Cox 模型。 |
| `scripts/04_subgroup_analysis.R` | 预设亚组分析与"术式×亚组"交互检验(PSM 与 IPTW)。 |
| `scripts/05_multivariable_cox_sensitivity_analysis.R` | DFS/OS 的多因素校正 Cox 敏感性分析。 |
| `scripts/06_exploratory_act_pathway_analysis.R` | 辅助化疗通路探索性分析(探索性,**未写入正文**)。 |
| `scripts/09_center_adjusted_sensitivity_analysis.R` | 中心校正 Cox 敏感性分析。 |
| `scripts/10_R0_only_and_oncologic_TO_sensitivity.R` | 仅 R0 的生存敏感性分析与肿瘤学教科书式结局分析。 |
| `scripts/12_original_subgroup_analysis.R` | 原始(未校正)队列亚组 Cox 分析。 |

### 表 / 图格式化
| 脚本 | 输出 |
|---|---|
| `scripts/11_...`、`08_...`、`10B_...`、`format_table3_cox_results.R` | 正文表 2–4 的格式化。 |
| `scripts/07_figure_panels.R`、`14_km_individual_panels.R` | 图 2(Kaplan–Meier 面板)。 |
| `scripts/18_subgroup_individual_panels.R` | 图 3(亚组森林图)。 |
| `scripts/13_sensitivity_forest_panels.R` | 图 4(敏感性分析森林图)。 |
| `scripts/15_figure1_consort.R`、`16_figure1_build.py`、`17_figure1_pptx.py` | 图 1(研究流程图)。 |

## 如何运行
1. 将输入 `data str.csv`(以及分中心校正所需的分中心文件)放入工作目录。
2. 打开 R 4.4.3,安装上述包,按编号顺序依次 source 各脚本。
3. 分析输出(表、模型估计)与图面板写入工作目录。

## 引用
若使用本代码,请引用相应文章(World Journal of Gastroenterology;正式引用待发表后补充)。

## 联系
通讯作者:田艳涛(tianyantao@cicams.ac.cn),国家癌症中心/中国医学科学院肿瘤医院。
